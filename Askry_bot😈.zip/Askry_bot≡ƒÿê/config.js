#!/usr/bin/env node
/**
 * ╔════════════════════════════════════════════════════════════════╗
 * ║  💀 𝐀𝐒𝐊𝐑𝐘-𝐁𝐎𝐓 𝐂𝐎𝐍𝐅𝐈𝐆 - 𝐇𝐀𝐂𝐊𝐄𝐑 𝐄𝐃𝐈𝐓𝐈𝐎𝐍 💀                   ║
 * ║  Main Configuration File - All Bot Settings                   ║
 * ║  Author: Al Askry | Telegram: @askry47 | © 2026               ║
 * ╚════════════════════════════════════════════════════════════════╝
 */

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
// 👑 ASKRY BOT - OWNER & CONTACTS
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
global.owner = [
  // Format: ['phone_number', 'display_name', 'isCreator']
  ['201067828124', 'Al Askry 👑', true],    // ✅ رقمك الأساسي (مطور)
  ['201067828124', 'Al Askry | Main', true], // نسخة احتياطية
]

global.mods = [
  // المشرفين (يقدروا يستخدموا أوامر mods)
  // '201000000000@s.whatsapp.net'
]

global.prems = [
  // المستخدمين المميزين (يقدروا يستخدموا أوامر premium)
  // '201000000000@s.whatsapp.net'
]

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
// 🤖 BOT IDENTITY & BRANDING
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
global.bot = {
  name: 'ASKRY-BOT',              // اسم البوت
  version: '2.0.0-HACKER',        // نسخة البوت
  author: 'Al Askry',             // اسم المطور
  telegram: '@askry47',           // حساب التليجرام
  whatsappChannel: 'https://whatsapp.com/channel/0029Vb6z6NO545v2nTgoBa3I',
  copyright: '© 2026 Al Askry. All Rights Reserved.',
  emoji: {
    owner: '👑',
    admin: '🛡️',
    premium: '💎',
    error: '💥',
    success: '✅',
    warning: '⚠️',
    hacker: '💀'
  }
};

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
// 🔧 TECHNICAL SETTINGS
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
global.libreria = 'Baileys'       // المكتبة المستخدمة
global.baileys = 'V 6.7.16'       // نسخة Baileys
global.vs = '2.2.0'               // نسخة البوت الداخلية
global.nameqr = 'ASKRY-QR'        // اسم جلسة QR
global.namebot = 'ASKRY-BOT'      // اسم البوت (للاستخدام الداخلي)
global.sessions = 'Askry_Session' // 📁 مجلد حفظ الجلسات
global.jadi = 'JadiBots'          // 📁 مجلد البوتات الفرعية
global.yukiJadibts = true         // تفعيل نظام البوتات الفرعية

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
// 🎨 STICKER & PACK SETTINGS
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
global.packname = 'ASKRY-BOT'     // اسم البوت على الاستيكرات
global.author = 'Al Askry 👑'     // اسم المطور على الاستيكرات
global.emojiPack = '💀'           // إيموجي الافتراضي للاستيكرات

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
// 💰 ECONOMY & GAME SETTINGS
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
global.moneda = 'USD'             // العملة المستخدمة في البوت (Dolar/EGP/etc)
global.multiplier = 69            // مضرب الخبرة (XP) - زاد الرقم = XP أسرع
global.maxwarn = '3'              // أقصى عدد تحذيرات قبل الحظر

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
// 📡 CHANNEL & NEWSLETTER SETTINGS
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
global.channel = {
  name: 'ASKRY-BOT Official',                          // اسم القناة
  link: 'https://whatsapp.com/channel/0029Vb6z6NO545v2nTgoBa3I',  // ✅ رابط قناتك
  id: '120363403628890197@newsletter',                // ID القناة (اختياري)
  reg: '120363403628890197@newsletter'                // قناة التسجيل
};

// اختصار للوصول السريع
global.ch = {
  ch1: global.channel.id,
};

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
// 🌐 API KEYS (Optional - Add your keys here)
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
global.APIs = {
  // Example:
  // nrtm: 'https://api.example.com',
};

global.APIKeys = {
  // Example:
  // 'https://api.example.com': 'your_api_key_here',
};

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
// ⚙️ ADVANCED SETTINGS
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
global.opts = {
  // Database
  db: 'json',              // نوع قاعدة البيانات: json/mongodb
  
  // Features
  autocleartmp: true,      // تنظيف مجلد tmp تلقائياً
  autoread: false,         // قراءة الرسائل تلقائياً
  antidelete: true,        // منع حذف الرسائل
  antilink: false,         // منع الروابط في المجموعات
  onlyLatinos: false,      // قبول المستخدمين من أمريكا اللاتينية فقط
  
  // Restrictions
  restrict: false,         // تقييد بعض الأوامر
  self: false,             // وضع الرد على نفسك فقط
  pconly: false,           // الرد في الخاص فقط
  gconly: false,           // الرد في المجموعات فقط
  
  // Queue
  queque: true,            // تفعيل نظام الطابور للرسائل
  quequeTime: 5,           // وقت الانتظار بين الرسائل (ثواني)
  
  // Debug
  debug: false,            // تفعيل وضع التصحيح
  noprint: false,          // عدم طباعة الرسائل في الكونسول
};

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
// 🎮 GAMING SETTINGS (PUBG + Free Fire)
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
global.gaming = {
  enabled: true,
  pubg: {
    lookup: true,          // تفعيل بحث ببجي
    regions: ['AS', 'EU', 'NA']  // المناطق المدعومة
  },
  freefire: {
    lookup: true,          // تفعيل بحث فري فاير
    regions: ['BR', 'AS', 'EU']
  }
};

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
// 🔐 SECURITY SETTINGS
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
global.security = {
  banOnSpam: true,         // حظر عند السبام
  spamThreshold: 10,       // عدد الرسائل قبل الاعتبار سبام
  spamWindow: 60,          // نافذة الوقت بالثواني
  allowedJIDs: [],         // قائمة المستخدمين المسموح لهم فقط (فارغة = الجميع)
  blockedJIDs: [],         // قائمة المستخدمين المحظورين
};

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
// 🎨 HACKER THEME COLORS (For Console)
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
global.colors = {
  cyan: '\x1b[36m',
  green: '\x1b[32m',
  yellow: '\x1b[33m',
  red: '\x1b[31m',
  magenta: '\x1b[35m',
  blue: '\x1b[34m',
  white: '\x1b[37m',
  reset: '\x1b[0m',
  bold: '\x1b[1m'
};

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
// 🔄 AUTO-RELOAD ON CONFIG CHANGE
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
import { watchFile, unwatchFile } from 'fs'
import chalk from 'chalk'
import { fileURLToPath } from 'url'

let file = fileURLToPath(import.meta.url)
watchFile(file, () => {
  unwatchFile(file)
  console.log(chalk.magenta(`[🔄] ${global.bot.emoji.hacker} تم تحديث 'config.js' - إعادة تحميل...`))
  console.log(chalk.cyan(`[ℹ️] Bot: ${global.bot.name} v${global.bot.version}`))
  console.log(chalk.cyan(`[👤] Owner: ${global.owner[0][1]}`))
  import(`${file}?update=${Date.now()}`).catch(console.error)
})

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
// 💀 END OF ASKRY-BOT CONFIG.JS
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━