// plugins/tools/translate.js

import translate from '@vitalets/google-translate-api'

let handler = async (m, { text, command }) => {
  if (!text) return m.reply(`🌐 أرسل النص الذي تريد ترجمته، مثال:\n${command} Hello, how are you?`)

  try {
    let res = await translate(text, { to: 'ar' }) // اللغة العربية
    m.reply(res.text)
  } catch (e) {
    m.reply('❌ حدث خطأ أثناء الترجمة، حاول مرة أخرى لاحقًا.')
    console.error(e)
  }
}

handler.help = ['translate', 'ترجم']
handler.tags = ['tools']
handler.command = /^ترجم|translate$/i

export default handler