import fetch from 'node-fetch';

let handler = async (m, { conn, text, command }) => {
  if (!text) {
    return conn.reply(m.chat, `❌ الرجاء كتابة اسم الرواية أو إرسال رابط حسب الأمر.\n\n📝 أمثلة:\n• .رواية أرض زيكولا\n• .فصول https://www.wattpad.com/story/123456789`, m);
  }

  // 🔎 البحث عن رواية
  if (command === 'رواية') {
    try {
      const res = await fetch(`https://emam-x-api.vercel.app/home/sections/Search/api/Wattpad/search?query=${encodeURIComponent(text)}`);
      const json = await res.json();

      if (!json?.status || !json.results?.length) {
        return conn.reply(m.chat, '❌ لم يتم العثور على نتائج للرواية.', m);
      }

      let result = json.results.slice(0, 10).map((item, i) => `📖 ${i + 1}. ${item.title}\n🔗 ${item.link}`).join('\n\n');
      return conn.reply(m.chat, `🔎 نتائج البحث:\n\n${result}`, m);

    } catch (err) {
      console.error(err);
      return conn.reply(m.chat, '❌ حدث خطأ أثناء البحث. حاول لاحقًا.', m);
    }
  }

  // 📚 عرض الفصول من رابط رواية
  if (command === 'فصول') {
    if (!text.includes('wattpad.com/story/')) {
      return conn.reply(m.chat, '❌ الرجاء إدخال رابط رواية صحيح من Wattpad.', m);
    }

    try {
      const res = await fetch(`https://emam-x-api.vercel.app/home/sections/Search/api/Wattpad/story?url=${encodeURIComponent(text)}`);
      const json = await res.json();

      if (!json?.story?.chapters || !json.story.chapters.length) {
        return conn.reply(m.chat, '❌ لم يتم العثور على فصول لهذه الرواية.', m);
      }

      const title = json.story.title || 'رواية بدون عنوان';
      const author = json.story.author || 'غير معروف';

      const list = json.story.chapters
        .filter(c => (c.title && c.title.length > 2))
        .slice(0, 20) // أول 20 فصل فقط
        .map((c, i) => `📖 ${i + 1}. ${c.title}\n🔗 ${c.link}`).join('\n\n');

      return conn.reply(m.chat, `📚 *${title}*\n✍️ المؤلف: ${author}\n\n${list}`, m);

    } catch (err) {
      console.error(err);
      return conn.reply(m.chat, '❌ حدث خطأ أثناء جلب الفصول.', m);
    }
  }
};

handler.command = ['رواية', 'فصول'];
handler.help = ['رواية <اسم>', 'فصول <رابط_رواية>'];
handler.tags = ['كتب'];

export default handler;