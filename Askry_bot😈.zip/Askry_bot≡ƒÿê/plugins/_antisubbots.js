import { areJidsSameUser } from '@whiskeysockets/baileys'

export async function before(m, { participants, conn }) {
    if (m.isGroup) {
        let chat = global.db.data.chats[m.chat];
        
        // التحقق من تفعيل نظام الحماية
        if (!chat.antiBot2) {
            return;
        }

        // تعريف البوت الرئيسي
        let mainBotJid = global.conn.user.jid;
        
        // إذا كان هذا البوت هو الرئيسي، لا تنفذ أي شيء
        if (areJidsSameUser(mainBotJid, conn.user.jid)) {
            return;
        }
        
        // التحقق من وجود البوت الرئيسي في المجموعة
        let isMainBotPresent = participants.some(p => areJidsSameUser(mainBotJid, p.id));
        
        if (isMainBotPresent) {
            setTimeout(async () => {
                try {
                    // إرسال رسالة المغادرة
                    await conn.sendMessage(m.chat, {
                        text: `🎋 *تنبيه مهم*\n\nتم الكشف عن وجود البوت الرئيسي في هذه المجموعة.\nسأغادر تلقائياً خلال 5 ثوانٍ لتجنب التكرار.\n\nشكراً لتفهمكم!`,
                        mentions: participants.map(p => p.id)
                    }, { quoted: m });
                    
                    // مغادرة المجموعة
                    await conn.groupLeave(m.chat);
                    
                    // تسجيل المغادرة في السجلات
                    console.log(`[BOT PROTECTION] غادرت المجموعة ${m.chat} بسبب وجود البوت الرئيسي`);
                } catch (error) {
                    console.error('حدث خطأ أثناء مغادرة المجموعة:', error);
                }
            }, 5000); // تأخير 5 ثوانٍ
        }
    }
}