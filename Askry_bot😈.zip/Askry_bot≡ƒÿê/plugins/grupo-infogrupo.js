const handler = async (m, { conn, participants, groupMetadata }) => {
  const pp = await conn.profilePictureUrl(m.chat, 'image').catch((_) => global.icono)
  const {
    antiLink,
    detect,
    welcome,
    modoadmin,
    autoRechazar,
    nsfw,
    autoAceptar,
    reaction,
    isBanned,
    antifake
  } = global.db.data.chats[m.chat]
  const groupAdmins = participants.filter((p) => p.admin)
  const listAdmin = groupAdmins.map((v, i) => `${i + 1}. @${v.id.split('@')[0]}`).join('\n')
  const owner = groupMetadata.owner || groupAdmins.find((p) => p.admin === 'superadmin')?.id || m.chat.split`-`[0] + '@s.whatsapp.net'
  const text = `*✧･ﾟ معلومات المجموعة ﾟ･✧*
❀ *المعرف:* ${groupMetadata.id}
⚘ *الاسم:* ${groupMetadata.subject}
❖ *الأعضاء:* ${participants.length} عضو
✰ *المنشئ:* @${owner.split('@')[0]}
✥ *المدراء:*
${listAdmin}

˚₊· ͟͟͞͞➳❥ *الإعدادات الحالية*

◈ *${botname}* » ${isBanned ? 'معطل' : 'مفعل'}
◈ *الترحيب:* ${welcome ? 'مفعل' : 'معطل'}
◈ *الكشف:* ${detect ? 'مفعل' : 'معطل'}  
◈ *الحماية من الروابط:* ${antiLink ? 'مفعل' : 'معطل'} 
◈ *القبول التلقائي:* ${autoAceptar ? 'مفعل' : 'معطل'}
◈ *الرفض التلقائي:* ${autoRechazar ? 'مفعل' : 'معطل'}
◈ *NSFW:* ${nsfw ? 'مفعل' : 'معطل'}
◈ *وضع المدير فقط:* ${modoadmin ? 'مفعل' : 'معطل'}
◈ *الردود التلقائية:* ${reaction ? 'مفعل' : 'معطل'}
◈ *الحماية من الأرقام المزيفة:* ${antifake ? 'مفعل' : 'معطل'}

✦ *الوصف:*
${groupMetadata.desc?.toString() || 'لا يوجد وصف للمجموعة'}`.trim()

  conn.sendFile(m.chat, pp, 'img.jpg', text, m, false, {
    mentions: [...groupAdmins.map((v) => v.id), owner]
  })
}
handler.help = ['كشف القروب']
handler.tags = ['مجموعة']
handler.command = ['infogrupo', 'gp', 'معلومات_المجموعة']
handler.register = true
handler.group = true

export default handler