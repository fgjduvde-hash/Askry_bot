const المهلة = 60000;
const النقاط = 500;
const فقدان_النقاط = -100;
const نقاط_البوت = 200;

const المعالج = async (m, {conn, usedPrefix, text}) => {
  conn.suit = conn.suit ? conn.suit : {};
  
  const المستخدم_المتحدي = m.mentionedJid[0] || (m.replyMessage && m.replyMessage.sender);
  
  if (Object.values(conn.suit).find((غرفة) => غرفة.id.startsWith('suit') && [غرفة.p, غرفة.p2].includes(m.sender))) throw `❌ انهي لعبتك الحالية قبل أن تبدأ أخرى.`;
  
  const نص_التحدي = `🎮 من تريد أن تتحداه؟ قم بوضع علامة على مستخدم.\n\n*—◉ مثال:*\n${usedPrefix}suit @اسم_المستخدم`;
  
  if (!المستخدم_المتحدي) return m.reply(nص_التحدي, m.chat, {mentions: conn.parseMention(nص_التحدي)});
  
  if (Object.values(conn.suit).find((غرفة) => غرفة.id.startsWith('suit') && [غرفة.p, غرفة.p2].includes(المستخدم_المتحدي))) throw `❌ هذا المستخدم لا يزال في لعبة، انتظر حتى تنتهي للعب.`;
  
  const المعرف = 'suit_' + new Date() * 1;
  const الوصف = `🎮 ألعاب - لاعب ضد لاعب 🎮\n\n—◉ @${m.sender.split`@`[0]} يتحدى @${المستخدم_المتحدي.split`@`[0]} في لعبة حجر ورق مقص\n◉ اكتب "قبول" للموافقة\n◉ اكتب "رفض" للرفض\nرداً على هذه الرسالة`;
  const صورة_اللعب = `https://www.merca2.es/wp-content/uploads/2020/05/Piedra-papel-o-tijera-0003318_1584-825x259.jpeg`;
  
  conn.suit[المعرف] = {
    chat: await conn.sendMessage(m.chat, {text: الوصف, mentions: [m.sender, المستخدم_المتحدي]}, {caption: الوصف}),
    id: المعرف,
    p: m.sender,
    p2: المستخدم_المتحدي,
    status: 'انتظار',
    وقت: setTimeout(() => {
      if (conn.suit[المعرف]) conn.reply(m.chat, `⏳ انتهى وقت الانتظار، تم إلغاء اللعبة لعدم الرد.`, m);
      delete conn.suit[المعرف];
    }, المهلة),
    النقاط, فقدان_النقاط, نقاط_البوت, المهلة,
  };
};

المعالج.command = ['suitpvp', 'pvp', 'suit'];
المعالج.group = true;
المعالج.register = true;
المعالج.game = true;

export default المعالج;