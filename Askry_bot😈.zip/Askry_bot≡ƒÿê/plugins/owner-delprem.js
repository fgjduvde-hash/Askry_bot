const handler = async (m, {conn, text, usedPrefix, command}) => {
  let who;
  if (m.isGroup) who = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : false;
  else who = m.chat;
  const user = global.db.data.users[who];
  if (!who) throw `${emoji} قم بمنشن الشخص الذي تريد إزالة ميزة البريميوم منه.`;
  if (!user) throw `${emoji4} المستخدم غير موجود في قاعدة البيانات.`;
  if (user.premiumTime = 0) throw `${emoji2} المستخدم ليس بريميوم. 👑`;
  const txt = text.replace('@' + who.split`@`[0], '').trim();

  user.premiumTime = 0;
  user.premium = false;

  const textdelprem = `@${who.split`@`[0]} لم يعد مستخدمًا بريميوم. 👑`;
  m.reply(textdelprem, null, {mentions: conn.parseMention(textdelprem)});
};
handler.help = ['ديلي برايم <@شخص>'];
handler.tags = ['المالك'];
handler.command = ['remove', 'ديلي برايم']
handler.group = true;
handler.rowner = true;

export default handler;