let handler = async (m, { conn }) => {
  // ✨ رابط الصورة (تقدر تغيره متى ما تحب)
  const imageURL = 'https://files.catbox.moe/f0pzgn.jpg'

  // 📝 نص الاستمارة
  let text = `
*🤖┇╾⪼ قــســم الـذكــاء الاصـطـنـاعــي*  

> ⩺ ⌟.gpt — تحدث مع الذكاء الاصطناعي  
> ⩺ ⌟.dalle • .draw — توليد صور من نص  
> ⩺ ⌟.codegpt — توليد أكواد برمجية  
> ⩺ ⌟.img2prompt — تحليل صورة ووصفها  
> ⩺ ⌟.styleai — تحويل الصور إلى ستايل أنمي  
> ⩺ ⌟.voicegpt — تحدث صوتيًا مع GPT  
> ⩺ ⌟.describe — وصف ذكي للصور  
> ⩺ ⌟.aiconvert — تحويل كود من لغة إلى أخرى  
> ⩺ ⌟.aicodefix — تصحيح أكواد برمجية  
> ⩺ ⌟.qrtext — قراءة وتحليل كود QR  

*🎀┇لا تنسى كتابة (.) قبل كل أمر لاستخدامه!*
`.trim()

  // ✅ إرسال الصورة مع النص
  await conn.sendMessage(m.chat, {
    image: { url: imageURL },
    caption: text,
    mentions: [m.sender]
  }, { quoted: m })
}

handler.help = ['س1']
handler.tags = ['sections']
handler.command = /^س1$/i

export default handler