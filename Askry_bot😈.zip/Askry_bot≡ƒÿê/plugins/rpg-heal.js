let المعالج = async (m, { conn }) => {
    let المستخدم = global.db.data.users[m.sender];
    if (!المستخدم) {
        return conn.reply(m.chat, `${emoji} المستخدم غير موجود في قاعدة البيانات.`, m);
    }
    if (المستخدم.coin < 50) {
        return conn.reply(m.chat, `💔 رصيدك غير كافٍ للشفاء. تحتاج على الأقل 50.`, m);
    }
    let كمية_الشفاء = 50; 
    المستخدم.health += كمية_الشفاء;
    المستخدم.coin -= 50; 
    if (المستخدم.health > 100) {
        المستخدم.health = 100; 
    }
    المستخدم.lastHeal = new Date();
    let معلومات = `❤️ *لقد شُفيت بمقدار ${كمية_الشفاء} نقطة صحة.*\n💸 *${عملة} المتبقية:* ${المستخدم.coin}\n❤️ *الصحة الحالية:* ${المستخدم.health}`;
    await conn.sendMessage(m.chat, { text: معلومات }, { quoted: m });
};

المعالج.help = ['شفاء'];
المعالج.tags = ['rpg'];
المعالج.command = ['شفاء', 'curar'];
المعالج.group = true;
المعالج.register = true;

export default المعالج;