const handler = async (m, { conn }) => {
  const المستخدم = global.db.data.users[m.sender];
  const عشوائي1 = `${Math.floor(Math.random() * 5)}`;
  const عشوائي2 = `${Math.floor(Math.random() * 5)}`;
  const عشوائي3 = `${Math.floor(Math.random() * 5)}`;
  const عشوائي4 = `${Math.floor(Math.random() * 5)}`;
  const عشوائي5 = `${Math.floor(Math.random() * 5)}`;
  const عشوائي6 = `${Math.floor(Math.random() * 5)}`;
  const عشوائي7 = `${Math.floor(Math.random() * 5)}`;
  const عشوائي8 = `${Math.floor(Math.random() * 5)}`;
  const عشوائي9 = `${Math.floor(Math.random() * 5)}`;
  const عشوائي10 = `${Math.floor(Math.random() * 5)}`;
  const عشوائي11 = `${Math.floor(Math.random() * 5)}`;
  const عشوائي12 = `${Math.floor(Math.random() * 5)}`.trim();

  const رقم1 = (عشوائي1 * 1);
  const رقم2 = (عشوائي2 * 1);
  const رقم3 = (عشوائي3 * 1);
  const رقم4 = (عشوائي4 * 1);
  const رقم5 = (عشوائي5 * 1);
  const رقم6 = (عشوائي6 * 1);
  const رقم7 = (عشوائي7 * 1);
  const رقم8 = (عشوائي8 * 1);
  const رقم9 = (عشوائي9 * 1);
  const رقم10 = (عشوائي10 * 1);
  const رقم11 = (عشوائي11 * 1);
  const رقم12 = (عشوائي12 * 1);

  const ن1 = `${رقم1}`;
  const ن2 = `${رقم2}`;
  const ن3 = `${رقم3}`;
  const ن4 = `${رقم4}`;
  const ن5 = `${رقم5}`;
  const ن6 = `${رقم6}`;
  const ن7 = `${رقم7}`;
  const ن8 = `${رقم8}`;
  const ن9 = `${رقم9}`;
  const ن10 = `${رقم10}`;
  const ن11 = `${رقم11}`;
  const ن12 = `${رقم12}`;

  const س1 = `${['🪚','⛏️','🧨','💣','🔫','🔪','🗡️','🏹','🦾','🥊','🧹','🔨','🛻'].getRandom()}`;
  const س2 = `${['🪚','⛏️','🧨','💣','🔫','🔪','🗡️','🏹','🦾','🥊','🧹','🔨','🛻'].getRandom()}`;
  const س3 = `${['🪚','⛏️','🧨','💣','🔫','🔪','🗡️','🏹','🦾','🥊','🧹','🔨','🛻'].getRandom()}`;
  const س4 = `${['🪚','⛏️','🧨','💣','🔫','🔪','🗡️','🏹','🦾','🥊','🧹','🔨','🛻'].getRandom()}`;
  const س5 = `${['🪚','⛏️','🧨','💣','🔫','🔪','🗡️','🏹','🦾','🥊','🧹','🔨','🛻'].getRandom()}`;
  const س6 = `${['🪚','⛏️','🧨','💣','🔫','🔪','🗡️','🏹','🦾','🥊','🧹','🔨','🛻'].getRandom()}`;
  const س7 = `${['🪚','⛏️','🧨','💣','🔫','🔪','🗡️','🏹','🦾','🥊','🧹','🔨','🛻'].getRandom()}`;
  const س8 = `${['🪚','⛏️','🧨','💣','🔫','🔪','🗡️','🏹','🦾','🥊','🧹','🔨','🛻'].getRandom()}`;
  const س9 = `${['🪚','⛏️','🧨','💣','🔫','🔪','🗡️','🏹','🦾','🥊','🧹','🔨','🛻'].getRandom()}`;
  const س10 = `${['🪚','⛏️','🧨','💣','🔫','🔪','🗡️','🏹','🦾','🥊','🧹','🔨','🛻'].getRandom()}`;
  const س11 = `${['🪚','⛏️','🧨','💣','🔫','🔪','🗡️','🏹','🦾','🥊','🧹','🔨','🛻'].getRandom()}`;
  const س12 = `${['🪚','⛏️','🧨','💣','🔫','🔪','🗡️','🏹','🦾','🥊','🧹','🔨','🛻'].getRandom()}`;

  const النتيجة = `
*✧ نتائج الصيد ${conn.getName(m.sender)} ✧*

 *🐂 ${س1} ${ن1}*			 *🐃 ${س7} ${ن7}*
 *🐅 ${س2} ${ن2}*			 *🐮 ${س8} ${ن8}*
 *🐘 ${س3} ${ن3}*			 *🐒 ${س9} ${ن9}*
 *🐐 ${س4} ${ن4}*			 *🐗 ${س10} ${ن10}*
 *🐼 ${س5} ${ن5}*			 *🐖 ${س11} ${ن11}*
 *🐊 ${س6} ${ن6}*		    *🐓 ${س12} ${ن12}*`.trim();

  المستخدم.banteng += رقم1;
  المستخدم.harimau += رقم2;
  المستخدم.gajah += رقم3;
  المستخدم.kambing += رقم4;
  المستخدم.panda += رقم5;
  المستخدم.buaya += رقم6;
  المستخدم.kerbau += رقم7;
  المستخدم.sapi += رقم8;
  المستخدم.monyet += رقم9;
  المستخدم.babihutan += رقم10;
  المستخدم.babi += رقم11;
  المستخدم.ayam += رقم12;

  const الوقت = المستخدم.lastberburu + 2700000;
  if (new Date - المستخدم.lastberburu < 2700000) return conn.reply(m.chat, `من فضلك انتظر قليلًا قبل أن تصطاد مرة أخرى\n\n⫹⫺ الوقت المتبقي ${clockString(الوقت - new Date())}\n${wm}`, m);

  setTimeout(() => {
    conn.reply(m.chat, النتيجة, m);
  }, 20000);

  setTimeout(() => {
    conn.reply(m.chat, `@${m.sender.split('@s.whatsapp.net')[0]} *${['الهدف محدد 🎯', 'جذب الطُعم 🍫 🍇 🍖', 'تم رصد الحيوانات!! 🐂 🐅 🐘 🐼', 'تم رصد الحيوانات!! 🐖 🐃 🐮 🐒'].getRandom()}*`, null, { mentions: [m.sender] });
  }, 18000);

  setTimeout(() => {
    conn.reply(m.chat, `@${m.sender.split('@s.whatsapp.net')[0]} *${['الأسلحة جاهزة للصيد!!', 'جاري اختبار الأسلحة 🔫 💣 🪓 🏹', 'المركبات جاهزة للصيد 🚗 🏍️ 🚜', 'الجو مثالي للصيد 🧤'].getRandom()}*`, null, { mentions: [m.sender] });
  }, 15000);

  setTimeout(() => {
    conn.reply(m.chat, `@${m.sender.split('@s.whatsapp.net')[0]} *${['جارٍ تجهيز معدات الصيد...', 'جارٍ التحضير الكامل للصيد!!', 'تحديد موقع الصيد...', 'جارٍ تجهيز مكان الصيد!!'].getRandom()}*`, m, m.mentionedJid ? { mentions: [m.sender] } : {});
  }, 0);

  المستخدم.lastberburu = new Date * 1;
};

handler.help = ['لعبة مطاردة'];
handler.tags = ['rpg'];
handler.command = ['مطاردة', 'hunt', 'berburu'];
handler.group = true;
handler.register = true;

export default handler;

function clockString(ms) {
  const h = Math.floor(ms / 3600000);
  const m = Math.floor(ms / 60000) % 60;
  const s = Math.floor(ms / 1000) % 60;
  return [h, m, s].map(v => v.toString().padStart(2, 0)).join(':');
}

