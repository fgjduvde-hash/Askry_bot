let handler = async (m, { conn }) => {
  const imageURL = 'https://files.catbox.moe/a0u9hc.jpg'

  let text = `
*📜┇╾⪼ قسم النثر والأدب*

> ⩺ ⌟.قصيدة — عرض قصيدة عشوائية  
> ⩺ ⌟.اقتباس — اقتباسات مميزة  
> ⩺ ⌟.حكمة — حكم وأقوال مأثورة  
> ⩺ ⌟.مقال — مقالات أدبية  
> ⩺ ⌟.قصة — قصة قصيرة  
> ⩺ ⌟.أدب_حديث — أدب معاصر  
> ⩺ ⌟.خواطر — خواطر ونصوص  

*🎀┇لا تنسَ كتابة (.) قبل كل أمر لاستخدامه!*
`.trim()

  await conn.sendMessage(m.chat, {
    image: { url: imageURL },
    caption: text,
    mentions: [m.sender]
  }, { quoted: m })
}

handler.help = ['س11']
handler.tags = ['menu']
handler.command = /^س11$/i

export default handler