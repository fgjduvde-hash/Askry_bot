let linkRegex = /chat.whatsapp.com\/([0-9A-Za-z]{20,24})/i;
let linkRegex1 = /whatsapp.com\/channel\/([0-9A-Za-z]{20,24})/i;

export async function before(m, { conn, isAdmin, isBotAdmin, isOwner, isROwner, participants }) {
    
    if (!m.isGroup) return;
    if (isAdmin || isOwner || m.fromMe || isROwner) return;

    let chat = global.db.data.chats[m.chat];
    let delet = m.key.participant;
    let bang = m.key.id;
    const user = `@${m.sender.split`@`[0]}`;
    const groupAdmins = participants.filter(p => p.admin);
    const listAdmin = groupAdmins.map((v, i) => `*» ${i + 1}. @${v.id.split('@')[0]}*`).join('\n');
    let bot = global.db.data.settings[conn.user.jid] || {};
    const isGroupLink = linkRegex.exec(m.text) || linkRegex1.exec(m.text);
    const grupo = `https://chat.whatsapp.com`;
    
    if (chat.antilink && isGroupLink && !isAdmin) {
        if (isBotAdmin) {
            const linkThisGroup = `https://chat.whatsapp.com/${await this.groupInviteCode(m.chat)}`;
            if (m.text.includes(linkThisGroup)) return !0;
        }
        
        // رسالة التحذير بالعربية مع تعديلات
        await conn.sendMessage(m.chat, { 
            text: `❌ *انتهاك القوانين!*\n\nتم اكتشاف رابط مجموعة من:\n${user}\n\n⚡ *العقوبة:*\n- تم طرد العضو من المجموعة\n\n📌 *ملاحظة:*\nممنوع مشاركة روابط مجموعات أخرى!`,
            mentions: [m.sender] 
        }, { 
            quoted: m, 
            ephemeralExpiration: 24*60*100, 
            disappearingMessagesInChat: 24*60*100 
        });

        if (isBotAdmin) {
            // حذف الرسالة الأصلية
            await conn.sendMessage(m.chat, { 
                delete: { 
                    remoteJid: m.chat, 
                    fromMe: false, 
                    id: bang, 
                    participant: delet 
                } 
            });
            
            // طرد العضو مع معالجة الأخطاء
            try {
                let responseb = await conn.groupParticipantsUpdate(m.chat, [m.sender], 'remove');
                if (responseb[0].status === "404") {
                    await conn.sendMessage(m.chat, { 
                        text: `⚠️ تعذر طرد ${user} لأن الحساب غير موجود أو تم حظره مسبقاً`,
                        mentions: [m.sender]
                    });
                }
            } catch (error) {
                console.error('حدث خطأ أثناء الطرد:', error);
                await conn.sendMessage(m.chat, { 
                    text: `❌ حدث خطأ أثناء محاولة طرد ${user}`,
                    mentions: [m.sender]
                });
            }
        } else {
            await conn.sendMessage(m.chat, {
                text: `⚠️ تم اكتشاف رابط مجموعة من:\n${user}\n\nلكنني لست مشرفاً لأتمكن من طرده!`,
                mentions: [m.sender]
            });
        }
    } 
    return !0;
}