/*
《✧》جميع الحقوق محفوظة للمؤلف《✧》
- GabrielVz (@glytglobal)
*/

import fetch from 'node-fetch'

let handler = async (m, { text, usedPrefix, command }) => {

if (!text) return conn.reply(m.chat, `${emoji} اكتب اسم السكريبر.\nمثال: ${usedPrefix + command} yt-search`, m)

try {

await m.react(rwait)
conn.reply(m.chat, `${emoji2} جاري البحث عن السكريبر....`, m)

let res = await fetch(`http://registry.npmjs.com/-/v1/search?text=${text}`)
let { objects } = await res.json()

if (!objects.length) return conn.reply(m.chat, `${emoji2} لم يتم العثور على نتائج لـ: ${text}`, m)

let txt = objects.map(({ package: pkg }) => {
return `《✧》 بحث عن سكريبر 《✧》

✦ الاسم: ${pkg.name}
✦ الإصدار: V${pkg.version}
✦ الرابط: ${pkg.links.npm}
✦ الوصف: ${pkg.description}
\n\n----------`
}).join`\n\n`

await conn.reply(m.chat, txt, m, fake)
await m.react(done)
} catch {
await conn.reply(m.chat, `${msm} حدث خطأ ما.`, m)
await m.react(error)
}}

handler.help = ['npmjs']
handler.tags = ['محرك بحث']
handler.command = ['npmjs', 'سكريبر']
handler.register = true
handler.coin = 1

export default handler