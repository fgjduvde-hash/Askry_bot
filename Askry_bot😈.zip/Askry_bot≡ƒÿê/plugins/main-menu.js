// plugins/main/menu.js
// ╔════════════════════════════════════════════════════════════════╗
// ║  💎 ASKRY-BOT - LUXURY MENU - HACKER EDITION 💎               ║
// ║  Author: Al Askry | Telegram: @askry47 | © 2026               ║
// ╚════════════════════════════════════════════════════════════════╝

let handler = async (m, { conn, usedPrefix, command }) => {
  let userId = m.sender
  let name = await conn.getName(userId)

  let dateObj = new Date()
  let currentTime = dateObj.toLocaleTimeString('ar-EG', { hour12: true })
  let currentDate = dateObj.toLocaleDateString('ar-EG')
  let groupName = m.isGroup ? (await conn.groupMetadata(m.chat)).subject : 'خاص'

  // 💎 الزخرفة الفاخرة
  let z1 = '╭━━━━━━━━━━━━━━━⊰💀⊱━━━━━━━━━━━━━━━╮'
  let z2 = '┃'
  let z3 = '╰━━━━━━━━━━━━━━━⊰💀⊱━━━━━━━━━━━━━━━╯'
  let z4 = '═'.repeat(35)
  let z5 = '─'.repeat(33)
  let z6 = '✦'.repeat(17)
  let z7 = '◈'.repeat(17)
  let z8 = '◆'.repeat(17)
  let z9 = '◇'.repeat(17)
  let z10 = '⊰•••⊱'

  let text = `
${z1}
${z2} ${' '.repeat(28)} ${z2}
${z2}   💀 𝐀𝐒𝐊𝐑𝐘-𝐁𝐎𝐓 💀   ${z2}
${z2}   ${'𝐋𝐔𝐗𝐔𝐑𝐘 𝐇𝐀𝐂𝐊𝐄𝐑 𝐄𝐃𝐈𝐓𝐈𝐎𝐍'}   ${z2}
${z2} ${' '.repeat(28)} ${z2}
${z3}

${z2} ${z10} 👋 مرحباً بك يا ${name} 👋 ${z10} ${z2}
${z2} ${z10} 💀 في بوت المطور: عسكري 💀 ${z10} ${z2}
${z2} ${z5} ${z2}

${z2} 🔐 ${' '.repeat(2)} *مـعـلـومـات الـحـسـاب* ${' '.repeat(2)} 🔐 ${z2}
${z2} ${z5} ${z2}
${z2} 👤 المستخدم: @${userId.split('@')[0]} ${z2}
${z2} ⏱️ الوقت: ${currentTime} ${z2}
${z2} 📆 التاريخ: ${currentDate} ${z2}
${z2} 💬 المجموعة: ${groupName} ${z2}
${z2} ${z5} ${z2}

${z2} 🎮 ${' '.repeat(3)} *قـوائـم الـبـوت الـفـاخـرة* ${' '.repeat(3)} 🎮 ${z2}
${z2} ${z4} ${z2}
${z2} ${z8} ${z2}
${z2} 🤖 ${z10} ⌟.س1⌜ 𖢿 *الذكاء الاصطناعي* ${z2}
${z2} 🎮 ${z10} ⌟.س2⌜ 𖤊 *ألعاب PUBG & Free Fire* ${z2}
${z2} 🛠️ ${z10} ⌟.س3⌜ 𖣋 *أدوات & خدمات* ${z2}
${z2} 🔍 ${z10} ⌟.س4⌜ 𖣲 *بحث & جلب* ${z2}
${z2} 📚 ${z10} ⌟.س5⌜ 𖣕 *فروع & تحكم* ${z2}
${z2} 💡 ${z10} ⌟.س6⌜ 𖤗 *ترفيه & ميديا* ${z2}
${z2} ✍️ ${z10} ⌟.س7⌜ 𖤤 *زخرفة & تصميم* ${z2}
${z2} 🧮 ${z10} ⌟.س8⌜ 𖥕 *حسابات & عمليات* ${z2}
${z2} 📊 ${z10} ⌟.س9⌜ 𖥡 *أدمن & جروبات* ${z2}
${z2} 🎭 ${z10} ⌟.س10⌜ 𖦜 *شخصيات & بروفايل* ${z2}
${z2} 📜 ${z10} ⌟.س11⌜ 𖦤 *نثر & أدب* ${z2}
${z2} ☕ ${z10} ⌟.س12⌜ 𖧶 *نخبة & خاص* ${z2}
${z2} 🎸 ${z10} ⌟.س13⌜ 𖦏 *أغاني & صوتيات* ${z2}
${z2} ${z8} ${z2}
${z2} ${z4} ${z2}

${z2} 💎 ${' '.repeat(4)} *روابـط هـامـة* ${' '.repeat(4)} 💎 ${z2}
${z2} ${z4} ${z2}
${z2} 👑 المطور: Al Askry | عسكري 👑 ${z2}
${z2} 📡 تليجرام: @askry47 ${z2}
${z2} ${z5} ${z2}
${z2} 📡 ${z10} ${z10} ${z10} ${z10} ${z10} ${z10} 📡 ${z2}
${z2} 🔗 *قـنـاة آلَبـوت الـرسـمـيـة* 🔗 ${z2}
${z2} 🎁 *جوائز • تحديثات • حصرية* 🎁 ${z2}
${z2} 👇 *انـضـم الآن* 👇 ${z2}
${z2} 🔗 https://whatsapp.com/channel/0029Vb6z6NO545v2nTgoBa3I 🔗 ${z2}
${z2} 📡 ${z10} ${z10} ${z10} ${z10} ${z10} ${z10} 📡 ${z2}
${z2} ${z5} ${z2}

${z2} 💡 *ملاحظة: اكتب (.مطور) لمعلومات أكثر* 💡 ${z2}
${z2} 🔐 *اكتب الأمر قبل كل كلمة: .اوامر* 🔐 ${z2}
${z2} ${' '.repeat(28)} ${z2}
${z3}

${z2} ${z6} ${z2}
${z2} 💀 © 2026 Al Askry - All Rights Reserved 💀 ${z2}
${z2} ${z6} ${z2}
${z1}
`.trim()

  // 💎 صورة المنيو الفاخرة - غير الرابط لو عايز صورتك
  let imageURL = 'https://files.catbox.moe/l2hw9y.jpg'

  await conn.sendMessage(m.chat, {
    image: { url: imageURL },
    caption: text,
    mentions: [userId],
    contextInfo: {
      forwardingScore: 999,
      isForwarded: true,
      forwardedNewsletterMessageInfo: {
        newsletterJid: '120363403628890197@newsletter',
        newsletterName: 'ASKRY-BOT Official',
        serverMessageId: -1
      }
    }
  }, { quoted: m })
}

handler.help = ['menu', 'help', 'اوامر', 'قائمة', 'askry', 'فخم']
handler.tags = ['main', 'askry', 'luxury']
handler.command = /^(menu|help|اوامر|قائمة|قائمة الاوامر|askry|فخم|فاخر)$/i
handler.limit = false
handler.register = false

// 💎 ASKRY-BOT LUXURY EDITION © 2026 Al Askry 💎
export default handler