// plugins/tools/channel-id.js
// 💀 ASKRY-BOT - Channel Info Tool - By Al Askry

let handler = async (m, { text, conn, usedPrefix, command }) => {
  if (!text) return m.reply(`💀 يرجى إرسال رابط القناة.\n\nمثال:\n${usedPrefix + command} https://whatsapp.com/channel/0029Vb6z6NO545v2nTgoBa3I`);
  if (!text.includes('https://whatsapp.com/channel/')) return m.reply('❌ الرابط غير صالح، تأكد أنه رابط قناة WhatsApp.');

  try {
    let code = text.split('https://whatsapp.com/channel/')[1];
    let res = await conn.newsletterMetadata('invite', code);

    let info = `💀 *ASKRY BOT - قناة معلومات*\n\n` +
               `🆔 *ID:* ${res.id}\n` +
               `📛 *الاسم:* ${res.name}\n` +
               `👥 *المشتركين:* ${res.subscribers}\n` +
               `📶 *الحالة:* ${res.state}\n` +
               `✅ *موثقة:* ${res.verification === 'VERIFIED' ? 'نعم ✅' : 'لا ❌'}\n\n` +
               `🔐 *بواسطة:* Al Askry 👑\n` +
               `📡 *قناتنا:* https://whatsapp.com/channel/0029Vb6z6NO545v2nTgoBa3I`;

    await m.reply(info);
  } catch (e) {
    console.error(e);
    m.reply('💀 حدث خطأ أثناء جلب البيانات، تأكد من صحة الرابط أو أعد المحاولة لاحقًا.\n\n📡 للدعم: @askry47');
  }
};

handler.command = ['id', 'channelid', 'قناة', 'info'];
handler.help = ['channelid <رابط_القناة>'];
handler.tags = ['tools', 'askry'];
handler.limit = true;

// 💀 ASKRY-BOT © 2026 Al Askry
export default handler;