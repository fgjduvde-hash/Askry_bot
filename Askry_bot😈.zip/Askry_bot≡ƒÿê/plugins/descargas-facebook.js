import { igdl } from 'ruhend-scraper'

const handler = async (m, { text, conn, args }) => {
  if (!args[0]) {
    return conn.reply(m.chat, `${emoji} من فضلك أدخل رابط فيسبوك.`, m)
  }

  let res;
  try {
    await m.react(rwait);
    res = await igdl(args[0]);
  } catch (e) {
    return conn.reply(m.chat, `${msm} خطأ في جلب البيانات. يرجى التحقق من الرابط.`, m)
  }

  let result = res.data;
  if (!result || result.length === 0) {
    return conn.reply(m.chat, `${emoji2} لم يتم العثور على نتائج.`, m)
  }

  let data;
  try {
    data = result.find(i => i.resolution === "720p (HD)") || result.find(i => i.resolution === "360p (SD)");
  } catch (e) {
    return conn.reply(m.chat, `${msm} خطأ في معالجة البيانات.`, m)
  }

  if (!data) {
    return conn.reply(m.chat, `${emoji2} لم يتم العثور على دقة مناسبة.`, m)
  }

  let video = data.url;
  try {
    await conn.sendMessage(m.chat, { 
      video: { url: video }, 
      caption: `${emoji} هذا هو الفيديو الخاص بك ฅ^•ﻌ•^ฅ.`, 
      fileName: 'fb.mp4', 
      mimetype: 'video/mp4' 
    }, { quoted: m })
    await m.react(done);
  } catch (e) {
    return conn.reply(m.chat, `${msm} خطأ في إرسال الفيديو.`, m)
    await m.react(error);
  }
}

handler.help = ['facebook', 'fb', 'فيسبوك']
handler.tags = ['تحميلات']
handler.command = ['facebook', 'fb', 'فيسبوك']
handler.group = true;
handler.register = true;
handler.coin = 2;

export default handler