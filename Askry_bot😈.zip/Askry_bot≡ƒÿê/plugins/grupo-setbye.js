let handler = async (m, { conn, text }) => {
  const emoji = '⚠️'; // رمز تحذير أو تقدر تغيّره
  if (!text) return m.reply(`${emoji} الرجاء كتابة رسالة وداع للبوت.\n> مثال: #setbye وداعاً @user`);

  global.welcom2 = text.trim();

  m.reply(`${emoji} تم تغيير رسالة وداع البوت إلى: ${global.welcom2}`);
};

handler.help = ['تعيين_وداع'];
handler.tags = ['أدوات'];
handler.command = ['setbye'];
handler.owner = false;
handler.admin = true;

export default handler;