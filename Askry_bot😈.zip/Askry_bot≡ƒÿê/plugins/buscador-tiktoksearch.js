import axios from 'axios';
import { fileTypeFromBuffer } from 'file-type';
import fetch from 'node-fetch';
const { generateWAMessageContent } = (await import("@whiskeysockets/baileys")).default;

let handler = async (message, { conn, text }) => {
  if (!text) return conn.reply(message.chat, "❀ من فضلك أدخل كلمة للبحث في تيك توك.", message);

  try {
    await conn.reply(message.chat, '✧ *جارٍ البحث عن النتائج...*', message);

    const { data } = await axios.get("https://apis-starlights-team.koyeb.app/starlight/tiktoksearch?text=" + encodeURIComponent(text));
    const results = data.data;

    if (!results || results.length === 0) {
      return conn.reply(message.chat, "❌ لم يتم العثور على نتائج.", message);
    }

    const topResults = results.slice(0, 4); // نرسل أول 4 فقط

    for (const result of topResults) {
      const videoUrl = result.nowm;
      const title = result.title;

      const response = await fetch(videoUrl);
      const buffer = await response.buffer();
      const fileInfo = await fileTypeFromBuffer(buffer);
      const ext = fileInfo ? fileInfo.ext : 'mp4';

      await conn.sendFile(
        message.chat,
        buffer,
        `tiktok.${ext}`,
        `🎬 *${title}*`,
        message
      );
    }
  } catch (err) {
    console.error(err);
    conn.reply(message.chat, `⚠︎ حدث خطأ أثناء جلب النتائج:\n${err.message}`, message);
  }
};

handler.help = ["tiktoksearch <كلمة>"];
handler.tags = ["محرك بحث"];
handler.command = ["tiktoksearch", "ttss", "tiktoks", "بحثتيكتوك"];
handler.register = true;
handler.group = false; // يعمل في الخاص والمجموعات

export default handler;