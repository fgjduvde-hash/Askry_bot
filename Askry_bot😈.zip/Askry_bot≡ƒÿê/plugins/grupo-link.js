var handler = async (m, { conn, args }) => {

  let group = m.chat
  let link = 'https://chat.whatsapp.com/' + await conn.groupInviteCode(group)
  conn.reply(m.chat, '\t\t✿:･✧ رابط المجموعة ✧･:✿\n\n\v' + link, m, { detectLink: true })

}
handler.help = ['لينك']
handler.tags = ['المجموعة']
handler.command = ['الرابط', 'رابط']
handler.group = true
handler.botAdmin = true

export default handler