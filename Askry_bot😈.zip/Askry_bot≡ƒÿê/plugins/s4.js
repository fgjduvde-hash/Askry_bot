let handler = async (m, { conn }) => {
  const imageURL = 'https://files.catbox.moe/zxoudc.jpg'

  let text = `
*🔍┇╾⪼ قــســم آلَبــحــث*

> ⩺ ⌟.tiktoksearch — بحث تيك توك
> ⩺ ⌟.ytsearch — بحث يوتيوب
> ⩺ ⌟.google — بحث جوجل
> ⩺ ⌟.githubsearch — بحث GitHub
> ⩺ ⌟.pin — بحث Pinterest
> ⩺ ⌟.tweetposts — بحث تويتر
> ⩺ ⌟.cuevana — بحث Cuevana
> ⩺ ⌟.xnxxsearch — بحث XNXX
> ⩺ ⌟.pornhubsearch — بحث Pornhub

*🎀┇لا تنسى كتابة (.) قبل كل أمر لاستخدامه!*
`.trim()

  await conn.sendMessage(m.chat, {
    image: { url: imageURL },
    caption: text,
    mentions: [m.sender]
  }, { quoted: m })
}

handler.help = ['س4']
handler.tags = ['menu']
handler.command = /^س4$/i

export default handler