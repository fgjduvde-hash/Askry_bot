import { promises as fs } from 'fs'

const مسار_الشخصيات = './src/database/characters.json'
const مسار_الحريم = './src/database/harem.json'

async function تحميل_الشخصيات() {
    try {
        const البيانات = await fs.readFile(مسار_الشخصيات, 'utf-8')
        return JSON.parse(البيانات)
    } catch (خطأ) {
        throw new Error('تعذر تحميل ملف الشخصيات.')
    }
}

async function حفظ_الشخصيات(شخصيات) {
    try {
        await fs.writeFile(مسار_الشخصيات, JSON.stringify(شخصيات, null, 2), 'utf-8')
    } catch (خطأ) {
        throw new Error('❀ تعذر حفظ ملف الشخصيات.')
    }
}

async function تحميل_الحريم() {
    try {
        const البيانات = await fs.readFile(مسار_الحريم, 'utf-8')
        return JSON.parse(البيانات)
    } catch (خطأ) {
        return []
    }
}

async function حفظ_الحريم(الحريم) {
    try {
        await fs.writeFile(مسار_الحريم, JSON.stringify(الحريم, null, 2))
    } catch (خطأ) {
        throw new Error('❀ تعذر حفظ ملف الحريم.')
    }
}

let handler = async (m, { conn, args }) => {
    const معرف_المستخدم = m.sender

    if (args.length < 2) {
        await conn.reply(m.chat, '《✧》يجب أن تحدد اسم الشخصية وتذكر من تريد إهداءها له.', m)
        return
    }

    const اسم_الشخصية = args.slice(0, -1).join(' ').toLowerCase().trim()
    let الى_من = m.mentionedJid[0]

    if (!الى_من) {
        await conn.reply(m.chat, '《✧》يجب أن تذكر مستخدمًا صالحًا.', m)
        return
    }

    try {
        const الشخصيات = await تحميل_الشخصيات()
        const الشخصية = الشخصيات.find(c => c.name.toLowerCase() === اسم_الشخصية && c.user === معرف_المستخدم)

        if (!الشخصية) {
            await conn.reply(m.chat, `《✧》*${اسم_الشخصية}* ليست مملوكة لك.`, m)
            return
        }

        الشخصية.user = الى_من
        await حفظ_الشخصيات(الشخصيات)

        const الحريم = await تحميل_الحريم()
        const مؤشر_المستخدم = الحريم.findIndex(entry => entry.userId === الى_من)

        if (مؤشر_المستخدم !== -1) {
            الحريم[مؤشر_المستخدم].characterId = الشخصية.id
            الحريم[مؤشر_المستخدم].lastClaimTime = Date.now()
        } else {
            const إدخال_جديد = {
                userId: الى_من,
                characterId: الشخصية.id,
                lastClaimTime: Date.now()
            }
            الحريم.push(إدخال_جديد)
        }

        await حفظ_الحريم(الحريم)

        await conn.reply(m.chat, `✰ *${الشخصية.name}* تم إهداؤها إلى @${الى_من.split('@')[0]}!`, m, { mentions: [الى_من] })
    } catch (خطأ) {
        await conn.reply(m.chat, `✘ حدث خطأ أثناء إهداء الشخصية: ${خطأ.message}`, m)
    }
}

handler.help = ['اهدي <اسم الشخصية> @المستخدم']
handler.tags = ['anime']
handler.command = ['اهدي', 'givewaifu', 'givechar']
handler.group = true

export default handler