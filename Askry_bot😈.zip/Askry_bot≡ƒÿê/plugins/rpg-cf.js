let users = {};

let handler = async (m, { conn, text, usedPrefix, command }) => {
  let [اختيار, كمية] = text.split(' ');
  if (!اختيار || !كمية) {
    return m.reply(`${emoji} من فضلك اختر "وجه" أو "ظهر" وحدد كمية من ${moneda} للمراهنة.\nمثال: *${usedPrefix + command} وجه 50*`);
  }

  اختيار = اختيار.toLowerCase();
  كمية = parseInt(كمية);
  if (اختيار !== 'وجه' && اختيار !== 'ظهر') {
    return m.reply(`${emoji2} اختيار غير صالح. من فضلك اختر "وجه" أو "ظهر".\nمثال: *${usedPrefix + command} وجه*`);
  }

  if (isNaN(كمية) || كمية <= 0) {
    return m.reply(`${emoji2} كمية غير صالحة. من فضلك اختر كمية من ${moneda} للمراهنة.\nمثال: *${usedPrefix + command} وجه 50*`);
  }

  let معرف_المستخدم = m.sender;
  if (!users[معرف_المستخدم]) users[معرف_المستخدم] = { coin: 100 };
  let المستخدم = global.db.data.users[m.sender];
  if (المستخدم.coin < كمية) {
    return m.reply(`${emoji2} ليس لديك ما يكفي من ${moneda} للمراهنة. لديك ${المستخدم.coin} ${moneda}.`);
  }

  let النتيجة = Math.random() < 0.5 ? 'وجه' : 'ظهر';
  let رسالة = `${emoji} العملة وقعت على `;
  if (النتيجة === اختيار) {
    المستخدم.coin += كمية;
    رسالة += `*${النتيجة}* وفزت بـ *${كمية} ${moneda}*!`;
  } else {
    المستخدم.coin -= كمية;
    رسالة += `*${النتيجة}* وخسرت *${كمية} ${moneda}*!`;
  }

  await conn.reply(m.chat, رسالة, m);
};

handler.help = ['cf'];
handler.tags = ['اقتصاد'];
handler.command = ['cf', 'حظ', 'وجه ظهر'];
handler.group = true;
handler.register = true;

export default handler;