import axios from "axios";

let handler = async (m, { conn, args }) => {
  if (!args[0]) {
    let resp = `${emoji} الرجاء إدخال اسم الدولة أو المدينة.`;
    let txt = '';
    let count = 0;
    for (const c of resp) {
      await new Promise(resolve => setTimeout(resolve, 5));
      txt += c;
      count++;
      if (count % 10 === 0) {
        conn.sendPresenceUpdate('composing', m.chat);
      }
    }
    await conn.sendMessage(m.chat, { text: txt.trim(), mentions: conn.parseMention(txt) }, { quoted: m, ephemeralExpiration: 24*60*60, disappearingMessagesInChat: 24*60*60 });
    return;
  }

  try {
    const response = await axios.get(`https://api.openweathermap.org/data/2.5/weather?q=${args[0]}&units=metric&appid=060a6bcfa19809c2cd4d97a212b19273`);
    const res = response.data;
    const name = res.name;
    const Country = res.sys.country;
    const Weather = res.weather[0].description;
    const Temperature = res.main.temp + "°C";
    const Minimum_Temperature = res.main.temp_min + "°C";
    const Maximum_Temperature = res.main.temp_max + "°C";
    const Humidity = res.main.humidity + "%";
    const Wind = res.wind.speed + "كم/س";
    const wea = `「 📍 」الموقع: ${name}\n「 🗺️ 」الدولة: ${Country}\n「 🌤️ 」الطقس: ${Weather}\n「 🌡️ 」درجة الحرارة: ${Temperature}\n「 💠 」الحد الأدنى للحرارة: ${Minimum_Temperature}\n「 📛 」الحد الأقصى للحرارة: ${Maximum_Temperature}\n「 💦 」الرطوبة: ${Humidity}\n「 🌬️ 」الرياح: ${Wind}`.trim();

    let txt = '';
    let count = 0;
    for (const c of wea) {
      await new Promise(resolve => setTimeout(resolve, 5));
      txt += c;
      count++;
      if (count % 10 === 0) {
        conn.sendPresenceUpdate('composing', m.chat);
      }
    }
    await conn.sendMessage(m.chat, { text: txt.trim(), mentions: conn.parseMention(txt) }, { quoted: m, ephemeralExpiration: 24*60*60, disappearingMessagesInChat: 24*60*60 });
  } catch (e) {
    let resp = `${msm} خطأ!\n لم يتم العثور على نتائج، حاول كتابة اسم دولة أو مدينة موجودة.`;
    let txt = '';
    let count = 0;
    for (const c of resp) {
      await new Promise(resolve => setTimeout(resolve, 5));
      txt += c;
      count++;
      if (count % 10 === 0) {
        conn.sendPresenceUpdate('composing', m.chat);
      }
    }
    await conn.sendMessage(m.chat, { text: txt.trim(), mentions: conn.parseMention(txt) }, { quoted: m, ephemeralExpiration: 24*60*60, disappearingMessagesInChat: 24*60*60 });
  }
};

handler.help = ['الطقس *<المدينة/الدولة>*'];
handler.tags = ['أدوات'];
handler.command = ['الطقس', 'clima', 'tiempo']
export default handler;