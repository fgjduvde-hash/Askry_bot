// plugins/owner/clear-session.js
// ╔════════════════════════════════════════════════════════════════╗
// ║  💀 ASKRY-BOT - CLEAR SESSION - HACKER EDITION 💀             ║
// ║  Author: Al Askry | Telegram: @askry47 | © 2026               ║
// ╚════════════════════════════════════════════════════════════════╝

import { readdirSync, unlinkSync, existsSync, promises as fs, rmSync } from 'fs'
import path from 'path'

var handler = async (m, { conn, usedPrefix }) => {

  // 💀 ثيم الهاكر الفاخر
  const skull = '💀'
  const warning = '⚠️'
  const success = '✅'
  const error = '❌'
  const wait = '🔄'
  const folder = '📁'
  const file = '📄'
  const clean = '🧹'

  // 🔐 تحقق من أن المستخدم هو البوت الرئيسي
  if (global.conn.user.jid !== conn.user.jid) {
    return conn.reply(m.chat, `
${warning}━━━━━━━━━━━━━━${warning}
💀 *ASKRY-BOT - تنبيه أمني* 💀
${warning}━━━━━━━━━━━━━━${warning}

${error} استخدم هذا الأمر من *الرقم الرئيسي للبوت* فقط.

🔐 هذا الأمر حصري للمطور: *عسكري* 👑
📡 للدعم: @askry47

${warning}━━━━━━━━━━━━━━${warning}
    `.trim(), m)
  }

  await conn.reply(m.chat, `
${wait}━━━━━━━━━━━━━━${wait}
💀 *جاري التنظيف...* 💀
${wait}━━━━━━━━━━━━━━${wait}

${clean} يتم الآن حذف جميع ملفات الجلسة...
${file} *ملف creds.json* سيتم الحفاظ عليه 🔐
${folder} المسار: ./${sessions}/

⏳ يرجى الانتظار...

${wait}━━━━━━━━━━━━━━${wait}
  `.trim(), m)
  
  m.react(wait)

  let sessionPath = `./${sessions}/`

  try {
    if (!existsSync(sessionPath)) {
      return await conn.reply(m.chat, `
${folder}━━━━━━━━━━━━━━${folder}
💀 *حالة المجلد* 💀
${folder}━━━━━━━━━━━━━━${folder}

${warning} المجلد فارغ أو غير موجود.

📂 المسار: ${sessionPath}
✅ لا يوجد ملفات للحذف.

${folder}━━━━━━━━━━━━━━${folder}
      `.trim(), m)
    }

    let files = await fs.readdir(sessionPath)
    let filesDeleted = 0

    for (const file of files) {
      if (file !== 'creds.json') {
        await fs.unlink(path.join(sessionPath, file))
        filesDeleted++
      }
    }

    if (filesDeleted === 0) {
      await conn.reply(m.chat, `
${folder}━━━━━━━━━━━━━━${folder}
💀 *نتيجة التنظيف* 💀
${folder}━━━━━━━━━━━━━━${folder}

${warning} المجلد لا يحتوي على ملفات قابلة للحذف.

📊 الملفات المحذوفة: *0*
🔐 ملف creds.json: *محفوظ* ✅

${folder}━━━━━━━━━━━━━━${folder}
      `.trim(), m)
    } else {
      m.react(success)
      await conn.reply(m.chat, `
${success}━━━━━━━━━━━━━━${success}
💀 *تم التنظيف بنجاح* 💀
${success}━━━━━━━━━━━━━━${success}

${clean} الملفات المحذوفة: *${filesDeleted}* 🗑️
${file} ملف creds.json: *محفوظ* 🔐
${folder} المسار: ./${sessions}/

🔄 *يرجى إعادة تشغيل البوت الآن*
${usedPrefix}restart

${success}━━━━━━━━━━━━━━${success}
      `.trim(), m)
      
      // رسالة تأكيد إضافية
      await conn.reply(m.chat, `
${skull} *ASKRY-BOT* ${skull}

${success} مرحبًا! هل يمكنك رؤيتي الآن؟ 👋

🔐 النظام يعمل بشكل صحيح.
👑 المطور: عسكري

${skull}━━━━━━━━━━━━━━${skull}
      `.trim(), m)
    }
  } catch (err) {
    console.error('💀 خطأ في ASKRY-BOT - clear-session:', err)
    await conn.reply(m.chat, `
${error}━━━━━━━━━━━━━━${error}
💀 *حدث خطأ غير متوقع* 💀
${error}━━━━━━━━━━━━━━${error}

${error} تعذر إكمال عملية التنظيف.

🔍 التفاصيل التقنية:
\`\`\`${err.message}\`\`\`

📡 للدعم الفني: @askry47
👑 المطور: عسكري

${error}━━━━━━━━━━━━━━${error}
    `.trim(), m)
  }
}

// 💀 إعدادات الأمر
handler.help = ['نظف', 'clearsession', 'cleansession']
handler.tags = ['owner', 'askry', 'system']
handler.command = ['نظف', 'dsowner', 'clearallsession', 'clearsession', 'cleansession', 'تنظيف']

// 🔐 الصلاحيات
handler.rowner = true      // حصري للمطور الرئيسي (عسكري)
handler.group = false      // يعمل في الخاص والمجموعات
handler.private = true     // مفضل استخدامه في الخاص
handler.admin = false
handler.botAdmin = false
handler.premium = false

// 💀 ASKRY-BOT © 2026 Al Askry - All Rights Reserved
export default handler