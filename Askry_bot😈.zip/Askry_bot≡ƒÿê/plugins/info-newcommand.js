let handler = async (m, { conn, text, usedPrefix, command }) => {
  if (!text) return conn.reply(m.chat, `√${emoji} ما هو الأمر الذي تريد اقتراحه؟`, m)
  if (text.length < 10) return conn.reply(m.chat, `${emoji2} يجب أن تكون الاقتراحات أكثر من 10 حروف.`, m)
  if (text.length > 1000) return conn.reply(m.chat, `${emoji2} الحد الأقصى للاقتراح هو 1000 حرف.`, m)
  
  const teks = `${emoji} اقتراح أمر جديد من المستخدم *${nombre}*\n\n☁️ الأمر المقترح:\n> ${text}`

  await conn.reply(`${suittag}@s.whatsapp.net`, m.quoted ? teks + m.quoted.text : teks, m, { mentions: conn.parseMention(teks) })

  m.reply('🍬 تم إرسال الاقتراح إلى المطور الخاص بي.')
}

handler.help = ['newcommand']
handler.tags = ['info']
handler.command = ['newcommand', 'sug']

export default handler