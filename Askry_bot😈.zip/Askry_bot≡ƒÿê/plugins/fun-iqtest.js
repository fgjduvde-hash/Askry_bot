let handler = async (m, { conn }) => {
  conn.reply(m.chat, `${pickRandom(global.iq)}`, m)
}
handler.help = ['اختبار-ذكاء']
handler.tags = ['fun']
handler.command = ['اختبار-ذكاء', 'iq']
handler.group = true
handler.register = true
handler.fail = null

export default handler 

function pickRandom(list) {
  return list[Math.floor(list.length * Math.random())]
}

global.iq = [
'معدل ذكائك هو: 1',
'معدل ذكائك هو: 14',
'معدل ذكائك هو: 23',
'معدل ذكائك هو: 35',
'معدل ذكائك هو: 41',
'معدل ذكائك هو: 50',
'معدل ذكائك هو: 67',
'معدل ذكائك هو: 72',
'معدل ذكائك هو: 86',
'معدل ذكائك هو: 99',
'معدل ذكائك هو: 150',
'معدل ذكائك هو: 340',
'معدل ذكائك هو: 423',
'معدل ذكائك هو: 500',
'معدل ذكائك هو: 676',
'معدل ذكائك هو: 780',
'معدل ذكائك هو: 812',
'معدل ذكائك هو: 945',
'معدل ذكائك هو: 1000',
'معدل ذكائك هو: لا محدود!!',
'معدل ذكائك هو: 5000',
'معدل ذكائك هو: 7500',
'معدل ذكائك هو: 10000',
]