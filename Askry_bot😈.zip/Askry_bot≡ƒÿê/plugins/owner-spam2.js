const delay = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

let handler = async (m, { conn, text, usedPrefix, command }) => {
  const args = text.split('|').map(v => v.trim());

  if (args.length < 3) {
    return m.reply(`${emoji} يجب إدخال رابط القروب، والرسالة، وعدد الرسائل مفصولين بـ "|".\n\nمثال:\n${usedPrefix + command} https://chat.whatsapp.com/SSSS | مرحباً، كيف حالكم؟ | 5`);
  }

  const [groupLink, message, countStr] = args;
  const count = parseInt(countStr, 10);

  if (!groupLink.includes('chat.whatsapp.com')) {
    return m.reply(`${emoji2} يرجى تقديم رابط مجموعة صحيح.`);
  }
  if (isNaN(count) || count <= 0) {
    return m.reply(`${emoji2} حدد عددًا صحيحًا من الرسائل (أكبر من 0).`);
  }

  try {
    const code = groupLink.split('chat.whatsapp.com/')[1];
    const groupId = await conn.groupAcceptInvite(code);

    m.reply(`${done} تم الانضمام إلى القروب بنجاح. بدء إرسال ${count} رسالة...`);

    for (let i = 0; i < count; i++) {
      await conn.sendMessage(groupId, { text: message });
      await delay(1000); 
    }

    m.reply(`${done} تم الانتهاء من الإرسال. جاري مغادرة القروب...`);
    await conn.groupLeave(groupId);
  } catch (error) {
    console.error(error);
    m.reply(`${msm} حدث خطأ أثناء تنفيذ العملية: ${error.message}`);
  }
};

handler.help = ['سبام'];
handler.tags = ['owner'];
handler.command = ['سبام'];
handler.owner = true;

export default handler;