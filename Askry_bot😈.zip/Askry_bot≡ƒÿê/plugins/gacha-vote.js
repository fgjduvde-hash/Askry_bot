import { promises as fs } from 'fs'

const مسار_الشخصيات = './src/database/characters.json'
const مسار_الحريم = './src/database/harem.json'

async function تحميل_الشخصيات() {
    try {
        const البيانات = await fs.readFile(مسار_الشخصيات, 'utf-8')
        return JSON.parse(البيانات)
    } catch (خطأ) {
        throw new Error('《✧》تعذر تحميل ملف الشخصيات.')
    }
}

async function حفظ_الشخصيات(شخصيات) {
    try {
        await fs.writeFile(مسار_الشخصيات, JSON.stringify(شخصيات, null, 2))
    } catch (خطأ) {
        throw new Error('《✧》تعذر حفظ ملف الشخصيات.')
    }
}

async function تحميل_الحريم() {
    try {
        const البيانات = await fs.readFile(مسار_الحريم, 'utf-8')
        return JSON.parse(البيانات)
    } catch {
        return []
    }
}

async function حفظ_الحريم(حريم) {
    try {
        await fs.writeFile(مسار_الحريم, JSON.stringify(حريم, null, 2))
    } catch (خطأ) {
        throw new Error('《✧》تعذر حفظ ملف الحريم.')
    }
}

let المهلة = new Map()
let تصويت_الشخصيات = new Map()

let handler = async (m, { conn, args }) => {
    try {
        const المستخدم = m.sender
        const وقت_الانتظار = 1 * 60 * 60 * 1000 // ساعة

        if (المهلة.has(المستخدم)) {
            const انتهاء = المهلة.get(المستخدم) + وقت_الانتظار
            const الآن = Date.now()
            if (الآن < انتهاء) {
                const الباقي = انتهاء - الآن
                const دقائق = Math.floor((الباقي / 1000 / 60) % 60)
                const ثواني = Math.floor((الباقي / 1000) % 60)
                await conn.reply(m.chat, `《✧》يجب الانتظار *${دقائق} دقيقة ${ثواني} ثانية* قبل التصويت مجددًا.`, m)
                return
            }
        }

        const الشخصيات = await تحميل_الشخصيات()
        const اسم_الشخصية = args.join(' ')

        if (!اسم_الشخصية) {
            await conn.reply(m.chat, '《✧》يرجى كتابة اسم الشخصية التي تريد التصويت لها.', m)
            return
        }

        const الاسم_الأصلي = اسم_الشخصية
        const الشخصية = الشخصيات.find(p => p.name.toLowerCase() === الاسم_الأصلي.toLowerCase())

        if (!الشخصية) {
            await conn.reply(m.chat, '《✧》لم يتم العثور على الشخصية. تأكد من كتابة الاسم بشكل صحيح.', m)
            return
        }

        if (تصويت_الشخصيات.has(الاسم_الأصلي) && Date.now() < تصويت_الشخصيات.get(الاسم_الأصلي)) {
            const انتهاء = تصويت_الشخصيات.get(الاسم_الأصلي)
            const الباقي = انتهاء - Date.now()
            const دقائق = Math.floor((الباقي / 1000 / 60) % 60)
            const ثواني = Math.floor((الباقي / 1000) % 60)
            await conn.reply(m.chat, `《✧》الشخصية *${الاسم_الأصلي}* تم التصويت لها مؤخرًا. الرجاء الانتظار *${دقائق} دقيقة ${ثواني} ثانية*.`, m)
            return
        }

        const الزيادة = Math.floor(Math.random() * 10) + 1
        الشخصية.value = String(Number(الشخصية.value) + الزيادة)
        الشخصية.votes += 1
        await حفظ_الشخصيات(الشخصيات)

        const الحريم = await تحميل_الحريم()
        const مدخل_المستخدم = الحريم.find(h => h.userId === المستخدم && h.characterId === الشخصية.id)

        if (!مدخل_المستخدم) {
            الحريم.push({
                userId: المستخدم,
                characterId: الشخصية.id,
                lastVoteTime: Date.now(),
                voteCooldown: Date.now() + وقت_الانتظار
            })
        } else {
            مدخل_المستخدم.lastVoteTime = Date.now()
            مدخل_المستخدم.voteCooldown = Date.now() + وقت_الانتظار
        }

        await حفظ_الحريم(الحريم)

        المهلة.set(المستخدم, Date.now())
        تصويت_الشخصيات.set(الاسم_الأصلي, Date.now() + وقت_الانتظار)

        await conn.reply(m.chat, `✰ تم التصويت للشخصية *${الاسم_الأصلي}*\n> القيمة الجديدة: *${الشخصية.value}* (زيادة بـ *${الزيادة}*)\n> عدد الأصوات: *${الشخصية.votes}*`, m)
    } catch (e) {
        await conn.reply(m.chat, `✘ حدث خطأ أثناء التصويت: ${e.message}`, m)
    }
}

handler.help = ['تصويت <اسم>']
handler.tags = ['anime']
handler.command = ['تصويت', 'vote', 'votar']
handler.group = true
handler.register = true

export default handler