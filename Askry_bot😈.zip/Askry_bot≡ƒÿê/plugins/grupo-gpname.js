const handler = async (m, { conn, args, text }) => {
  if (!text) throw `${emoji} من فضلك أدخل الاسم الجديد الذي تريد وضعه للمجموعة.`;
  try {
    const nuevoNombre = args.join(' ');
    if (nuevoNombre) {
      await conn.groupUpdateSubject(m.chat, nuevoNombre);
      m.reply(`${emoji} تم تغيير اسم المجموعة إلى: ${nuevoNombre}`);
    }
  } catch (e) {
    throw `${msm} حدث خطأ أثناء تغيير اسم المجموعة.`;
  }
};
handler.help = ['اسم القروب <النص>'];
handler.tags = ['مجموعة'];
handler.command = ['اسم_مجموعة', 'gpname', 'groupname'];
handler.group = true;
handler.admin = true;

export default handler;