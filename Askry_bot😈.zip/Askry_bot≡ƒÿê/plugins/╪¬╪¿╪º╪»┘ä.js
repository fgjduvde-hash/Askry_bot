const exchangeData = global.db.data.exchangeSystem = global.db.data.exchangeSystem || {
  active: false,
  links: [],
  lastExchange: {}
};

let handler = async (m, { conn, text, args, command, isGroup }) => {
  const isPrivate = !m.isGroup;

  // ─── أوامر القروب ───
  if (!isPrivate && ['تبادل'].includes(command)) {
    let sub = args[0]?.toLowerCase();
    if (sub === 'فتح') {
      if (args.length < 2) return m.reply('📌 يرجى إضافة رابط واحد على الأقل بعد الأمر:\nمثال:\n*.تبادل فتح https://chat.whatsapp.com/xxxx https://chat.whatsapp.com/yyyy*');
      let links = args.slice(1).filter(link => link.startsWith('https://chat.whatsapp.com/'));
      if (links.length === 0) return m.reply('❌ لم يتم العثور على أي روابط صالحة.');
      exchangeData.active = true;
      exchangeData.links = links;
      return m.reply('*تبادلاتكم خاص 〔🌕〕*');
    }

    if (sub === 'قفل') {
      exchangeData.active = false;
      exchangeData.links = [];
      return m.reply('*تم قفل التبادل〔🌕〕*');
    }

    return m.reply('❓ أمر غير معروف. استعمل:\n- *.تبادل فتح <روابط>*\n- *.تبادل قفل*');
  }

  // ─── أمر الخاص .تبادل خاص ───
  if (isPrivate && command === 'تبادل') {
    if (!exchangeData.active || exchangeData.links.length === 0) {
      return m.reply('❌ التبادل غير مفعل حاليًا.\nيرجى المحاولة لاحقًا أو التواصل مع الأدمن.');
    }

    const user = m.sender;
    const now = Date.now();
    const last = exchangeData.lastExchange[user] || 0;
    const cooldown = 24 * 60 * 60 * 1000; // 24 ساعة

    if (now - last < cooldown) {
      let remaining = Math.ceil((cooldown - (now - last)) / (60 * 60 * 1000));
      return m.reply(`⏱️ لقد قمت بالتبادل مؤخرًا.\nيرجى الانتظار *${remaining} ساعة* قبل محاولة جديدة.`);
    }

    // حفظ وقت التبادل
    exchangeData.lastExchange[user] = now;

    // إرسال الروابط
    let replyText = `🔗 *روابط التبادل:*\n\n`;
    exchangeData.links.forEach((link, i) => {
      replyText += `🔸 ${i + 1}. ${link}\n`;
    });
    replyText += `\n📌 تأكد من تنفيذ التبادل خلال وقت قصير.\n⚙️ ˚ ₊⊹𝑻𝒆𝒔𝒔𝒊𝒂୨🪽𝐵𝑜𝑡₊`;

    return conn.reply(m.chat, replyText, m);
  }
};

handler.command = ['تبادل'];
export default handler;