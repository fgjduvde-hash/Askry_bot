import db from '../lib/database.js'

let handler = async (m, { conn, usedPrefix }) => {
    let who = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : m.sender
    if (who == conn.user.jid) return m.react('✖️')
    if (!(who in global.db.data.users)) return m.reply(`${emoji} المستخدم غير موجود في قاعدة البيانات الخاصة بي.`)
  
    let user = global.db.data.users[who]
    let total = (user.coin || 0) + (user.bank || 0);

    const texto = `ᥫ᭡ معلومات - الاقتصاد ❀
 
ᰔᩚ المستخدم » *${conn.getName(who)}*   
⛀ النقود » *${user.coin} ${moneda}*
⚿ البنك » *${user.bank} ${moneda}*
⛁ الإجمالي » *${total} ${moneda}*

> *لحماية أموالك، قم بإيداعها في البنك باستخدام الأمر #deposit!*`;

    await conn.reply(m.chat, texto, m)
}

handler.help = ['الرصيد']
handler.tags = ['rpg']
handler.command = ['رصيد', 'balance', 'bank'] 
handler.register = true 
handler.group = true 

export default handler

