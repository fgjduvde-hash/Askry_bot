import { readdirSync, statSync, unlinkSync, existsSync, readFileSync, watch, rmSync, promises as fsPromises } from "fs";
const fs = { ...fsPromises, existsSync };
import path, { join } from 'path';
import ws from 'ws';

let handler = async (m, { conn: _envio, command, usedPrefix, args, text, isOwner }) => {
  const isCommand1 = /^(deletesesion|deletebot|deletesession|deletesesaion)$/i.test(command);
  const isCommand2 = /^(stop|pausarai|pausarbot)$/i.test(command);
  const isCommand3 = /^(bots|sockets|socket)$/i.test(command);

  async function reportError(e) {
    await m.reply(`${msm} حدث خطأ.`);
    console.error(e);
  }

  switch (true) {
    case isCommand1:
      let who = m.mentionedJid && m.mentionedJid[0] ? m.mentionedJid[0] : m.fromMe ? conn.user.jid : m.sender;
      let uniqid = `${who.split`@`[0]}`;
      const sessionPath = `./${jadi}/${uniqid}`;

      if (!await fs.existsSync(sessionPath)) {
        await _envio.sendMessage(m.chat, { text: `${emoji} ليس لديك جلسة، يمكنك إنشاء واحدة باستخدام:\n${usedPrefix + command}\n\nإذا كان لديك *(ID)* يمكنك تخطي الخطوة السابقة باستخدام:\n*${usedPrefix + command}* \`\`\`(ID)\`\`\`` }, { quoted: m });
        return;
      }

      if (global.conn.user.jid !== conn.user.jid) {
        return _envio.sendMessage(m.chat, {
          text: `${emoji2} استخدم هذا الأمر على *البوت* الرئيسي.\n\n*https://api.whatsapp.com/send/?phone=${global.conn.user.jid.split`@`[0]}&text=${usedPrefix + command}&type=phone_number&app_absent=0*`
        }, { quoted: m });
      } else {
        await _envio.sendMessage(m.chat, { text: `${emoji} تم حذف جلستك كبوت فرعي.` }, { quoted: m });
      }

      try {
        await fs.rmdir(`./${jadi}/` + uniqid, { recursive: true, force: true });
        await _envio.sendMessage(m.chat, { text: `${emoji3} تم إغلاق الجلسة وحذف جميع آثارها.` }, { quoted: m });
      } catch (e) {
        reportError(e);
      }
      break;

    case isCommand2:
      if (global.conn.user.jid === conn.user.jid) {
        conn.reply(m.chat, `${emoji} إذا لم تكن *بوت فرعي* تواصل مع الرقم الرئيسي للبوت ليتم إضافتك كبوت فرعي.`, m);
      } else {
        await conn.reply(m.chat, `${emoji} تم إيقاف تشغيل ${botname}.`, m);
        conn.ws.close();
      }
      break;

    case isCommand3:
      const users = [...new Set([...global.conns.filter(c => c.user && c.ws.socket && c.ws.socket.readyState !== ws.CLOSED).map(c => c)])];

      function msToTime(ms) {
        let seconds = Math.floor(ms / 1000);
        let minutes = Math.floor(seconds / 60);
        let hours = Math.floor(minutes / 60);
        let days = Math.floor(hours / 24);

        seconds %= 60;
        minutes %= 60;
        hours %= 24;

        let result = "";
        if (days !== 0) result += days + " أيام، ";
        if (hours !== 0) result += hours + " ساعات، ";
        if (minutes !== 0) result += minutes + " دقائق، ";
        if (seconds !== 0) result += seconds + " ثواني";
        return result;
      }

      const message = users.map((v, i) => `• 「 ${i + 1} 」\n📎 Wa.me/${v.user.jid.replace(/[^0-9]/g, '')}?text=${usedPrefix}estado\n👤 المستخدم: ${v.user.name || 'بوت فرعي'}\n🕑 متصل منذ: ${v.uptime ? msToTime(Date.now() - v.uptime) : 'غير معروف'}`).join('\n\n__________________________\n\n');
      const replyMessage = message.length === 0 ? `لا يوجد بوتات فرعية متاحة حالياً، تحقق لاحقاً.` : message;
      const totalUsers = users.length;

      const responseMessage = `${emoji} قائمة *البوتات الفرعية* النشطة\n\n${emoji2} يمكنك طلب الإذن ليتم إضافة البوت إلى مجموعتك\n\n\`\`\`كل مستخدم بوت فرعي يستخدم وظائفه بحرية، الرقم الرئيسي للبوت غير مسؤول عن سوء الاستخدام.\`\`\`\n\n*البوتات الفرعية المتصلة:* ${totalUsers || '0'}\n\n${replyMessage.trim()}`.trim();

      await _envio.sendMessage(m.chat, { text: responseMessage, mentions: _envio.parseMention(responseMessage) }, { quoted: m });
      break;
  }
};

handler.tags = ['serbot'];
handler.help = ['البوتات الفرعيه', 'deletesesion', 'pausarai'];
handler.command = ['المنصبين', 'deletebot', 'deletesession', 'stop', 'pausarai', 'pausarbot', 'bots', 'sockets', 'socket'];

export default handler;