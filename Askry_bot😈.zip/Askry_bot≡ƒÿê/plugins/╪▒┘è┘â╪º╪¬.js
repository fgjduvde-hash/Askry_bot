export async function before (m, { conn }) {

  const numbers = ['218927472437', '201032644623' ,'249115025700'];

  const emojis = ["🧏🏻‍♀️", "🍓", "🌙", "💋", "💐", "🫀", "✨", "🫐", "🌸", "💍", "🦋", "🌑", "🤹🏼‍♀️", "🖤", "💗", "🤹🏻‍♀️", "🙊", "💄", "🐈‍⬛", "🌹", "🍇", "🍥", "🥛", "👩‍🍼", "👩🏼‍⚕️", "👰🏻‍♀", "🧛🏻‍♀️", "🧖🏼‍♀️", "🎼", "🍒", "👮🏻‍♀️", "🥹", "🧖🏻‍♀️"];

  if (numbers.includes(m.sender.split`@`[0])) {

    const emojiPattern = /[\u{1F600}-\u{1F64F}\u{1F300}-\u{1F5FF}\u{1F680}-\u{1F6FF}\u{1F700}-\u{1F77F}\u{1F780}-\u{1F7FF}\u{1F800}-\u{1F8FF}\u{1F900}-\u{1F9FF}\u{1FA00}-\u{1FA6F}\u{1FA70}-\u{1FAFF}\u{2600}-\u{26FF}\u{2700}-\u{27BF}\u{2300}-\u{23FF}\u{2B50}\u{1F004}\u{1F0CF}]/u;

    const text = m.text || '';

    const randomEmoji = emojis[Math.floor(Math.random() * emojis.length)];

    const match = text.match(emojiPattern);

    const emojiToReact = match ? match[0] : randomEmoji;

    await conn.sendMessage(m.chat, { react: { text: randomEmoji, key: m.key } });

    await new Promise(resolve => setTimeout(resolve, 500)); 

    await conn.sendMessage(m.chat, { react: { text: emojiToReact, key: m.key } });

  }

}