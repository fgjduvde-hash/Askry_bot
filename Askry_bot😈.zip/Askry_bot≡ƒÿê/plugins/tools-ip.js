import axios from 'axios'

let handler = async (m, { conn, text }) => {
  let bot = '🍭 جاري البحث، يرجى الانتظار...'
  conn.reply(m.chat, bot, m)

  if (!text) return conn.reply(m.chat, `${emoji} من فضلك أدخل *عنوان IP*.`, m)

  axios.get(`http://ip-api.com/json/${text}?fields=status,message,country,countryCode,region,regionName,city,district,zip,lat,lon,timezone,isp,org,as,mobile,hosting,query`).then((res) => {
    const data = res.data

    if (String(data.status) !== "success") {
      throw new Error(data.message || "فشل في الجلب")
    }

    let ipsearch = `
☁️ *مـعـلـومـات الـ IP* ☁️

📌 العنوان : ${data.query}
🌎 الدولة : ${data.country}
🔠 رمز الدولة : ${data.countryCode}
🗺️ المقاطعة : ${data.regionName}
📍 رمز المقاطعة : ${data.region}
🏙️ المدينة : ${data.city}
🏘️ الحي : ${data.district}
📮 الرمز البريدي : ${res.data.zip}
⏰ المنطقة الزمنية : ${data.timezone}
📡 مزود الخدمة : ${data.isp}
🏢 المنظمة : ${data.org}
🛰️ AS : ${data.as}
📱 هاتف محمول : ${data.mobile ? "نعم" : "لا"}
🖥️ استضافة : ${data.hosting ? "نعم" : "لا"}
`.trim()

    conn.reply(m.chat, ipsearch, m)
  })
}

handler.help = ['ip <عنوان IP>']
handler.tags = ['المالك']
handler.command = ['ip']

export default handler