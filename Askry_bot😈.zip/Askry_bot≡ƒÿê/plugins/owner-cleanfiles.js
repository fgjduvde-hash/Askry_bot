import { promises as fs } from 'fs';
import path from 'path';

const dirname = path.resolve();

const limpiarArchivosTemporales = async () => {
    const dir = path.join(dirname, 'plugins');
    const files = await fs.readdir(dir);

    const tempImages = files.filter(file => file.startsWith('temp_image_') && file.endsWith('.png'));
    const tempPDFs = files.filter(file => file.startsWith('manga_') && file.endsWith('.pdf'));

    const allTempFiles = [...tempImages, ...tempPDFs];

    if (allTempFiles.length === 0) {
        return `${emoji2} لم يتم العثور على ملفات مؤقتة للحذف.`;
    }

    await Promise.all(allTempFiles.map(async file => {
        const filePath = path.join(dir, file);
        await fs.unlink(filePath);
    }));

    return `${emoji} تم حذف ${allTempFiles.length} ملف مؤقت بنجاح.`;
};

let handler = async (m, { conn, isOwner }) => {
    if (!isOwner) return conn.reply(m.chat, `${emoji} فقط المالك يمكنه استخدام هذا الأمر.`, m);

    try {
        const result = await limpiarArchivosTemporales();
        await conn.reply(m.chat, result, m);
    } catch (error) {
        await conn.reply(m.chat, `${msm} خطأ: ${error.message}`, m);
    }
};

handler.help = ['cleanfiles'].map(v => v + " *");
handler.tags = ['owner'];
handler.command = ['ملفات نظيفة'];

export default handler;