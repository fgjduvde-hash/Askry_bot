let handler = async (m, { conn, text }) => {
    let who;

    if (m.isGroup) {
        if (m.mentionedJid.length > 0) {
            who = m.mentionedJid[0];
        } else if (m.replyMessage && m.replyMessage.sender) {
            who = m.replyMessage.sender;
        } else if (text) {
            who = text.trim();
            if (!who.endsWith('@s.whatsapp.net')) {
                who = `${who}@s.whatsapp.net`;
            }
        } else {
            who = m.sender;
        }
    } else {
        if (text) {
            who = text.trim();
            if (!who.endsWith('@s.whatsapp.net')) {
                who = `${who}@s.whatsapp.net`;
            }
        } else {
            who = m.sender;
        }
    }

    console.log(`المستخدم المعالج: ${who}`); // لأغراض التصحيح

    if (!global.db) global.db = {};
    if (!global.db.data) global.db.data = {};
    if (!global.db.data.users) global.db.data.users = {};

    let users = global.db.data.users;

    if (!users[who]) throw `${emoji2} لا توجد بيانات لهذا المستخدم لإزالتها.`;

    users[who].coin = 0;
    users[who].exp = 0;
    users[who].level = 0;

    await global.db.write();

    for (let subbot of global.conns) {
        try {
            if (subbot.user) {
                await subbot.sendMessage(m.chat, { text: `/deschetar ${who.split`@`[0]}` });
            }
        } catch (error) {
            console.log(`${msm} خطأ أثناء إزالة بيانات المستخدم: ${error.message}`);
        }
    }

    await m.reply(
        `☁️ *تم تصفير بيانات المستخدم بنجاح!*\n\n` +
        `👤 المستخدم: @${who.split`@`[0]}\n` +
        `💸 ${moneda}: *0*\n` +
        `✨ الخبرة: *0*\n` +
        `🌟 المستوى: *0*`,
        null,
        { mentions: [who] }
    );
};

handler.help = ['تشريد *@شخص*', 'deschetar *<رقم>*'];
handler.tags = ['المالك'];
handler.command = ['deschetar'];
handler.register = true;
handler.rowner = true;

export default handler;