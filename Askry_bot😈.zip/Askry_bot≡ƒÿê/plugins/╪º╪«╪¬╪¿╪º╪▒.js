import fs from 'fs';

let handler = m => m;

handler.all = async function (m) {
  const vn = './src/assets/audio/ايوه.mp3';
  const vn2 = './src/assets/audio/شويه حاجات.mp3';

  const chat = global.db.data.chats[m.chat] || {};
  const user = global.db.data.users[m.sender] || {};
  const name = await this.getName(m.sender);
  const wm = global.wm || 'بوت';

  const fk = {
    key: {
      fromMe: false,
      participant: '0@s.whatsapp.net',
      remoteJid: 'status@broadcast'
    },
    message: {
      contactMessage: {
        displayName: name,
        vcard: `BEGIN:VCARD\nVERSION:3.0\nN:;${name};;;;\nFN:${name}\nitem1.TEL;waid=${m.sender.split('@')[0]}:${m.sender.split('@')[0]}\nitem1.X-ABLabel:Ponsel\nEND:VCARD`
      }
    }
  };

  // الأمر الأول
  if (/^(دلت|صثه|جستو)$/i.test(m.text) && !chat.isBanned) {
    const img = 'https://files.catbox.moe/hq6v5d.jpg';
    const cap = `
*⛊ مرحباً: ❲ ${name} ❳*
*⛊ أنا: ❲ ${wm} ❳*

> 🗃️ *معلوماتي:*

- ◉📑 *الأوامر:* لعرض قائمة أوامري  
- ◉💻 *المطور:* للتواصل مع مطوري
`.trim();

    await this.sendButton(m.chat, cap, wm, img, [
      ['❲ الاوامــر ❳', '.اوامر'],
      ['❲ المطــور ❳', '.مطور']
    ], fk);

    if (chat.audios) {
      this.sendPresenceUpdate('recording', m.chat);
      await this.sendMessage(m.chat, {
        audio: fs.readFileSync(vn),
        fileName: 'ايوه.mp3',
        mimetype: 'audio/mpeg',
        ptt: true
      }, { quoted: fk });
    }
  }

  // الأمر الثاني
  if (/^تست$/i.test(m.text) && !chat.isBanned) {
    await this.sendMessage(m.chat, { text: '*`❲ 🌕 ❳ 𝑊𝑜𝑟𝑘𝑖𝑛𝑔`*' }, { quoted: fk });

    if (chat.audios) {
      this.sendPresenceUpdate('recording', m.chat);
      await this.sendMessage(m.chat, {
        audio: fs.readFileSync(vn2),
        fileName: 'test.mp3',
        mimetype: 'audio/mpeg',
        ptt: true
      }, { quoted: fk });
    }
  }

  return true;
};

export default handler;