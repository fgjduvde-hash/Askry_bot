const handler = async (m, { conn, isROwner, text }) => {
  const delay = (time) => new Promise((res) => setTimeout(res, time));
  const getGroups = await conn.groupFetchAllParticipating();
  const groups = Object.entries(getGroups).slice(0).map((entry) => entry[1]);
  const anu = groups.map((v) => v.id);
  const pesan = m.quoted && m.quoted.text ? m.quoted.text : text;
  if (!pesan) throw `${emoji} لقد نسيت النص.`;
  for (const i of anu) {
    await delay(500);
    conn.relayMessage(i,
        { liveLocationMessage: {
          degreesLatitude: 35.685506276233525,
          degreesLongitude: 139.75270667105852,
          accuracyInMeters: 0,
          degreesClockwiseFromMagneticNorth: 2,
          caption: '⭐️ رسالة ⭐️\n\n' + pesan + `${packname}`,
          sequenceNumber: 2,
          timeOffset: 3,
          contextInfo: m,
        }}, {}).catch((_) => _);
  }
  m.reply(`${emoji} *تم إرسال الرسالة إلى:* ${anu.length} *مجموعة/مجموعات*`);
};
handler.help = ['بيان', 'bcgc'];
handler.tags = ['owner'];
handler.command = ['بيان'];
handler.owner = true;

export default handler;