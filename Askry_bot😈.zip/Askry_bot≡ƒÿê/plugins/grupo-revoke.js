var handler = async (m, { conn }) => {

  // إعادة تعيين رابط الدعوة للمجموعة
  let res = await conn.groupRevokeInvite(m.chat)
  let gruf = m.chat

  // إرسال الرابط الجديد لصاحب الأمر
  conn.reply(m.sender, 'https://chat.whatsapp.com/' + await conn.groupInviteCode(gruf), m)
}

handler.help = ['تعيين رابط القروب']
handler.tags = ['مجموعة']
handler.command = ['revoke', 'إعادة_تعيين']
handler.group = true
handler.admin = true
handler.botAdmin = true

export default handler