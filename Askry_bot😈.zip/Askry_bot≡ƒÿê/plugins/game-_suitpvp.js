const handler = (m) => m;
handler.before = async function(m) {
  this.suit = this.suit ? this.suit : {};
  if (db.data.users[m.sender].suit < 0) db.data.users[m.sender].suit = 0;
  const room = Object.values(this.suit).find((room) => room.id && room.status && [room.p, room.p2].includes(m.sender));
  if (room) {
    let الفائز = '';
    let تعادل = false;
    if (m.sender == room.p2 && /^(acc(ept)?|terima|aceptar|gas|aceptare?|nao|gamau|rechazar|ga(k.)?bisa)/i.test(m.text) && m.isGroup && room.status == 'wait') {
      if (/^(tolak|gamau|rechazar|ga(k.)?bisa)/i.test(m.text)) {
        const نص_الرفض = `${emoji2} @${room.p2.split`@`[0]} رفض التحدي، تم إلغاء اللعبة.`;
        m.reply(نص_الرفض, null, {mentions: this.parseMention(نص_الرفض)});
        delete this.suit[room.id];
        return !0;
      }
      room.status = 'play';
      room.asal = m.chat;
      clearTimeout(room.waktu);
      const نص_بدء_اللعب = `🎮 ألعاب - لاعب ضد لاعب - ألعاب 🎮\n\n—◉ بدأت اللعبة، تم إرسال الخيارات إلى المحادثات الخاصة لـ @${room.p.split`@`[0]} و @${room.p2.split`@`[0]}\n\n◉ اختر خيارًا في محادثتك الخاصة، على التوالي.\n*◉ اختر خيارًا في wa.me/${conn.user.jid.split`@`[0]}*`;
      m.reply(نص_بدء_اللعب, m.chat, {mentions: this.parseMention(نص_بدء_اللعب)});
      const نص_الخيارات_للاعب_1 = `${emoji} من فضلك اختر أحد الخيارات التالية:
حجر
ورق
مقص\nالفائز +${room.poin}XP\nالخاسر ${room.poin_lose}XP\n*رد على هذه الرسالة بالخيار الذي تريد* 
*مثال: ورق*`;
      const نص_الخيارات_للاعب_2 = `${emoji} من فضلك اختر أحد الخيارات التالية:
حجر
ورق
مقص\nالفائز +${room.poin}XP\nالخاسر ${room.poin_lose}XP\n*رد على هذه الرسالة بالخيار الذي تريد* 
*مثال: ورق*`;

      if (!room.pilih) this.sendMessage(room.p, {text: نص_الخيارات_للاعب_1}, {quoted: m});
      if (!room.pilih2) this.sendMessage(room.p2, {text: نص_الخيارات_للاعب_2}, {quoted: m});
      room.waktu_milih = setTimeout(() => {
        const نص_عدم_المبادرة = `${emoji2} لم يقم أي لاعب بالمبادرة لبدء اللعبة، تم إلغاء التحدي.`;
        if (!room.pilih && !room.pilih2) this.sendMessage(m.chat, {text: نص_عدم_المبادرة}, {quoted: m});
        else if (!room.pilih || !room.pilih2) {
          الفائز = !room.pilih ? room.p2 : room.p;
          const نص_عدم_الاختيار = `${emoji2} @${(room.pilih ? room.p2 : room.p).split`@`[0]} لم تختر أي خيار، انتهى التحدي.`;
          this.sendMessage(m.chat, {text: نص_عدم_الاختيار}, {quoted: m}, {mentions: this.parseMention(نص_عدم_الاختيار)});
          db.data.users[الفائز == room.p ? room.p : room.p2].exp += room.poin;
          db.data.users[الفائز == room.p ? room.p : room.p2].exp += room.poin_bot;
          db.data.users[الفائز == room.p ? room.p2 : room.p].exp -= room.poin_lose;
        }
        delete this.suit[room.id];
        return !0;
      }, room.timeout);
    }
    const رد_اللاعب_1 = m.sender == room.p;
    const رد_اللاعب_2 = m.sender == room.p2;
    const مقص = /مقص/i;
    const حجر = /حجر/i;
    const ورق = /ورق/i;
    const نمط = /^(مقص|حجر|ورق)/i;
    if (رد_اللاعب_1 && نمط.test(m.text) && !room.pilih && !m.isGroup) {
      room.pilih = نمط.exec(m.text.toLowerCase())[0];
      room.text = m.text;
      m.reply(`${emoji} اخترت ${m.text}، عد إلى المجموعة و${room.pilih2 ? `راجع النتائج` : 'انتظر النتائج'}`);
      if (!room.pilih2) this.reply(room.p2, `${emoji2} الخصم اختار، دورك الآن للاختيار!!`, 0);
    }
    if (رد_اللاعب_2 && نمط.test(m.text) && !room.pilih2 && !m.isGroup) {
      room.pilih2 = نمط.exec(m.text.toLowerCase())[0];
      room.text2 = m.text;
      m.reply(`${emoji} اخترت ${m.text}، عد إلى المجموعة و${room.pilih ? `راجع النتائج` : 'انتظر النتائج'}`);
      if (!room.pilih) this.reply(room.p, `${emoji2} الخصم اختار، دورك الآن للاختيار!!`, 0);
    }
    const خيار_1 = room.pilih;
    const خيار_2 = room.pilih2;
    if (room.pilih && room.pilih2) {
      clearTimeout(room.waktu_milih);
      if (حجر.test(خيار_1) && مقص.test(خيار_2)) الفائز = room.p;
      else if (حجر.test(خيار_1) && ورق.test(خيار_2)) الفائز = room.p2;
      else if (مقص.test(خيار_1) && ورق.test(خيار_2)) الفائز = room.p;
      else if (مقص.test(خيار_1) && حجر.test(خيار_2)) الفائز = room.p2;
      else if (ورق.test(خيار_1) && حجر.test(خيار_2)) الفائز = room.p;
      else if (ورق.test(خيار_1) && مقص.test(خيار_2)) الفائز = room.p2;
      else if (خيار_1 == خيار_2) تعادل = true;
      this.reply(room.asal, `
*👑 نتائج التحدي 👑*${تعادل ? '\n*—◉ تعادل!!*' : ''}
*@${room.p.split`@`[0]} (${room.text})* ${تعادل ? '' : room.p == الفائز ? ` *فاز 🥳 +${room.poin}XP*` : ` *خسر 🤡 ${room.poin_lose}XP*`}
*@${room.p2.split`@`[0]} (${room.text2})* ${تعادل ? '' : room.p2 == الفائز ? ` *فاز 🥳 +${room.poin}XP*` : ` *خسر 🤡 ${room.poin_lose}XP*`}
`.trim(), m, {mentions: [room.p, room.p2]} );
      if (!تعادل) {
        db.data.users[الفائز == room.p ? room.p : room.p2].exp += room.poin;
        db.data.users[الفائز == room.p ? room.p : room.p2].exp += room.poin_bot;
        db.data.users[الفائز == room.p ? room.p2 : room.p].exp += room.poin_lose;
      }
      delete this.suit[room.id];
    }
  }
  return !0;
};
handler.exp = 0;
export default handler;
function random(arr) {
  return arr[Math.floor(Math.random() * arr.length)];
}