import { createHash } from 'crypto';  
import fetch from 'node-fetch';

const handler = async (m, { conn, command, usedPrefix, text }) => {

let user = global.db.data.users[m.sender];

if (user.genre) {
return conn.reply(m.chat, `${emoji2} لديك جنس محدد مسبقًا، إذا أردت حذف الجنس الحالي استخدم:\n> » ${usedPrefix}delgenre`, m);
}

if (!text) return conn.reply(m.chat, `${emoji} يجب عليك إدخال جنس صالح.\n> مثال » *${usedPrefix + command} ذكر*`, m);

function asignarGenre(text) {
let genre;
switch (text.toLowerCase()) {
case "ذكر":
case "hombre":
genre = "ذكر";
break;
case "أنثى":
case "mujer":
genre = "أنثى";
break;
default:
return null;
}
return genre;
}

let genre = asignarGenre(text);
if (!genre) {
return conn.reply(m.chat, `${emoji2} تذكر اختيار جنس صالح.\n> مثال: ${usedPrefix + command} ذكر`, m);
}

user.genre = genre;

return conn.reply(m.chat, `${emoji} تم تعيين جنسك كالتالي: *${user.genre}*!`, m);
};

handler.help = ['تعيين_الجنس']
handler.tags = ['rg']
handler.command = ['تعيين جنس', 'setgenre']
export default handler;