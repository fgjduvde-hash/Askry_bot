import fetch from 'node-fetch'

let handler = async (m, { conn, text }) => {
if (!text) return m.reply(`${emoji} أدخل اسم الفيلم\n> *مثال: /cuevana Deadpool*`)

try {
let api = await fetch(`https://delirius-apiofc.vercel.app/search/cuevana?q=${encodeURIComponent(text)}`)
let json = await api.json()

let JT = '🎬 كويڤانا - بحث 🎬';
json.data.forEach((app, index) => {
      JT += `\n\n═══════════════════════`;
      JT += `\n☁️ *الرقم:* ${index + 1}`
      JT += `\n🖼️ *الصورة:* ${app.image}`
      JT += `\n⚜️ *العنوان:* ${app.title}`
      JT += `\n📚 *الوصف:* ${app.description}`
      JT += `\n🔗 *الرابط:* ${app.link}`
}) 

m.reply(JT)
} catch (error) {
console.error(error)
}}

handler.command = ['cuevanasearch', 'cuevana', 'كويڤانا']

export default handler