let handler = async (m, { conn }) => {
  const imageURL = 'https://files.catbox.moe/kxnnsu.jpg'

  let text = `
*💡┇╾⪼ قسم الدين الإسلامي*

> ⩺ ⌟.اذكار — إرسال أذكار عشوائية  
> ⩺ ⌟.قران • .quran — آية من القرآن الكريم  
> ⩺ ⌟.اية — جلب آية عشوائية  
> ⩺ ⌟.حديث — حديث نبوي  
> ⩺ ⌟.دعا • .دعاء — دعاء عشوائي  
> ⩺ ⌟.سورة [الاسم] — تشغيل سورة معينة  
> ⩺ ⌟.رمضان — رسالة رمضانية  
> ⩺ ⌟.القبلة — تحديد اتجاه القبلة  
> ⩺ ⌟.القران_كامل — تحميل القرآن الكريم  
> ⩺ ⌟.مواقيت — معرفة مواقيت الصلاة  

*🎀┇لا تنسَ كتابة (.) قبل كل أمر لاستخدامه!*
`.trim()

  await conn.sendMessage(m.chat, {
    image: { url: imageURL },
    caption: text,
    mentions: [m.sender]
  }, { quoted: m })
}

handler.help = ['س6']
handler.tags = ['menu']
handler.command = /^س6$/i

export default handler