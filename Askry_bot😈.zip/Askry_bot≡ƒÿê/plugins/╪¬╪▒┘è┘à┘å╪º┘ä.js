import { exec } from 'child_process';

let handler = async (m, { conn, text }) => {
  // تأكد أن الأمر يحتوي على نص للتنفيذ
  if (!text) return m.reply('❗️ يرجى كتابة الأمر الذي تريد تنفيذه.');

  // تحقق من صلاحية المستخدم (مثلاً المطور فقط)
  const devs = ['رقمك@s.whatsapp.net']; // غير الرقم إلى رقمك
  if (!devs.includes(m.sender)) {
    return m.reply('❌ أنت غير مخول لتنفيذ هذا الأمر.');
  }

  exec(text, { maxBuffer: 1024 * 500 }, (error, stdout, stderr) => {
    if (error) {
      m.reply(`❌ خطأ:\n${error.message}`);
      return;
    }
    if (stderr) {
      m.reply(`⚠️ تحذير:\n${stderr}`);
      return;
    }
    let output = stdout.trim();
    if (!output) output = '✅ تم تنفيذ الأمر ولكن لا يوجد إخراج.';
    if (output.length > 4000) output = output.slice(0, 4000) + '\n...';
    m.reply(`📥 النتيجة:\n${output}`);
  });
};

handler.help = ['term <الأمر>'];
handler.tags = ['owner'];
handler.command = /^term|shell|exec$/i;

export default handler;