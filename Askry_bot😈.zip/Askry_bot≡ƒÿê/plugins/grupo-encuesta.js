let handler = async (m, { conn, text, args, usedPrefix, command }) => {

  if (!args[0]) throw `${emoji} أدخل نصًا لبدء الاستفتاء.\n\n>📌 مثال : *${usedPrefix + command}* نص|نص2...`;
  if (!text.includes('|')) throw `${emoji2} افصل الخيارات باستخدام *|*\n\n>📌 مثال : *${usedPrefix + command}* نص|نص2...`;

  let opciones = [];
  let partes = text.split('|');
  for (let i = 0; i < partes.length; i++) {
    opciones.push([partes[i]]);
  }

  return conn.sendPoll(m.chat, `${packname}`, opciones, m);
};

handler.help = ['استفتاء <نص|نص2>'];
handler.tags = ['مجموعة'];
handler.command = ['استفتاء', 'poll'];
handler.group = true;

export default handler;