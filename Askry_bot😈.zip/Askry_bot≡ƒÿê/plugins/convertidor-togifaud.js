let handler = async (m, { conn, usedPrefix, command }) => {
if (!m.quoted) return conn.reply(m.chat, `${emoji} من فضلك قم بالرد على *فيديو.*`, m)
conn.reply(m.chat, global.wait, m)
const q = m.quoted || m
let mime = (q.msg || q).mimetype || ''
if (!/(mp4)/.test(mime)) return conn.reply(m.chat, `${emoji} من فضلك قم بالرد على *فيديو.*`, m)
await m.react(rwait)
let media = await q.download()
let listo = '🍬 ها هو لديك ฅ^•ﻌ•^ฅ.'
conn.sendMessage(m.chat, { video: media, gifPlayback: true, caption: listo }, { quoted: fkontak })
await m.react(done)
}
handler.help = ['togifaud']
handler.tags = ['تحويل']
handler.group = true;
handler.register = true
handler.command = ['togifaud', 'لجيف']

export default handler