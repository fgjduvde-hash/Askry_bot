import { areJidsSameUser } from '@whiskeysockets/baileys'

var handler = async (m, { conn, text, participants, args, command }) => {

  let miembros = participants.map(u => u.id)
  let cantidad = !text ? miembros.length : text
  let total = 0
  let fantasmas = []

  for (let i = 0; i < cantidad; i++) {
    let usuario = m.isGroup ? participants.find(u => u.id == miembros[i]) : {}
    if ((typeof global.db.data.users[miembros[i]] == 'undefined' || global.db.data.users[miembros[i]].chat == 0) 
        && !usuario.isAdmin && !usuario.isSuperAdmin) { 
      if (typeof global.db.data.users[miembros[i]] !== 'undefined') {
        if (global.db.data.users[miembros[i]].whitelist == false) {
          total++
          fantasmas.push(miembros[i])
        }
      } else {
        total++
        fantasmas.push(miembros[i])
      }
    }
  }

  const delay = ms => new Promise(res => setTimeout(res, ms))

  switch (command) {

    case 'fantasmas':
      if (total == 0) return conn.reply(m.chat, `${emoji} هذا المجموعة نشطة، لا يوجد أشباح.`, m)
      m.reply(`${emoji} *فحص الغير نشطين*\n\n${emoji2} *قائمة الأشباح*\n${fantasmas.map(v => '@' + v.replace(/@.+/, '')).join('\n')}\n\n*📝 ملاحظة:*\nهذه ليست دقيقة 100%، البوت يبدأ العد من تاريخ تفعيله في هذا الرقم`, null, { mentions: fantasmas })
      break

    case 'kickfantasmas':
      if (total == 0) return conn.reply(m.chat, `${emoji} هذا المجموعة نشطة، لا يوجد أشباح.`, m)
      await m.reply(`${emoji} *حذف الغير نشطين*\n\n${emoji2} *قائمة الأشباح*\n${fantasmas.map(v => '@' + v.replace(/@.+/, '')).join('\n')}\n\n${msm} _*البوت سيحذف المستخدمين في القائمة كل 10 ثواني.*_`, null, { mentions: fantasmas })
      await delay(10000)

      let chat = global.db.data.chats[m.chat]
      chat.welcome = false

      try {
        let users = m.mentionedJid.filter(u => !areJidsSameUser(u, conn.user.id))
        let kickedGhost = fantasmas.map(v => v.id).filter(v => v !== conn.user.jid)
        for (let user of users) {
          if (user.endsWith('@s.whatsapp.net') && !(participants.find(v => areJidsSameUser(v.id, user)) || { admin: true }).admin) {
            let res = await conn.groupParticipantsUpdate(m.chat, [user], 'remove')
            kickedGhost.concat(res)
            await delay(10000)
          }
        }
      } finally {
        chat.welcome = true
      }
      break
  }
}

handler.tags = ['مجموعة']
handler.command = ['fantasmas', 'kickfantasmas']
handler.group = true
handler.botAdmin = true
handler.admin = true
handler.fail = null

export default handler

const delay = ms => new Promise(resolve => setTimeout(resolve, ms))