import db from '../lib/database.js';
import moment from 'moment-timezone';

let المعالج = async (m, { conn, usedPrefix }) => {
    let من = m.mentionedJid[0] ? m.mentionedJid[0] : m.sender;

    if (!(من in global.db.data.users)) {
        return conn.reply(m.chat, `${emoji} المستخدم غير موجود في قاعدة بياناتي.`, m);
    }
    
    let صورة = 'https://raw.githubusercontent.com/The-King-Destroy/Adiciones/main/Contenido/1745557972839.jpeg';
    let المستخدم = global.db.data.users[من];
    let الاسم = conn.getName(من);

    let مميز = المستخدم.premium ? '✅' : '❌';

    let نص = `╭━〔 مخزون ${الاسم} 〕⬣\n` +
              `┋ 💸 *${عملة} في المحفظة:* ${المستخدم.coin || 0}\n` +  
              `┋ 🏦 *${عملة} في البنك:* ${المستخدم.bank || 0}\n` + 
              `┋ ♦️ *الزمرد:* ${المستخدم.emerald || 0}\n` + 
              `┋ 🔩 *الحديد:* ${المستخدم.iron || 0}\n` +  
              `┋ 🏅 *الذهب:* ${المستخدم.gold || 0}\n` + 
              `┋ 🕋 *الفحم:* ${المستخدم.coal || 0}\n` +  
              `┋ 🪨 *الحجر:* ${المستخدم.stone || 0}\n` +  
              `┋ ✨ *الخبرة:* ${المستخدم.exp || 0}\n` + 
              `┋ ❤️ *الصحة:* ${المستخدم.health || 100}\n` + 
              `┋ 💎 *الألماس:* ${المستخدم.diamond || 0}\n` +   
              `┋ 🍬 *الحلوى:* ${المستخدم.candies || 0}\n` + 
              `┋ 🎁 *الهدايا:* ${المستخدم.gifts || 0}\n` + 
              `┋ 🎟️ *التذاكر:* ${المستخدم.joincount || 0}\n` +  
              `┋ ⚜️ *مميز:* ${مميز}\n` + 
              `┋ ⏳ *آخر مغامرة:* ${المستخدم.lastAdventure ? moment(المستخدم.lastAdventure).fromNow() : 'أبدًا'}\n` + 
              `┋ 📅 *التاريخ:* ${new Date().toLocaleString('id-ID')}\n` +
              `╰━━━━━━━━━━━━⬣`;

    await conn.sendFile(m.chat, صورة, 'yuki.jpg', نص, fkontak);
}

المعالج.help = ['المخزون', 'inv'];
المعالج.tags = ['rpg'];
المعالج.command = ['المخزون', 'inv']; 
المعالج.group = true;
المعالج.register = true;

export default المعالج;

