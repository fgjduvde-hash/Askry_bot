let handler = async (m, { conn, usedPrefix, text, args, command }) => {
    // ✅ تفاعل مع الرسالة
    await conn.sendMessage(m.chat, {
        react: {
            text: '🫦',
            key: m.key
        }
    });

    // ✅ تحديد الشخص المقصود
    let who = m.mentionedJid?.[0] || (m.fromMe ? conn.user.jid : m.sender);
    let name = await conn.getName(who);
    let username = await conn.getName(m.sender);

    // ✅ إرسال الصوت
    let audioUrl = 'https://files.catbox.moe/uw5d84.mp3';
    await conn.sendMessage(m.chat, {
        audio: { url: audioUrl },
        mimetype: 'audio/mp4',
        ptt: false
    }, { quoted: m });

    // ✅ بعد 3 ثوانٍ، أرسل جهة الاتصال والرسالة
    setTimeout(async () => {
        // جهة الاتصال
        let list = [{
            displayName: "｢ 𝑨𝒓𝒕𝒉𝒖𝒓𝒔 / 𝑨𝒍𝒊 💤 ｣",
            vcard: `BEGIN:VCARD
VERSION:3.0
FN:｢𝐁𝐀𝐓𝐌𝐀𝐍 💤 / ارثر｣
TEL;type=CELL;waid=218927472437:+218927472437
EMAIL;type=INTERNET:khalifaalialtaheri@gmail.com
URL:https://instagram.com/khalifaalialtahery
ADR:;;ليبيا;;;;
END:VCARD`
        }];

        // ✅ إرسال جهة الاتصال مع بطاقة خارجية
        await conn.sendMessage(m.chat, {
            contacts: {
                displayName: `${list.length} جهة اتصال`,
                contacts: list
            },
            contextInfo: {
                externalAdReply: {
                    showAdAttribution: true,
                    title: 'مرحبا، هذا هو مطور البوت',
                    body: 'للتواصل مع المطور مباشرة',
                    thumbnail: await (await fetch('https://files.catbox.moe/ftzfne.jpg')).buffer(),
                    sourceUrl: 'https://instagram.com/khalifaalialtahery',
                    mediaType: 1,
                    renderLargerThumbnail: true
                }
            }
        }, { quoted: m });

        // ✅ رسالة تعريفية بالمطور
        let txt = `*🍬┇مـرحـبـا يـا* \`${username}\` *هـذا شـات مـطـوري*\n` +
                  `*⌬═━━━━═⊰🌏⊱═━━━━═⌬*\n` +
                  `①➤ ادخل بتحية السلام\n` +
                  `②➤ لا تزعجه بطلبات فارغة\n` +
                  `③➤ السكربت ليس مجاني\n` +
                  `*⌬═━━━━═⊰🌏⊱═━━━━═⌬*\n` +
                  `> هذا الرقم *ليس بوت*`;

        await conn.sendMessage(m.chat, {
            text: txt,
            footer: '｢˚ ₊⊹𝑊𝑎𝑔𝑢𝑟𝑖୨🌸𝐵𝑜𝑡₊｣',
            buttons: [
                {
                    buttonId: ".menu",
                    buttonText: { displayText: '📜 قائمة البوت' },
                    type: 1
                }
            ],
            headerType: 1,
            viewOnce: true
        }, { quoted: m });

    }, 3000);
};

handler.help = ['owner', 'creator'];
handler.tags = ['main'];
handler.command = /^(owner|المطور|مطور|dueño)$/i;

export default handler;