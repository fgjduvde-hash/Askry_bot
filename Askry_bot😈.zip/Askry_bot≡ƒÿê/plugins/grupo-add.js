let handler = async (m, { conn, args, text, usedPrefix, command }) => {
  if (!text) return conn.reply(m.chat, `💀 من فضلك أدخل الرقم الذي تريد إرسال دعوة للمجموعة إليه.`, m);
  if (text.includes('+')) return conn.reply(m.chat, `⚠️ الرجاء إدخال الرقم كاملًا بدون رمز +.`, m);
  if (isNaN(text)) return conn.reply(m.chat, `⚠️ الرجاء إدخال أرقام فقط بدون رمز الدولة وبدون فراغات.`, m);

  let المجموعة = m.chat;
  
  // 🔗 رابط قناتك بدلاً من رابط المجموعة
  let الرابط = 'https://whatsapp.com/channel/0029Vb6z6NO545v2nTgoBa3I';

  await conn.reply(text + '@s.whatsapp.net', `💀 *دعوة من ASKRY BOT*\n\nقام المطور عسكري بدعوتك للانضمام إلى قناتنا الرسمية\n\n${الرابط}`, m, { mentions: [m.sender] });
  m.reply(`💀 تم إرسال رابط القناة للمستخدم.`);
};

handler.help = ['اضف *<2010xxxxxxx>*'];
handler.tags = ['group'];
handler.command = ['add', 'agregar', 'añadir', 'دعوة'];
handler.group = true;
handler.admin = false;
handler.botAdmin = true;

export default handler;