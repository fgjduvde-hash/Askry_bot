let handler = (m, { usedPrefix, command, text }) => {
    if (!text) return conn.reply(m.chat, 
        `${emoji} من فضلك أدخل تاريخ ميلادك بهذا الشكل.\n> مثال: ${usedPrefix + command} 2003 02 07`, 
        m)

    const date = new Date(text)
    if (date == 'تاريخ غير صحيح، جرب الصيغة التالية السنة الشهر اليوم مثال: 2003 02 07') throw date
    
    const d = new Date()
    const [tahun, bulan, tanggal] = [d.getFullYear(), d.getMonth() + 1, d.getDate()]
    const birth = [date.getFullYear(), date.getMonth() + 1, date.getDate()]

    const zodiac = getZodiac(birth[1], birth[2])
    const ageD = new Date(d - date)
    const age = ageD.getFullYear() - new Date(1970, 0, 1).getFullYear()

    const birthday = [tahun + (birth[1] < bulan), ...birth.slice(1)]
    const cekusia = bulan === birth[1] && tanggal === birth[2] ? 
        `${age} - عيد ميلاد سعيد 🎉` : age

    const teks = `
تاريخ الميلاد: ${birth.join('-')}
موعد الميلاد القادم: ${birthday.join('-')}
العمر: ${cekusia}
البرج: ${zodiac}
`.trim()
    m.reply(teks)
}

handler.help = ['برج *2002 02 25*']
handler.tags = ['fun']
handler.group = true
handler.register = true
handler.command = ['برج','zodiac']

export default handler

const zodiak = [
    ["الجدي", new Date(1970, 0, 1)],
    ["الدلو", new Date(1970, 0, 20)],
    ["الحوت", new Date(1970, 1, 19)],
    ["الحمل", new Date(1970, 2, 21)],
    ["الثور", new Date(1970, 3, 21)],
    ["الجوزاء", new Date(1970, 4, 21)],
    ["السرطان", new Date(1970, 5, 22)],
    ["الأسد", new Date(1970, 6, 23)],
    ["العذراء", new Date(1970, 7, 23)],
    ["الميزان", new Date(1970, 8, 23)],
    ["العقرب", new Date(1970, 9, 23)],
    ["القوس", new Date(1970, 10, 22)],
    ["الجدي", new Date(1970, 11, 22)]
].reverse()

function getZodiac(month, day) {
    let d = new Date(1970, month - 1, day)
    return zodiak.find(([_,_d]) => d >= _d)[0]
}