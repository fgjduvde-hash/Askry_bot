let handler = async (m, { conn, command, text }) => {
  if (!text) return m.reply(`${emoji} من فضلك، أدخل سبب الاجتماع.`);
  if (text.length < 10) return m.reply(`${emoji2} من فضلك، أدخل على الأقل 10 أحرف.`);

  let texto = `${emoji2} قام المطوّر @${m.sender.split`@`[0]} ببدء اجتماع. الرجاء الدخول إلى مجموعة الطاقم في أقرب وقت...\n*➪ السبب: ${text}*`;
  m.reply(`${emoji} جارٍ إرسال رسالة الاجتماع إلى جميع المطوّرين...`);

  let mentions = [m.sender];

  for (let [jid] of global.owner.filter(([number, _, isDeveloper]) => isDeveloper && number)) {
    let data = (await conn.onWhatsApp(jid))[0] || {};
    if (data.exists) {
      await conn.sendMessage(data.jid, { text: texto, mentions });
    }
  }
};

handler.tags = ['owner'];
handler.command = handler.help = ['اجتماع', 'اجتماع_الطاقم'];
handler.rowner = true;

export default handler;