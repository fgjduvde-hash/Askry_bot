let handler = async (m, { conn, text, usedPrefix, command }) => {
  if (!text) throw `📚┇اكتب اسم الأمر الذي تريد شرحه\nمثال: ${usedPrefix}${command} ملصق`

  // نبحث عن البلوجن الذي يحتوي هذا الأمر
  let plugin = Object.values(global.plugins).find(plugin =>
    plugin.help &&
    plugin.help.map(cmd => cmd.toLowerCase()).includes(text.toLowerCase())
  )

  if (!plugin) throw `📌┇لم يتم العثور على شرح لهذا الأمر: *${text}*`

  // نعرض تفاصيل الأمر
  let help = plugin.help.map(v => `◾ *${usedPrefix}${v}*`).join('\n')
  let tags = plugin.tags ? Object.values(plugin.tags).join(', ') : 'غير مصنف'
  let description = plugin.description || 'لا يوجد شرح مفصل لهذا الأمر حالياً.'
  let isPremium = plugin.premium ? '✅ يتطلب اشتراك بريميوم' : '❌ لا يتطلب بريميوم'
  let isLimit = plugin.limit ? '✅ يستهلك نقاط' : '❌ لا يستهلك نقاط'

  let response = `
*📖 شرح الأمر: ${text}*

${help}

🗂️ التصنيف: ${tags}
💬 الوصف: ${description}
💎 بريميوم: ${isPremium}
🎯 نقاط/حد: ${isLimit}
`.trim()

  conn.reply(m.chat, response, m)
}

handler.help = ['شرح <أمر>']
handler.tags = ['info']
handler.command = /^شرح$/i

export default handler