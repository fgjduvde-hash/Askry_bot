import { exec } from 'child_process';

let handler = async (m, { conn }) => {
  try {
    await conn.reply(m.chat, '⏳ جاري التحقق من الحزم التي تحتاج تحديث...', m);

    const runCommand = (cmd) => new Promise((resolve, reject) => {
      exec(cmd, (error, stdout, stderr) => {
        if (error) reject(stderr || error.message);
        else resolve(stdout);
      });
    });

    const outdated = await runCommand('npm outdated --json');

    if (!outdated || outdated.trim() === '') {
      await conn.reply(m.chat, '🎉 جميع الحزم محدثة ولا يوجد تحديثات متاحة.', m);
      return;
    }

    let data;
    try {
      data = JSON.parse(outdated);
    } catch {
      await conn.reply(m.chat, `❌ فشل في تحليل بيانات التحديث:\n${outdated}`, m);
      return;
    }

    let message = '📦 الحزم التي تحتاج تحديث:\n\n';
    for (const [pkg, info] of Object.entries(data)) {
      message += `• ${pkg}\n  - الإصدار الحالي: ${info.current}\n  - الإصدار المطلوب: ${info.latest}\n\n`;
    }

    await conn.reply(m.chat, message.trim(), m);

  } catch (e) {
    await conn.reply(m.chat, `❌ حدث خطأ أثناء التحقق من التحديثات:\n${e}`, m);
  }
};

handler.command = /^تحديثات?$/i;
handler.owner = true;  // فقط المطور

export default handler;