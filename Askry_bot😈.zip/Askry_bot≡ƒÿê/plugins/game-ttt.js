import TicTacToe from '../lib/tictactoe.js';

const المعالج = async (m, {conn, usedPrefix, command, text}) => {
  conn.game = conn.game || {};

  if (Object.values(conn.game).find((غرفة) => غرفة.id.startsWith('tictactoe') && [غرفة.game.playerX, غرفة.game.playerO].includes(m.sender))) {
    throw `❌ أنت لا تزال في لعبة مع مستخدم آخر.`;
  }

  if (!text) {
    return m.reply(`🎮 مطلوب اسم غرفة اللعبة\n\n*—◉ مثال*\n*◉ ${usedPrefix + command} غرفة جديدة*`, m.chat);
  }

  let غرفة = Object.values(conn.game).find((غرفة) => غرفة.state === 'WAITING' && (text ? غرفة.name === text : true));

  if (غرفة) {
    await m.reply(`🎮 بدء اللعبة، انضم لاعب جديد إلى المباراة.`);
    غرفة.o = m.chat;
    غرفة.game.playerO = m.sender;
    غرفة.state = 'PLAYING';
    
    const arr = غرفة.game.render().map((v) => {
      return {
        X: '❎',
        O: '⭕',
        1: '1️⃣',
        2: '2️⃣',
        3: '3️⃣',
        4: '4️⃣',
        5: '5️⃣',
        6: '6️⃣',
        7: '7️⃣',
        8: '8️⃣',
        9: '9️⃣',
      }[v];
    });

    const النص = `
🎮 لعبة إكس-أو (تريز إن رايا) 🎮

❎ = @${غرفة.game.playerX.split('@')[0]}
⭕ = @${غرفة.game.playerO.split('@')[0]}

        ${arr.slice(0, 3).join('')}
        ${arr.slice(3, 6).join('')}
        ${arr.slice(6).join('')}

دور اللاعب @${غرفة.game.currentTurn.split('@')[0]}
`.trim();

    if (غرفة.x !== غرفة.o) await conn.sendMessage(غرفة.x, {text: النص, mentions: conn.parseMention(النص)}, {quoted: m});
    await conn.sendMessage(غرفة.o, {text: النص, mentions: conn.parseMention(النص)}, {quoted: m});
  } else {
    غرفة = {
      id: 'tictactoe-' + Date.now(),
      x: m.chat,
      o: '',
      game: new TicTacToe(m.sender, 'o'),
      state: 'WAITING',
      name: text
    };

    const صورة_اللعب = `https://cope-cdnmed.agilecontent.com/resources/jpg/8/9/1590140413198.jpg`;
    conn.reply(m.chat, `*🕹 لعبة إكس-أو (تريز إن رايا) 🎮*\n\n◉ في انتظار اللاعب الثاني\n◉ لحذف أو الخروج من اللعبة استخدم الأمر *${usedPrefix}delttt*\n\n◉ للانضمام إلى اللعبة اكتب: (${usedPrefix + command} ${text})`, m);
    conn.game[غرفة.id] = غرفة;
  }
};

المعالج.command = ['ttt', 'tictactoe'];
المعالج.group = true;
المعالج.register = true;

export default المعالج;