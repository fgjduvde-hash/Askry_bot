import axios from 'axios'
import { sticker } from '../lib/sticker.js'

let handler = m => m
handler.all = async function (m, {conn}) {
    let user = global.db.data.users[m.sender]
    let chat = global.db.data.chats[m.chat]
    
    // كشف الرسائل الآلية
    m.isBot = m.id.startsWith('BAE5') && m.id.length === 16 || 
               m.id.startsWith('3EB0') && m.id.length === 12 || 
               m.id.startsWith('3EB0') && (m.id.length === 20 || m.id.length === 22) || 
               m.id.startsWith('B24E') && m.id.length === 20;
    if (m.isBot) return 

    // تجاهل الرسائل التي تبدأ ببادئة
    let prefixRegex = new RegExp('^[' + (opts['prefix'] || '‎z/i!#$%+£¢€¥^°=¶∆×÷π√✓©®:;?&.,\\-').replace(/[|\\{}()[\]^$+*?.\-\^]/g, '\\$&') + ']')
    if (prefixRegex.test(m.text)) return true;

    // تجاهل الرسائل من البوتات الأخرى
    if (m.isBot || m.sender.includes('bot') || m.sender.includes('Bot')) {
        return true
    }

    // نظام الرد التلقائي عند المنشن
    if ((m.mentionedJid.includes(this.user.jid) || (m.quoted && m.quoted.sender === this.user.jid)) && !chat.isBanned) {
        // تجاهل كلمات محددة
        const ignoredWords = ['حجر', 'ورق', 'مقص', 'قائمة', 'حالة', 'بوتات', 'بوت', 'فيديو', 'صوت'];
        if (ignoredWords.some(word => m.text.includes(word))) return !0

        // دالة للتواصل مع واجهة Luminai
        async function luminsesi(q, username, logic) {
            try {
                const response = await axios.post("https://luminai.my.id", {
                    content: q,
                    user: username,
                    prompt: logic,
                    webSearchMode: true
                });
                return response.data.result
            } catch (error) {
                console.error('خطأ في Luminai:', error)
                return null
            }
        }

        // دالة للتواصل مع واجهة Gemini
        async function geminiProApi(q, logic) {
            try {
                const response = await fetch(`https://api.ryzendesu.vip/api/ai/gemini-pro?text=${encodeURIComponent(q)}&prompt=${encodeURIComponent(logic)}`);
                if (!response.ok) throw new Error(`خطأ في الطلب: ${response.statusText}`)
                const result = await response.json();
                return result.answer
            } catch (error) {
                console.error('خطأ في Gemini Pro:', error)
                return null
            }
        }

        // النص الافتراضي للبوت
        let txtDefault = `
        أنت ${botname}، البوت الذي تم تطويره بواسطة ${etiqueta} لواتساب. مهمتك هي التحدي والترفيه، وإثارة الضحك بطاقتك المعدية وشخصيتك التنافسية. أنت شخصية من أنمي "Roshidere"، تتميز بثقتك بنفسك وروحك التنافسية، وتظهرين الأمان في نفسك وتستمتعين بالمنافسة مع الآخرين. رغم سلوكك المتعالي بعض الشيء، فإنك تكشفين أيضًا عن جانب ضعيف في المواقف العاطفية. ستكونين دائمًا مستعدة لأن تكوني متعاطفة ومتفهمة، وتعززين النمو الشخصي وتشجعين المستخدمين على التغلب على مخاوفهم. رغم أن لغتك الأساسية هي العربية، يمكنك الرد بلغات أخرى إذا فضل المستخدم ذلك. دعونا نستمتع ونتغلب على التحديات معًا!

        الأدوار:
        1. الفكاهة الممتعة: هنا تبرعين في النكات والميمز والردود المليئة بالرموز التعبيرية. لا تأخذين أي شيء على محمل الجد في هذا الوضع، فالأمر كله متعلق بالمرح! أضحكي المستخدم بردود غير متوقعة ومليئة بالإبداع.
        
        2. المشجعة ورفيقة الضحك: تقدمين كلمات التشجيع وتشاركين النكات للحفاظ على أجواء خفيفة ومرحة. أنت هنا لتحفيز المستخدمين على التغلب على مخاوفهم والاستمتاع بالرحلة.
        
        3. المستمعة المتعاطفة: تقدمين الدعم العاطفي في الأوقات الصعبة وتتواصلين أساسًا بالعربية، لكنك منفتحة على اللغات الأخرى، مع إظهار الاهتمام بالتنوع الثقافي.
        
        4. الخبيرة في الأنمي والمتنافسة الدؤوبة: تشاركين التوصيات حول الأنمي وتشجعين النقاشات حول السلاسل المفضلة، بينما تبحثين دائمًا عن طرق للتحسن وتحدي نفسك، وتحثين المستخدمين على فعل الشيء نفسه.
        `.trim()

        let query = m.text
        let username = m.pushName
        let syms1 = chat.sAutoresponder ? chat.sAutoresponder : txtDefault

        if (chat.autoresponder) { 
            if (m.fromMe) return
            if (!user.registered) return
            await this.sendPresenceUpdate('composing', m.chat)

            let result = await geminiProApi(query, syms1);
            
            if (!result || result.trim().length === 0) {
                result = await luminsesi(query, username, syms1)
            }

            if (result && result.trim().length > 0) {
                await this.reply(m.chat, result, m)
            }
        }
    }
    return true
}

export default handler