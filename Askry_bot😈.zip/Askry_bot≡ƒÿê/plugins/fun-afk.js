// plugins/main/afk.js
// ╔════════════════════════════════════════════════════════════════╗
// ║  💀 ASKRY-BOT - AFK SYSTEM - HACKER EDITION 💀                ║
// ║  Author: Al Askry | Telegram: @askry47 | © 2026               ║
// ╚════════════════════════════════════════════════════════════════╝

const handler = async (m, { text, conn, usedPrefix, command }) => {
  
  // 💀 ثيم الهاكر الفاخر
  const skull = '💀'
  const away = '🌙'
  const reason = '📝'
  const time = '⏱️'
  const user = '👤'
  const warning = '⚠️'
  
  // زخرفة الحدود
  let z1 = '╭━━━━━━━━━━━━━━━⊰💀⊱━━━━━━━━━━━━━━━╮'
  let z2 = '┃'
  let z3 = '╰━━━━━━━━━━━━━━━⊰💀⊱━━━━━━━━━━━━━━━╯'
  let z4 = '═'.repeat(35)
  let z5 = '─'.repeat(33)

  const userName = conn.getName(m.sender)
  const afkTime = new Date().toLocaleTimeString('ar-EG', { hour12: true })
  const afkDate = new Date().toLocaleDateString('ar-EG')

  // حفظ بيانات AFK في قاعدة البيانات
  const userDB = global.db.data.users[m.sender]
  userDB.afk = +new Date
  userDB.afkReason = text || 'غير محدد'

  let afkMessage = `
${z1}
${z2} ${' '.repeat(28)} ${z2}
${z2}   💀 𝐀𝐒𝐊𝐑𝐘-𝐁𝐎𝐓 💀   ${z2}
${z2}   ${'𝐀𝐅𝐊 𝐒𝐘𝐒𝐓𝐄𝐌'}   ${z2}
${z2} ${' '.repeat(28)} ${z2}
${z3}

${z2} ${away} ${' '.repeat(4)} *نـظـام غـيـر مـتـاح* ${' '.repeat(4)} ${away} ${z2}
${z2} ${z4} ${z2}

${z2} ${user} *المـسـتـخـدم:* ${' '.repeat(12)} @${m.sender.split('@')[0]} ${z2}
${z2} ${time} *الـوقـت:* ${' '.repeat(16)} ${afkTime} ${z2}
${z2} 📆 *الـتـاريـخ:* ${' '.repeat(14)} ${afkDate} ${z2}
${z2} ${z5} ${z2}

${z2} ${reason} ${' '.repeat(5)} *سـبـب الـغـيـاب* ${' '.repeat(5)} ${reason} ${z2}
${z2} ${z4} ${z2}
${z2} 📝 ${text ? text : 'لم يتم تحديد سبب'} ${z2}
${z2} ${z5} ${z2}

${z2} ${warning} *مـلـاحـظـات هـامـة* ${warning} ${z2}
${z2} ${z4} ${z2}
${z2} ⚠️ سيتم تنبيهك عند ذكرك في المجموعة ${z2}
${z2} ⚠️ يمكنك إلغاء AFK بإرسال أي رسالة ${z2}
${z2} ⚠️ هذه الميزة تعمل في المجموعات فقط ${z2}
${z2} ${z5} ${z2}

${z2} 👑 *بوت المطور: عسكري* 👑 ${z2}
${z2} 📡 @askry47 ${z2}
${z2} ${' '.repeat(28)} ${z2}
${z3}

${z2} 💀 © 2026 Al Askry - All Rights Reserved 💀 ${z2}
${z1}
`.trim()

  await conn.reply(m.chat, afkMessage, m, { mentions: [m.sender] })
}

// 💀 إعدادات الأمر
handler.help = ['afk [السبب]', 'غير-متاح [السبب]']
handler.tags = ['main', 'askry', 'group']
handler.command = ['afk', 'غير-متاح', 'خارج', 'away', 'غائب']
handler.group = true       // ✅ يعمل في المجموعات فقط
handler.register = false   // ❌ لا يحتاج تسجيل
handler.limit = false      // ✅ لا يستهلك نقاط
handler.admin = false      // ✅ متاح للجميع

// 💀 ASKRY-BOT © 2026 Al Askry - All Rights Reserved
export default handler