const handler = async (m, {conn, text, usedPrefix, command}) => {
  if (!text) throw `${emoji} لم يتم العثور على بادئة، من فضلك اكتب بادئة.\n> *مثال: ${usedPrefix + command} !*`;
  global.prefix = new RegExp('^[' + (text || global.opts['prefix'] || '‎xzXZ/i!#$%+£¢€¥^°=¶∆×÷π√✓©®:;?&.\\-').replace(/[|\\{}()[\]^$+*?.\-\^]/g, '\\$&') + ']');
  // await m.reply(`*✅️ تم تحديث البادئة بنجاح، البادئة الحالية: ${text}*`);
  conn.fakeReply(m.chat, `${done} *تم تحديث البادئة بنجاح، البادئة الحالية: ${text}*`, '0@s.whatsapp.net', '✨ البادئة الجديدة ✨')
};
handler.help = ['بيرفكس'].map((v) => v + ' [البادئة]');
handler.tags = ['owner'];
handler.command = ['بيرفكس'];
handler.rowner = true;

export default handler;