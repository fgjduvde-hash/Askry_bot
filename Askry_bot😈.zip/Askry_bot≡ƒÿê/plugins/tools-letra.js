function handler(m, { text }) {
  if (!text) return conn.reply(m.chat, `${emoji} من فضلك أدخل النص الذي تريد تحويله.`, m)

  let teks = text ? text : m.quoted && m.quoted.text ? m.quoted.text : m.text
  m.reply(teks.replace(/[a-z]/gi, v => {
    return {
      'a': 'ᥲ',
      'b': 'ᑲ',
      'c': 'ᥴ',
      'd': 'ძ',
      'e': 'ᥱ',
      'f': '𝖿',
      'g': 'g',
      'h': 'һ',
      'i': 'і',
      'j': 'ȷ',
      'k': 'k',
      'l': 'ᥣ',
      'm': 'm',
      'n': 'ᥒ',
      'o': '᥆',
      'p': '⍴',
      'q': '𝗊',
      'r': 'r',
      's': 's',
      't': '𝗍',
      'u': 'ᥙ',
      'v': '᥎',
      'w': 'ᥕ',
      'x': '᥊',
      'y': 'ᥡ',
      'z': 'z'
    }[v.toLowerCase()] || v
  }))
}

handler.help = ['حروف *<نص>*']
handler.tags = ['مرح']
handler.command = ['حروف']
handler.register = true

export default handler