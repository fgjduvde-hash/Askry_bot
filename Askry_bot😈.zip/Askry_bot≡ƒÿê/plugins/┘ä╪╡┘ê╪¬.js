import ffmpeg from 'fluent-ffmpeg'
import fs from 'fs'
import { tmpdir } from 'os'
import path from 'path'

let handler = async (m, { conn }) => {
  let q = m.quoted ? m.quoted : m
  let mime = (q || m.msg).mimetype || ''

  if (!/video|audio/.test(mime)) throw `*✳️ قم بالرد على فيديو أو صوت لتحويله إلى صوت mp3*`

  let media = await q.download?.()
  if (!media) throw '❎ فشل تحميل الوسائط'

  let filename = path.join(tmpdir(), `${Date.now()}.mp4`)
  let outname = path.join(tmpdir(), `${Date.now()}.mp3`)
  fs.writeFileSync(filename, media)

  await new Promise((resolve, reject) => {
    ffmpeg(filename)
      .output(outname)
      .audioCodec('libmp3lame')
      .on('end', () => resolve())
      .on('error', err => reject(err))
      .run()
  })

  await conn.sendFile(m.chat, outname, 'audio.mp3', '', m, null, { mimetype: 'audio/mp4' })
  fs.unlinkSync(filename)
  fs.unlinkSync(outname)
}

handler.help = ['tomp3']
handler.tags = ['audio']
handler.command = /^(لصوت|لفويس|tomp3)$/i
handler.register = true

export default handler