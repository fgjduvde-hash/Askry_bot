import axios from 'axios';
import cheerio from 'cheerio';

let handler = async (m, { conn, text }) => {
  if (!text) return conn.reply(m.chat, `${emoji} من فضلك اكتب ما تريد البحث عنه في ويكيبيديا.`, m);
  
  try {
    const response = await axios.get(`https://es.wikipedia.org/wiki/${encodeURIComponent(text)}`);
    const $ = cheerio.load(response.data);

    const title = $('#firstHeading').text().trim();
    const paragraph = $('#mw-content-text > div.mw-parser-output > p').first().text().trim();

    if (!paragraph) {
      return conn.reply(m.chat, `${emoji2} لم يتم العثور على نتائج لطلبك.`, m);
    }

    m.reply(`▢ *Wikipedia*

‣ تم البحث عن: ${title}

${paragraph}`);
  } catch (e) {
    m.reply(`${emoji2} حدث خطأ أو لم يتم العثور على نتائج.`, m);
  }
};

handler.help = ['wikipedia'];
handler.tags = ['tools'];
handler.command = ['ويكي', 'wikipedia'];

export default handler;