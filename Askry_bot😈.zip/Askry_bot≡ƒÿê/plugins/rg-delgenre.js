const handler = async (m, { conn, command, usedPrefix }) => {

  const user = global.db.data.users[m.sender];

  if (!user.genre) {
    return conn.reply(m.chat, `${emoji2} لم تقم بتعيين جنس.`, m);
  }

  user.genre = '';

  return conn.reply(m.chat, `${emoji} تم حذف الجنس الخاص بك.`, m);
};

handler.help = ['جنسي'];
handler.tags = ['rg'];
handler.command = ['جنسي', 'حذف جنسي'];
export default handler;