let handler = async (m, { conn, text }) => {
  let المبلغ = parseInt(text.trim());

  if (isNaN(المبلغ) || المبلغ <= 0) {
    return conn.reply(m.chat, `${emoji} من فضلك أدخل كمية صحيحة من ${moneda}.`, m);
  }

  let الرمز = Math.random().toString(36).substring(2, 10).toUpperCase();

  if (!global.db.data.codes) global.db.data.codes = {};
  global.db.data.codes[الرمز] = { coin: المبلغ, claimedBy: [] };

  conn.reply(m.chat, `${emoji} تم إنشاء رمز: *${الرمز}*\nيمكن استبدال هذا الرمز بـ ${المبلغ} ${moneda} ويمكن استخدامه من قبل 50 شخصًا.`, m);
}

handler.help = ['رمز <كمية العملات>'];
handler.tags = ['مالك'];
handler.command = ['رمز'];
handler.rowner = true;

export default handler;