let handler = async (m, { conn, usedPrefix, command, args }) => {
  if (!(m.chat in global.db.data.chats)) {
    return conn.reply(m.chat, `《✦》هذا الدردشة غير مسجلة!`, m);
  }

  let chat = global.db.data.chats[m.chat];

  if (command === 'bot') {
    if (args.length === 0) {
      const estado = chat.isBanned ? '✗ معطل' : '✓ مفعل';
      const info = `
「✦」يمكن للمشرف تفعيل أو تعطيل *${botname}* باستخدام:

> ✐ *${usedPrefix}bot on* للتفعيل
> ✐ *${usedPrefix}bot off* للتعطيل

✧ الحالة الحالية » *${estado}*
`;
      return conn.reply(m.chat, info, m);
    }

    if (args[0] === 'off') {
      if (chat.isBanned) {
        return conn.reply(m.chat, `《✧》${botname} كان معطلًا بالفعل.`, m);
      }
      chat.isBanned = true;
      return conn.reply(m.chat, `✐ لقد *عطلت* ${botname}!`, m);
    } else if (args[0] === 'on') {
      if (!chat.isBanned) {
        return conn.reply(m.chat, `《✧》*${botname}* كان مفعلًا بالفعل.`, m);
      }
      chat.isBanned = false;
      return conn.reply(m.chat, `✐ لقد *فعّلت* ${botname}!`, m);
    }
  }
};

handler.help = ['bot'];
handler.tags = ['group'];
handler.command = ['bot'];
handler.admin = true;

export default handler;