export async function before(m, {conn, isAdmin, isBotAdmin, isOwner, isROwner}) {
  // تجاهل الرسائل من البوت نفسه
  if (m.isBaileys && m.fromMe) return !0;
  
  // تجاهل المجموعات
  if (m.isGroup) return !1;
  
  // تجاهل الرسائل غير النصية
  if (!m.message) return !0;
  
  // كلمات ممنوعة في الخاص
  const forbiddenWords = ['PIEDRA', 'PAPEL', 'TIJERA', 'serbot', 'jadibot'];
  if (forbiddenWords.some(word => m.text.includes(word))) return !0;
  
  // تجاهل النشرات الإخبارية
  if (m.chat === '120363403628890197@newsletter') return !0;
  
  const chat = global.db.data.chats[m.chat];
  const bot = global.db.data.settings[this.user.jid] || {};
  
  // نظام منع الخاص
  if (bot.antiPrivate && !isOwner && !isROwner) {
    const userMention = `@${m.sender.split('@')[0]}`;
    const warningMessage = `
⚠️ *مرحبًا ${userMention}* ⚠️

لقد قام المطور بإيقاف الأوامر في الدردشات الخاصة.
سيتم حظرك من استخدام البوت.

إذا كنت ترغب باستخدام البوت، يرجى الانضمام للمجموعة الرسمية:
${gp1}

مع تحياتي،
بوت ${this.user.name}
    `;
    
    // إرسال التحذير
    await m.reply(warningMessage, false, {mentions: [m.sender]});
    
    // حظر المستخدم
    await this.updateBlockStatus(m.chat, 'block');
    
    // تسجيل الحادث في الكونسول
    console.log(`[PRIVATE BLOCK] تم حظر ${m.sender} بسبب محاولة استخدام البوت في الخاص`);
  }
  
  return !1;
}