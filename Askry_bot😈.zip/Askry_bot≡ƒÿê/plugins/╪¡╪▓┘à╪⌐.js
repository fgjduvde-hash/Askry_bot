import { promises as fs } from 'fs'
import path from 'path'
import { sticker5 } from '../../lib/sticker.js'

let handler = async (m, { conn, text }) => {
  if (!text) return m.reply('❗ اكتب اسم الحزمة مثل:\n.حزمة ذكرياتي')

  const packName = text.trim().replace(/\s+/g, '_')
  const tmpDir = path.resolve('./tmp/stickerpacks', packName)
  await fs.mkdir(tmpDir, { recursive: true })

  let mediaMessages = []

  // صور في نفس الرسالة
  if (m.message?.imageMessage) mediaMessages.push(m)

  // صور في الرد
  if (m.quoted?.message?.imageMessage) mediaMessages.push(m.quoted)

  // صور من آخر 10 رسائل
  if (!mediaMessages.length) {
    let chat = conn.chats[m.chat]
    if (chat && chat.messages) {
      let recentMsgs = [...chat.messages.values()]
        .filter(m => m?.message?.imageMessage && m?.key)
        .slice(-10)
      for (let msg of recentMsgs) {
        mediaMessages.push({
          key: msg.key,
          message: msg.message
        })
      }
    }
  }

  if (!mediaMessages.length) return m.reply('❗ لم يتم العثور على صور لتحويلها.')

  await m.reply(`⏳ جاري تجهيز حزمة "${packName}" من ${mediaMessages.length} صورة...`)

  let sent = 0
  for (let i = 0; i < mediaMessages.length; i++) {
    const msg = mediaMessages[i]
    try {
      const buffer = await conn.downloadM(msg)
      if (!buffer || buffer.length < 1000) {
        await m.reply(`⚠️ تخطي الصورة رقم ${i + 1}: لم يتم تنزيلها بشكل صحيح.`)
        continue
      }

      const stkr = await sticker5(buffer, null, packName, '💤 Arthurs / Ali')
      const filePath = path.join(tmpDir, `sticker_${i + 1}.webp`)
      await fs.writeFile(filePath, stkr)
      await conn.sendFile(m.chat, stkr, `sticker_${i + 1}.webp`, '', m)
      sent++
    } catch (err) {
      console.error('❌ خطأ أثناء تحويل صورة رقم ' + (i + 1), err)
      await m.reply(`❌ فشل تحويل صورة رقم ${i + 1}`)
    }
  }

  if (sent > 0) {
    await conn.sendMessage(m.chat, {
      text: `✅ تم إرسال ${sent} ملصق من حزمة "${packName}".`,
      footer: '💤 Arthurs / Ali',
      buttons: [
        {
          buttonId: `.حزمة ${packName}`,
          buttonText: { displayText: `📦 عرض الحزمة مرة أخرى` },
          type: 1
        }
      ],
      headerType: 1
    }, { quoted: m })
  } else {
    await m.reply('❌ لم يتم إنشاء أي ملصق.')
  }
}

handler.command = ['حزمة']
handler.help = ['حزمة <اسم>']
handler.tags = ['sticker']
export default handler