// استيراد الدوال المطلوبة من مكتبة Baileys
const {
    proto,
    generateWAMessage,
    areJidsSameUser
} = (await import('@whiskeysockets/baileys')).default

// تصدير دالة تعالج كل الرسائل الواردة
export async function all(m, chatUpdate) {
    // إذا كانت الرسالة من البوت نفسه، توقف
    if (m.isBaileys) return
    // إذا لم يكن هناك محتوى رسالة، توقف
    if (!m.message) return
    // إذا لم يكن هناك ملف (مثل ملصق)، توقف
    if (!m.msg.fileSha256) return
    // إذا لم يكن هناك تطابق بين هاش الملصق والبيانات المحفوظة، توقف
    if (!(Buffer.from(m.msg.fileSha256).toString('base64') in global.db.data.sticker)) return

    // جلب البيانات المخزنة للملصق (النص والجهات المذكورة)
    let hash = global.db.data.sticker[Buffer.from(m.msg.fileSha256).toString('base64')]
    let { text, mentionedJid } = hash

    // إنشاء رسالة واتساب جديدة بنفس النص والإشارات
    let messages = await generateWAMessage(m.chat, { text: text, mentions: mentionedJid }, {
        userJid: this.user.id,
        quoted: m.quoted && m.quoted.fakeObj
    })

    // تحديد إذا كانت الرسالة مرسلة من البوت أو مستخدم آخر
    messages.key.fromMe = areJidsSameUser(m.sender, this.user.id)
    // تعيين معرف الرسالة وناشرها
    messages.key.id = m.key.id
    messages.pushName = m.pushName
    // إذا كانت المجموعة، أضف المرسل كـ "مشارك"
    if (m.isGroup) messages.participant = m.sender

    // إعداد تحديث الدردشة وإرسال الرسالة
    let msg = {
        ...chatUpdate,
        messages: [proto.WebMessageInfo.fromObject(messages)],
        type: 'append'
    }
    // إطلاق حدث لإضافة الرسالة
    this.ev.emit('messages.upsert', msg)
}