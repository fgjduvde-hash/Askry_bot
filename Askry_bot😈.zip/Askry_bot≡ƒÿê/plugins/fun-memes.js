import hispamemes from 'hispamemes'
let handler = async (m, { conn, usedPrefix, command }) => {
const meme = hispamemes.meme()
conn.sendFile(m.chat, meme, '', '', m)
m.react(emoji2)
}
handler.help = ['ميمز']
handler.tags = ['fun']
handler.command = ['ميمز', 'ميم']
handler.coin = 1
handler.group = true;
handler.register = true

export default handler