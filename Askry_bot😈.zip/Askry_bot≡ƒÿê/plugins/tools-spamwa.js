const handler = async (m, { conn, text }) => {
  const [nomor, pesan, jumlah] = text.split('|');

  if (!nomor) return conn.reply(m.chat, `${emoji} من فضلك أدخل رقم لإرسال الرسائل المتكررة.`, m);

  if (!pesan) return conn.reply(m.chat, `${emoji2} الاستخدام الصحيح:\n\n> ${emoji2} #spamwa رقم|نص|الكمية`, m);

  if (jumlah && isNaN(jumlah)) return conn.reply(m.chat, `${emoji2} يجب أن تكون الكمية رقمًا.`, m);

  const fixedNumber = nomor.replace(/[-+<>@]/g, '').replace(/ +/g, '').replace(/^[0]/g, '62') + '@s.whatsapp.net';
  const fixedJumlah = jumlah ? Number(jumlah) : 10;

  if (fixedJumlah > 999) return conn.reply(m.chat, `${emoji3} الحد الأقصى هو 999 رسالة.`, m);

  await conn.reply(m.chat, `${emoji4} تم إرسال الرسائل بنجاح.`, m);
  for (let i = fixedJumlah; i > 1; i--) {
    if (i !== 0) conn.reply(fixedNumber, pesan.trim(), null);
  }
};

handler.help = ['spamwa <رقم>|<رسالة>|<عدد الرسائل>'];
handler.tags = ['أدوات'];
handler.command = ['2سبام', 'spamwa'];
handler.premium = true;

export default handler;