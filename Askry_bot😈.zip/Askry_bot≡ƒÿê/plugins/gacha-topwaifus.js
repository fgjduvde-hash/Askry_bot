import { promises as fs } from 'fs'

const مسار_الشخصيات = './src/database/characters.json'

async function تحميل_الشخصيات() {
    try {
        const البيانات = await fs.readFile(مسار_الشخصيات, 'utf-8')
        return JSON.parse(البيانات)
    } catch (خطأ) {
        throw new Error('《✧》تعذر تحميل ملف الشخصيات.')
    }
}

let handler = async (m, { conn, args }) => {
    try {
        const الشخصيات = await تحميل_الشخصيات()
        const الصفحة = parseInt(args[0]) || 1
        const عدد_لكل_صفحة = 10
        const الشخصيات_المرتبة = الشخصيات.sort((a, b) => Number(b.value) - Number(a.value))

        const المجموع = الشخصيات_المرتبة.length
        const عدد_الصفحات = Math.ceil(mجموع / عدد_لكل_صفحة)
        const البداية = (الصفحة - 1) * عدد_لكل_صفحة
        const النهاية = البداية + عدد_لكل_صفحة

        const المعروض = الشخصيات_المرتبة.slice(البداية, النهاية)

        let الرسالة = '❀ *أعلى الشخصيات قيمة:*\n'
        المعروض.forEach((شخصية, ترتيب) => {
            الرسالة += `✰ ${البداية + ترتيب + 1} » *${شخصية.name}*\n`
            الرسالة += `\t\t→ القيمة: *${شخصية.value}*\n`
        })

        الرسالة += `> • صفحة *${الصفحة}* من *${عدد_الصفحات}*.`

        await conn.reply(m.chat, الرسالة, m)
    } catch (خطأ) {
        await conn.reply(m.chat, `✘ حدث خطأ أثناء تحميل الشخصيات: ${خطأ.message}`, m)
    }
}

handler.help = ['افضل عشر شخصيات [رقم_الصفحة]']
handler.tags = ['anime']
handler.command = ['افضل شخصيات', 'topwaifus', 'waifustop', 'waifusboard']
handler.group = true
handler.register = true

export default handler