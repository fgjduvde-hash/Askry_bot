import fetch from 'node-fetch'

let handler = async (m, { conn, command, args }) => {
  if (!args[0]) return conn.reply(m.chat, `${emoji} من فضلك أدخل رابط الصفحة.`, m)
  try {
    await m.react(rwait)
    conn.reply(m.chat, `${emoji2} جاري البحث عن المعلومات....`, m)
    let ss = await (await fetch(`https://image.thum.io/get/fullpage/${args[0]}`)).buffer()
    conn.sendFile(m.chat, ss, 'error.png', args[0], fkontak)
    await m.react(done)
  } catch {
    await m.react(error)
    return conn.reply(m.chat, `${msm} حدث خطأ.`, m)
  }
}

handler.help = ['ssweb', 'ss']
handler.tags = ['أدوات']
handler.command = ['بحث', 'ss']

export default handler