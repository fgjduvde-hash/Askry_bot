let handler = async (m, { conn, usedPrefix }) => {
    let user = global.db.data.users[m.sender]
    let name = conn.getName(m.sender) || 'مستخدم'
    let taguser = '@' + m.sender.split("@")[0]
    
    // معلومات الوقت والتاريخ
    let currentTime = new Date().toLocaleTimeString('ar-EG', { hour: '2-digit', minute: '2-digit' })
    let currentDate = new Date().toLocaleDateString('ar-EG')
    
    // معلومات المجموعة
    let groupInfo = m.isGroup ? await conn.groupMetadata(m.chat) : null
    let groupName = groupInfo ? groupInfo.subject : 'خاص'
    
    // نص القائمة
    let decorateMenu = `
*✨┇╾⪼ مــرحــبــاً يــ ❪${taguser}❫*

> *┃🎨 ┊❝ قــســم الــزخــارف والــتــصــامــيــم ❞┊⚡┃*  

*· • • ━ ╃✾⊰ ✨ ⊱✾╄ ━ • • ·*  
 
*⚡ هــذا الــقــســم يــحــتــوي عــلــى أوامــر الــزخــارف والــتــصــامــيــم الــجــمــيــلــة ⚡*

> ˚‧︵‿₊୨✨୧₊‿︵‧ ˚ ₊⊹ ⊹₊ ⚡˚‧︵‿₊  

˚ ₊⊹ *✨ لا تــنــســى كــتــابــة (${usedPrefix}) قــبــل كــل امـــر ✨˚ ₊⊹*  

> *──⊰◈⚡◈⊱─*
> 🌈 ⩺ ⌟${usedPrefix}font⌜  𖢿˚ ₊⊹ *تغيير خط النص*
> ✍️ ⩺ ⌟${usedPrefix}neon⌜  𖤊˚ ₊⊹ *زخارف نيون مميزة*
> 🎀 ⩺ ⌟${usedPrefix}floral⌜  𖣋˚ ₊⊹ *زخارف نباتية*
> 🌙 ⩺ ⌟${usedPrefix}islamic⌜  𖣲˚ ₊⊹ *زخارف إسلامية*
> 💫 ⩺ ⌟${usedPrefix}glitter⌜  𖣕˚ ₊⊹ *زخارف براقة*
> 🔥 ⩺ ⌟${usedPrefix}burn⌜  𖤗˚ ₊⊹ *نصوص نارية*
> ❄️ ⩺ ⌟${usedPrefix}snow⌜  𖤤˚ ₊⊹ *زخارف ثلجية*
> 🌸 ⩺ ⌟${usedPrefix}flower⌜ 𖥕˚ ₊⊹ *زخارف زهور*
> 🎆 ⩺ ⌟${usedPrefix}firework⌜ 𖥡˚ ₊⊹ *زخارف ألعاب نارية*
> 🖋️ ⩺ ⌟${usedPrefix}calligraphy⌜ 𖦜˚ ₊⊹ *زخارف خطاطة*
> 💎 ⩺ ⌟${usedPrefix}diamond⌜  𖦤˚ ₊⊹ *زخارف ماسية*
> 🧿 ⩺ ⌟${usedPrefix}arabic⌜  𖧶 ˚ ₊⊹ *زخارف عربية*
> 🌠 ⩺ ⌟${usedPrefix}sky⌜  𖦏 ˚ ₊⊹ *زخارف سماوية*
> *╯──⊰◈⚡◈⊱──╰*  

*💡 مـلاحـظـة: يـمـكـنـك كـتـابـة (${usedPrefix}allmenu) لـعـرض كـافـة اوامـر الـبـوت 💡*

*· • • ━ ╃✾⊰✨⊱✾╄ ━ • • ·*
> ⪼ 𝑌𝑢𝑘𝑖 𝑆𝑢𝑜𝑢 ୨🎨୧ 𝐵𝑜𝑡
> ⪼ ✰✰𝐵𝐴𝑇𝑂⏤͟͟͞͞​᭄💤🇹🇷
> ⏱️ الوقت: ${currentTime}
> 📆 التاريخ: ${currentDate}
> 💬 المجموعة: ${groupName}

> ˚‧︵‿₊୨✨୧₊‿︵‧ ˚ ₊⊹ ⊹₊ ⚡˚‧︵‿₊`

    try {
        // إرسال رد فعل
        await conn.sendMessage(m.chat, { 
            react: { 
                text: '✨', 
                key: m.key 
            } 
        })

        // إرسال القائمة مع صورة
        await conn.sendMessage(m.chat, {
            image: { url: 'https://files.catbox.moe/e8mqtc.jpg' },
            caption: decorateMenu,
            mentions: [m.sender]
        }, { quoted: m })

    } catch (error) {
        console.error('حدث خطأ في عرض قائمة الزخارف:', error)
        await conn.sendMessage(m.chat, {
            text: '❌ حدث خطأ في عرض القائمة، يرجى المحاولة لاحقاً.',
            mentions: [m.sender]
        }, { quoted: m })
    }
}

// تعريف الأمر
handler.help = ['decorate', 'زخارف', '🌸┊「قــســم الزخــارف」🎴']
handler.tags = ['decorate', 'design']
handler.command = /^(زخارف|decorate|decoratemenu|قسم-الزخارف|تصاميم|زخرفة)$/i

export default handler