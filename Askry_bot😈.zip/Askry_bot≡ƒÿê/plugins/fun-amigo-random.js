
let toM = a => '@' + a.split('@')[0]
function handler(m, { groupMetadata }) {
let ps = groupMetadata.participants.map(v => v.id)
let a = ps.getRandom()
let b
do b = ps.getRandom()
while (b === a)
m.reply(`${emoji} لنصنع بعض الصداقات.\n\n*يا ${toM(a)} تواصل مع ${toM(b)} على الخاص للعب وبناء صداقة 🙆*\n\n*أفضل الصداقات تبدأ بلعبة 😉.*`, null, {
mentions: [a, b]
})}
handler.help = ['صداقة']
handler.tags = ['مرح']
handler.command = ['صديق-عشوائي','صداقة']
handler.group = true
handler.register = true

export default handler