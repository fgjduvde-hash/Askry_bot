import { promises as fs } from 'fs'

const charactersFilePath = './src/database/characters.json'
const haremFilePath = './src/database/harem.json'

async function تحميل_الشخصيات() {
    try {
        const data = await fs.readFile(charactersFilePath, 'utf-8')
        return JSON.parse(data)
    } catch (error) {
        throw new Error('✘ فشل في تحميل ملف الشخصيات.')
    }
}

async function تحميل_الحريم() {
    try {
        const data = await fs.readFile(haremFilePath, 'utf-8')
        return JSON.parse(data)
    } catch (error) {
        return []
    }
}

let handler = async (m, { conn, args }) => {
    if (args.length === 0) {
        await conn.reply(m.chat, `📌 يرجى كتابة اسم الشخصية.`, m)
        return
    }

    const اسم_الشخصية = args.join(' ').toLowerCase().trim()

    try {
        const الشخصيات = await تحميل_الشخصيات()
        const الشخصية = الشخصيات.find(c => c.name.toLowerCase() === اسم_الشخصية)

        if (!الشخصية) {
            await conn.reply(m.chat, `✘ لم يتم العثور على الشخصية *${اسم_الشخصية}*. تأكد من كتابة الاسم بشكل صحيح.`, m)
            return
        }

        const صورة_عشوائية = الشخصية.img[Math.floor(Math.random() * الشخصية.img.length)]

        const الرسالة = `🎀 *الاسم:* ${الشخصية.name}
⚥ *الجنس:* ${الشخصية.gender}
📚 *المصدر:* ${الشخصية.source}`

        await conn.sendFile(m.chat, صورة_عشوائية, `${الشخصية.name}.jpg`, الرسالة, m)
    } catch (error) {
        await conn.reply(m.chat, `✘ حدث خطأ أثناء تحميل صورة الشخصية:\n${error.message}`, m)
    }
}

handler.help = ['صورة <اسم>']
handler.tags = ['انمي']
handler.command = ['صورة', 'صورة_وايفو', 'صورةشخصية']
handler.group = true

export default handler