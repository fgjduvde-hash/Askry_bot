import fs from 'fs';

let handler = async (m, { conn, text, command, usedPrefix }) => {
    const fileName = text?.trim();
    const filePath = `plugins/${fileName}.js`;

    if (!fileName) {
        return m.reply(`❗ يرجى كتابة اسم الملف بعد الأمر.\n📌 مثال: *${usedPrefix + command} اسم_الملف*`);
    }

    if (command === 'احفظ') {
        const q = m.quoted || m;
        const mime = q.mimetype || '';
        const isText = !!q.text;

        if (!isText && !mime) {
            return m.reply('❗ يرجى الرد على رسالة نصية أو ملف JavaScript لحفظه.');
        }

        try {
            let content = '';

            if (isText) {
                content = q.text.trim();
            } else if (mime === 'application/javascript') {
                const buffer = await q.download();
                content = buffer.toString('utf-8').trim();
            } else {
                return m.reply('❗ نوع الملف غير مدعوم. فقط ملفات JavaScript مدعومة.');
            }

            if (!content) {
                return m.reply('❗ الملف فارغ أو لا يحتوي على محتوى صالح.');
            }

            fs.writeFileSync(filePath, content, 'utf8');
            return m.reply(`✅ تم حفظ الملف بنجاح:\n📄 *${filePath}*`);
        } catch (err) {
            return m.reply(`❌ حدث خطأ أثناء حفظ الملف:\n${err.message}`);
        }

    } else if (command === 'امسح') {
        if (!fs.existsSync(filePath)) {
            return m.reply(`❗ الملف غير موجود:\n📄 *${filePath}*`);
        }

        try {
            fs.unlinkSync(filePath);
            return m.reply(`✅ تم حذف الملف بنجاح:\n🗑️ *${filePath}*`);
        } catch (err) {
            return m.reply(`❌ حدث خطأ أثناء حذف الملف:\n${err.message}`);
        }

    } else {
        return m.reply(`❗ أمر غير معروف.\nالأوامر المتاحة:\n- *${usedPrefix}احفظ*\n- *${usedPrefix}امسح*`);
    }
};

handler.help = ['احفظ', 'امسح'];
handler.tags = ['owner'];
handler.command = ['احفظ', 'امسح'];
handler.owner = true;

export default handler;