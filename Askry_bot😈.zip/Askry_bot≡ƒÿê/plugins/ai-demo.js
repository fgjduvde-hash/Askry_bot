import { randomBytes } from "crypto"
import axios from "axios"

let handler = async (m, { conn, text }) => {
    if (!text) throw `${emoji} كيف يمكنني مساعدتك اليوم؟`;
    try {
        conn.reply(m.chat, m);
        let data = await chatGpt(text);
        await conn.sendMessage(m.chat, { 
            text: '*تجريبية:* ' + data
        }, { quoted: m });

    } catch (err) {
        m.reply('حدث خطأ :/ ' + err);
    }
}

handler.help = ['تجريبية *<نص>*'];
handler.command = ['تجريبية', 'openai'];
handler.tags = ['ذكاء'];
handler.group = true;

export default handler;

async function chatGpt(query) {
    try {
        const { id_ } = (await axios.post("https://chat.chatgptdemo.net/new_chat", { user_id: "crqryjoto2h3nlzsg" }, { headers: { "Content-Type": "application/json" } })).data;

        const json = { "question": query, "chat_id": id_, "timestamp": new Date().getTime() };

        const { data } = await axios.post("https://chat.chatgptdemo.net/chat_api_stream", json, { headers: { "Content-Type": "application/json" } });
        const cek = data.split("data: ");

        let res = [];

        for (let i = 1; i < cek.length; i++) {
            if (cek[i].trim().length > 0) {
                res.push(JSON.parse(cek[i].trim()));
            }
        }

        return res.map((a) => a.choices[0].delta.content).join("");

    } catch (error) {
        console.error("خطأ في تحليل JSON:", error);
        return 404;
    }
}