let WAMessageStubType = (await import('@whiskeysockets/baileys')).default

let handler = m => m
handler.before = async function (m, { conn, participants, groupMetadata }) {
    if (!m.messageStubType || !m.isGroup) return
    
    const fkontak = { 
        "key": { 
            "participants": "0@s.whatsapp.net", 
            "remoteJid": "status@broadcast", 
            "fromMe": false, 
            "id": "Halo" 
        }, 
        "message": { 
            "contactMessage": { 
                "vcard": `BEGIN:VCARD\nVERSION:3.0\nN:Sy;Bot;;;\nFN:y\nitem1.TEL;waid=${m.sender.split('@')[0]}:${m.sender.split('@')[0]}\nitem1.X-ABLabel:Ponsel\nEND:VCARD` 
            }
        }, 
        "participant": "0@s.whatsapp.net"
    }
    
    let chat = global.db.data.chats[m.chat]
    let usuario = `@${m.sender.split('@')[0]}`
    let pp = await conn.profilePictureUrl(m.chat, 'image').catch(_ => null) || 'https://files.catbox.moe/xr2m6u.jpg'

    // تعريف الرسائل بالعربية
    const messages = {
        nameChanged: `📛 *تغيير اسم المجموعة* 📛\n\nقام ${usuario} بتغيير اسم المجموعة\n\n✏️ *الاسم الجديد*:\n${m.messageStubParameters[0]}`,
        picChanged: `🖼️ *تغيير صورة المجموعة* 🖼️\n\nقام ${usuario} بتغيير صورة المجموعة`,
        settingsChanged: `⚙️ *تغيير إعدادات المجموعة* ⚙️\n\nقام ${usuario} بتغيير صلاحيات ${m.messageStubParameters[0] == 'on' ? 'للمشرفين فقط' : 'لجميع الأعضاء'}`,
        linkReset: `🔗 *تغيير رابط المجموعة* 🔗\n\nقام ${usuario} بإعادة تعيين رابط الدعوة`,
        groupStatus: `🔒 *حالة المجموعة* 🔒\n\nقام ${usuario} بتغيير حالة المجموعة إلى ${m.messageStubParameters[0] == 'on' ? 'مقفولة' : 'مفتوحة'}\n\nالآن ${m.messageStubParameters[0] == 'on' ? 'فقط المشرفين' : 'جميع الأعضاء'} يمكنهم إرسال الرسائل`,
        adminAdded: `👑 *تمت ترقية مشرف جديد* 👑\n\nتم ترقية @${m.messageStubParameters[0].split('@')[0]} إلى مشرف\n\nبواسطة: ${usuario}`,
        adminRemoved: `⬇️ *إزالة مشرف* ⬇️\n\nتم إزالة @${m.messageStubParameters[0].split('@')[0]} من المشرفين\n\nبواسطة: ${usuario}`
    }

    if (chat.detect) {
        try {
            switch (m.messageStubType) {
                case 21: // تغيير الاسم
                    await conn.sendMessage(m.chat, { 
                        text: messages.nameChanged, 
                        mentions: [m.sender] 
                    }, { quoted: fkontak })
                    break
                    
                case 22: // تغيير الصورة
                    await conn.sendMessage(m.chat, { 
                        image: { url: pp }, 
                        caption: messages.picChanged, 
                        mentions: [m.sender] 
                    }, { quoted: fkontak })
                    break
                    
                case 23: // تغيير الرابط
                    await conn.sendMessage(m.chat, { 
                        text: messages.linkReset, 
                        mentions: [m.sender] 
                    }, { quoted: fkontak })
                    break
                    
                case 25: // تغيير الإعدادات
                    await conn.sendMessage(m.chat, { 
                        text: messages.settingsChanged, 
                        mentions: [m.sender] 
                    }, { quoted: fkontak })
                    break
                    
                case 26: // تغيير حالة المجموعة
                    await conn.sendMessage(m.chat, { 
                        text: messages.groupStatus, 
                        mentions: [m.sender] 
                    }, { quoted: fkontak })
                    break
                    
                case 29: // إضافة مشرف
                    await conn.sendMessage(m.chat, { 
                        text: messages.adminAdded, 
                        mentions: [m.sender, m.messageStubParameters[0]] 
                    }, { quoted: fkontak })
                    break
                    
                case 30: // إزالة مشرف
                    await conn.sendMessage(m.chat, { 
                        text: messages.adminRemoved, 
                        mentions: [m.sender, m.messageStubParameters[0]] 
                    }, { quoted: fkontak })
                    break
            }
        } catch (error) {
            console.error('حدث خطأ في إرسال الإشعار:', error)
        }
    } else if (m.messageStubType == 2) {
        return
    } else {
        console.log({
            messageStubType: m.messageStubType,
            messageStubParameters: m.messageStubParameters,
            type: WAMessageStubType[m.messageStubType]
        })
    }
}

export default handler