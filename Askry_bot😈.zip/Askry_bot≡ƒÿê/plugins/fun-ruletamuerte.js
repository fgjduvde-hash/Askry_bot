import { delay } from '@whiskeysockets/baileys';

const salasRuleta = {};

const handler = async (m, { conn }) => {
    const chatId = m.chat;
    const senderId = m.sender;

    if (salasRuleta[chatId]) 
        return conn.reply(m.chat, '✧ هناك لعبة نشطة بالفعل في هذه المجموعة، يرجى الانتظار حتى تنتهي.', m);

    salasRuleta[chatId] = { jugadores: [senderId], estado: 'esperando' };

    await conn.sendMessage(m.chat, { 
        text: `✦ *روليت الموت* ✦\n\n@${senderId.split('@')[0]} بدأ جلسة اللعبة.\n> ❀ للانضمام، رد بكلمة *قبلت*، الوقت المتبقي 60 ثانية...`, 
        mentions: [senderId] 
    }, { quoted: m });

    await delay(60000);
    if (salasRuleta[chatId] && salasRuleta[chatId].estado === 'esperando') {
        delete salasRuleta[chatId];
        await conn.sendMessage(m.chat, { text: '✦ لم يقبل أحد التحدي، تم إغلاق الجلسة.' });
    }
};

handler.command = ['روليت-الموت'];
handler.botAdmin = true

export default handler;

handler.before = async (m, { conn }) => {
    const chatId = m.chat;
    const senderId = m.sender;
    const texto = m.text?.toLowerCase();

    if (!salasRuleta[chatId]) return

    if (texto === 'قبلت' || texto === 'قبول') {
        if (salasRuleta[chatId].jugadores.length >= 2) 
            return conn.reply(m.chat, '✧ يوجد بالفعل لاعبين في هذه الجلسة.', m);

        if (senderId === salasRuleta[chatId].jugadores[0])
            return conn.reply(m.chat, '✧ لا يمكنك قبول تحدي نفسك.', m);

        salasRuleta[chatId].jugadores.push(senderId);
        salasRuleta[chatId].estado = 'completa';

        await conn.sendMessage(m.chat, { 
            audio: { url: "https://qu.ax/iwAmy.mp3" }, 
            mimetype: "audio/mp4", 
            ptt: true 
        });

        await conn.sendMessage(m.chat, { 
            text: '✦ *روليت الموت* ✦\n\n❀ اكتملت الجلسة!\n\n> ✧ جاري اختيار الخاسر...' 
        });

        const loadingMessages = [
            "《 █▒▒▒▒▒▒▒▒▒▒▒》10%\n- جاري حساب الاحتمالات...",
            "《 ████▒▒▒▒▒▒▒▒》30%\n- القدر يحكم...",
            "《 ███████▒▒▒▒▒》50%\n- الحظ يقرر...",
            "《 ██████████▒▒》80%\n- سنعرف الخاسر قريباً!",
            "《 ████████████》100%\n- النتيجة النهائية!"
        ];

        let { key } = await conn.sendMessage(m.chat, { text: "✧ جاري حساب النتيجة!" }, { quoted: m });

        for (let msg of loadingMessages) {
            await delay(3000);
            await conn.sendMessage(m.chat, { text: msg, edit: key }, { quoted: m });
        }

        const [jugador1, jugador2] = salasRuleta[chatId].jugadores;
        const perdedor = Math.random() < 0.5 ? jugador1 : jugador2;

        await conn.sendMessage(m.chat, { 
            text: `✦ *الحكم النهائي* ✦\n\n@${perdedor.split('@')[0]} هو الخاسر.\n\n> ❀ لديك 60 ثانية لقول كلماتك الأخيرة...`, 
            mentions: [perdedor] 
        });

        await delay(60000);        
            await conn.groupParticipantsUpdate(m.chat, [perdedor], 'remove');
            await conn.sendMessage(m.chat, { 
                text: `❀ @${perdedor.split('@')[0]} تم إزالته. نهاية اللعبة.`, 
                mentions: [perdedor] 
            });        
        delete salasRuleta[chatId];
    }

    if (texto === 'رفض' && senderId === salasRuleta[chatId].jugadores[0]) {
        delete salasRuleta[chatId];
        await conn.sendMessage(m.chat, { text: '✧ تم إلغاء اللعبة من قبل المطالب.' });
    }
};