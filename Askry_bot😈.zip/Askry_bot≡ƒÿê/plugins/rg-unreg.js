let handler = async (m, { conn, text }) => {

let user = global.db.data.users[m.sender]

user.registered = false
return conn.reply(m.chat, `${emoji} تم حذف تسجيلك من قاعدة بياناتي.`, m)

}
handler.help = ['إلغاء_التسجيل']
handler.tags = ['rg']
handler.command = ['الغاء تسجيل']
handler.register = true
export default handler

