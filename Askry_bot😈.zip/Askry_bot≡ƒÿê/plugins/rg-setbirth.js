import { createHash } from 'crypto';  
import fetch from 'node-fetch';

const handler = async (m, { conn, command, usedPrefix, text }) => {

let user = global.db.data.users[m.sender];

if (user.birth) {
return conn.reply(m.chat, `${emoji2} لديك تاريخ ميلاد مسجل بالفعل، إذا أردت حذف التاريخ الحالي استخدم:\n> » ${usedPrefix}delbirth`, m);
}

if (!text) return conn.reply(m.chat, `${emoji} يجب إدخال تاريخ ميلاد صالح.\n\n> ✐ مثال » *${usedPrefix + command} 01/01/2000* (يوم/شهر/سنة)`, m);

function validarFechaNacimiento(text) {
const opcionesFecha = [
/^\d{1,2}\/\d{1,2}\/\d{4}$/ // يوم/شهر/سنة
];

let esValida = opcionesFecha.some(regex => regex.test(text));
if (!esValida) return null;

if (/^\d{1,2}\/\d{1,2}\/\d{4}$/.test(text)) {
const [dia, mes, año] = text.split('/');
const meses = ["يناير", "فبراير", "مارس", "أبريل", "مايو", "يونيو", "يوليو", "أغسطس", "سبتمبر", "أكتوبر", "نوفمبر", "ديسمبر"];
return `${parseInt(dia)} من ${meses[parseInt(mes) - 1]} عام ${año}`;
}
return text;
}

let birth = validarFechaNacimiento(text);
if (!birth) {
return conn.reply(m.chat, `${emoji2} تأكد من اختيار تاريخ ميلاد صالح.\n> مثال: ${usedPrefix + command} 01/12/2024`, m);
}

user.birth = birth;
return conn.reply(m.chat, `${emoji} تم تعيين تاريخ ميلادك كالتالي: *${user.birth}*!`, m);
};

handler.help = ['تعيين_الميلاد']
handler.tags = ['rg']
handler.command = ['تعيين ميلاد', 'setcumpleaños']
export default handler;