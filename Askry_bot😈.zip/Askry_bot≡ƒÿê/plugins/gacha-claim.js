import { promises as fs } from 'fs';

const charactersFilePath = './src/database/characters.json';
const haremFilePath = './src/database/harem.json';

const cooldowns = {};

async function loadCharacters() {
    try {
        const data = await fs.readFile(charactersFilePath, 'utf-8');
        return JSON.parse(data);
    } catch (error) {
        throw new Error('❀ تعذر تحميل ملف characters.json');
    }
}

async function saveCharacters(characters) {
    try {
        await fs.writeFile(charactersFilePath, JSON.stringify(characters, null, 2), 'utf-8');
    } catch (error) {
        throw new Error('❀ تعذر حفظ ملف characters.json');
    }
}

let handler = async (m, { conn }) => {
    const userId = m.sender;
    const now = Date.now();

    if (cooldowns[userId] && now < cooldowns[userId]) {
        const remainingTime = Math.ceil((cooldowns[userId] - now) / 1000);
        const minutes = Math.floor(remainingTime / 60);
        const seconds = remainingTime % 60;
        return await conn.reply(m.chat, `《✧》يجب الانتظار *${minutes} دقائق و ${seconds} ثانية* لاستخدام *#c* مرة أخرى.`, m);
    }

    if (m.quoted && m.quoted.sender === conn.user.jid) {
        try {
            const characters = await loadCharacters();
            const characterIdMatch = m.quoted.text.match(/✦ الرقم: \*(.+?)\*/);

            if (!characterIdMatch) {
                await conn.reply(m.chat, '《✧》تعذر العثور على رقم الشخصية في الرسالة المقتبسة.', m);
                return;
            }

            const characterId = characterIdMatch[1];
            const character = characters.find(c => c.id === characterId);

            if (!character) {
                await conn.reply(m.chat, '《✧》الرسالة المقتبسة لا تحتوي على شخصية صالحة.', m);
                return;
            }

            if (character.user && character.user !== userId) {
                await conn.reply(m.chat, `《✧》هذه الشخصية مملوكة بالفعل بواسطة @${character.user.split('@')[0]}, حاول في المرة القادمة :)`, m, { mentions: [character.user] });
                return;
            }

            character.user = userId;
            character.status = "محجوز";

            await saveCharacters(characters);

            await conn.reply(m.chat, `✦ لقد حجزت شخصية *${character.name}* بنجاح.`, m);
            cooldowns[userId] = now + 30 * 60 * 1000;

        } catch (error) {
            await conn.reply(m.chat, `✘ خطأ في حجز الشخصية: ${error.message}`, m);
        }

    } else {
        await conn.reply(m.chat, '《✧》يجب اقتباس رسالة شخصية صالحة للحجز.', m);
    }
};

handler.help = ['حجز'];
handler.tags = ['gacha'];
handler.command = ['c', 'حجز', 'احجز'];
handler.group = true;

export default handler;