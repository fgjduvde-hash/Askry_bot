let handler = async (m, { conn, text }) => {
if (!text) return m.reply(`${emoji} أدخل اسمًا للمجموعة.`)
try {
m.reply(`${emoji2} يتم الآن إنشاء المجموعة...`)
let group = await conn.groupCreate(text, [m.sender])
let link = await conn.groupInviteCode(group.gid)
m.reply('https://chat.whatsapp.com/' + link)
} catch (e) {
m.reply(`${msm} حدث خطأ.`)
}
}
handler.help = ['انشاء قروب <الاسم>']
handler.tags = ['المالكين']
handler.command = ['creargc', 'newgc', 'creargrupo', 'grupocrear']
handler.rowner = true
handler.register = true

export default handler