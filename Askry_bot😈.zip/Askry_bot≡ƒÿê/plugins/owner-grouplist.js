const handler = async (m, { conn }) => {
  let txt = '';
  try {    
    const groups = Object.entries(conn.chats).filter(([jid, chat]) => jid.endsWith('@g.us') && chat.isChats);
    const totalGroups = groups.length;
    for (let i = 0; i < groups.length; i++) {
      const [jid, chat] = groups[i];
      const groupMetadata = ((conn.chats[jid] || {}).metadata || (await conn.groupMetadata(jid).catch((_) => null))) || {};
      const participants = groupMetadata.participants || [];
      const bot = participants.find((u) => conn.decodeJid(u.id) === conn.user.jid) || {};
      const isBotAdmin = bot?.admin || false;
      const isParticipant = participants.some((u) => conn.decodeJid(u.id) === conn.user.jid);
      const participantStatus = isParticipant ? '👤 مشارك' : '❌ غير مشارك';
      const totalParticipants = participants.length;
      txt += `*◉ المجموعة ${i + 1}*
    *➤ الاسم:* ${await conn.getName(jid)}
    *➤ المعرف:* ${jid}
    *➤ مشرف:* ${isBotAdmin ? '✔ نعم' : '❌ لا'}
    *➤ الحالة:* ${participantStatus}
    *➤ عدد المشاركين:* ${totalParticipants}
    *➤ الرابط:* ${isBotAdmin ? `https://chat.whatsapp.com/${await conn.groupInviteCode(jid) || '--- (خطأ) ---'}` : '--- (ليس مشرف) ---'}\n\n`;
    }
    m.reply(`*قائمة مجموعات البوت* 🤖\n\n*—◉ إجمالي المجموعات:* ${totalGroups}\n\n${txt}`.trim());
  } catch {
    const groups = Object.entries(conn.chats).filter(([jid, chat]) => jid.endsWith('@g.us') && chat.isChats);
    const totalGroups = groups.length;
    for (let i = 0; i < groups.length; i++) {
      const [jid, chat] = groups[i];
      const groupMetadata = ((conn.chats[jid] || {}).metadata || (await conn.groupMetadata(jid).catch((_) => null))) || {};
      const participants = groupMetadata.participants || [];
      const bot = participants.find((u) => conn.decodeJid(u.id) === conn.user.jid) || {};
      const isBotAdmin = bot?.admin || false;
      const isParticipant = participants.some((u) => conn.decodeJid(u.id) === conn.user.jid);
      const participantStatus = isParticipant ? '👤 مشارك' : '❌ غير مشارك';
      const totalParticipants = participants.length;    
      txt += `*◉ المجموعة ${i + 1}*
    *➤ الاسم:* ${await conn.getName(jid)}
    *➤ المعرف:* ${jid}
    *➤ مشرف:* ${isBotAdmin ? '✔ نعم' : '❌ لا'}
    *➤ الحالة:* ${participantStatus}
    *➤ عدد المشاركين:* ${totalParticipants}
    *➤ الرابط:* ${isBotAdmin ? '--- (خطأ) ---' : '--- (ليس مشرف) ---'}\n\n`;
    }
    m.reply(`*قائمة مجموعات البوت* 👾\n\n*—◉ إجمالي المجموعات:* ${totalGroups}\n\n${txt}`.trim());
  }    
};

handler.help = ['الجروبات', 'grouplist'];
handler.tags = ['المالك'];
handler.command = ['القروبات', 'gruposlista', 'grouplist', 'listagrupos'];
handler.rowner = true;
handler.private = true;

export default handler;