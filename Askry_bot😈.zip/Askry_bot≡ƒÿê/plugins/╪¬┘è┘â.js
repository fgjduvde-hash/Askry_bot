/**
 * TikTok Downloader  ─  ˚ ₊⊹𝑌𝑢𝑘𝑖୨🌕𝐵𝑜𝑡₊
 * ———————————————
 * يحفظ الفيديو من تيك توك بدون علامة مائية + الملف الصوتي (MP3)
 * أمر الاستخدام:
 *    .tiktok <رابط-تيك-توك>
 *
 * © Elena-Bot Team 2025
 */

import axios from 'axios';

const BOT_NAME = '˚ ₊⊹𝑌𝑢𝑘𝑖୨🌕𝐵𝑜𝑡₊';

let handler = async (m, { conn, args, usedPrefix, command }) => {
  if (!args[0])
    return m.reply(`❌  أرسل رابط الفيديو بعد الأمر، مثل:\n${usedPrefix + command} https://www.tiktok.com/@user/video/123`);

  const url = args[0].trim();

  try {
    const res = await fetchTikTok(url);

    if (res.code !== 0) throw 'فشل جلب البيانات، جرّب رابطاً آخر.';

    const {
      title,
      play,          // رابط الفيديو بدون علامة مائية
      music,         // رابط ملف الصوت
      author,
      cover          // صورة الغلاف
    } = res.data;

    // ▸ رسالة المعلومات
    const caption =
`🎵  *TikTok Downloader – ${BOT_NAME}*

📌 *العنوان:* ${title || 'غير متوفر'}
👤 *المُنشئ:* ${author.nickname} (@${author.unique_id})
🔗 *الرابط الأصلي:* ${url}`;

    // ▸ الغلاف + معلومات
    await conn.sendMessage(
      m.chat,
      { image: { url: cover }, caption },
      { quoted: m }
    );

    // ▸ الفيديو
    await conn.sendMessage(
      m.chat,
      { video: { url: play }, caption: '🎥 *الفيديو بدون علامة مائية*' },
      { quoted: m }
    );

    // ▸ الصوت (إن وُجد)
    if (music) {
      await conn.sendMessage(
        m.chat,
        { audio: { url: music }, mimetype: 'audio/mpeg', ptt: false },
        { quoted: m }
      );
    }

  } catch (e) {
    console.error(e);
    m.reply('❌ حدث خطأ أثناء التحميل، حاول لاحقاً.');
  }
};

handler.help = ['tiktok'].map(v => v + ' <رابط>');
handler.tags = ['downloader'];
handler.command = /^(tiktok|تيك)$/i;

export default handler;

//───────────────────────────────

async function fetchTikTok(url) {
  const form = new URLSearchParams({ url });

  const { data } = await axios.post('https://tikwm.com/api/', form, {
    headers: {
      'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
      Cookie: 'current_language=en',
      'User-Agent':
        'Mozilla/5.0 (Linux; Android 10) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/123.0.0.0 Mobile Safari/537.36'
    },
    timeout: 15000
  });

  if (!data || typeof data.code !== 'number')
    throw new Error('استجابة غير صحيحة من السيرفر');

  return data;
}