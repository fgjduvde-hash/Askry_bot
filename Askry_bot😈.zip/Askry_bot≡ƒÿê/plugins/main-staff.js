let handler = async (m, { conn, command, usedPrefix }) => {
  let img = './src/catalogo.jpg'
  let staff = `ᥫ᭡ *فريق المساعدين* ❀
✰ *المالك:* ${creador}
✦ *البوت:* ${botname}
⚘ *الإصدار:* ${vs}
❖ *المكتبة:* ${libreria} ${baileys}

❍ *المنشئ:*

ᰔᩚ ⁱᵃᵐ|𝔇ĕ𝐬†𝓻⊙γ𒆜
> 🜸 الدور » *المنشئ*
> ✧ GitHub » https://github.com/The-King-Destroy

❒ *المساهمون:*

ᰔᩚ 𝓔𝓶𝓶𝓪 𝓥𝓲𝓸𝓵𝓮𝓽𝓼 𝓥𝓮𝓻𝓼𝓲ó𝓷 
> 🜸 الدور » *مطور*
> ✧ GitHub » https://github.com/Elpapiema

ᰔᩚ Niño Piña
> 🜸 الدور » *مطور*
> ✧ GitHub » https://github.com/WillZek

✧ ☆꧁༒ĹєǤ𝒆𝐧𝐃༒꧂☆
> 🜸 الدور » *مطور*
> ✧ GitHub » https://github.com/Diomar-s

ᰔᩚ I'm Fz' (Tesis)
> 🜸 الدور » *مطور*
> ✧ GitHub » https://github.com/FzTeis

ᰔᩚ Legna
> 🜸 الدور » *مطور فرعي* 
> ✧ GitHub » https://github.com/Legna-chan
`
  await conn.sendFile(m.chat, img, 'yuki.jpg', staff.trim(), fkontak)
}

handler.help = ['staff']
handler.command = ['مطورين', 'staff']
handler.register = true
handler.tags = ['main']

export default handler