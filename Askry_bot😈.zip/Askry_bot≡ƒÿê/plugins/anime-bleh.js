/*
❀ الكود من إنشاء Destroy
✧ https://github.com/The-King-Destroy/Yuki_Suou-Bot.git
*/

import fs from 'fs'
import path from 'path'

let handler = async (m, { conn, usedPrefix }) => {
    let من = m.mentionedJid.length > 0 ? m.mentionedJid[0] : (m.quoted ? m.quoted.sender : m.sender)
    let اسم = conn.getName(من)
    let اسم_المرسل = conn.getName(m.sender)

    let النص = m.mentionedJid.length > 0 || m.quoted
        ? `\`${اسم_المرسل}\` أخرج لسانه لـ \`${اسم || من}\` (｡╹ω╹｡)`
        : `\`${اسم_المرسل}\` يخرج لسانه (｡╹ω╹｡)`
    
    if (m.isGroup) {
        let ف1 = 'https://raw.githubusercontent.com/The-King-Destroy/Adiciones/main/Contenido/1742790736580.mp4'
        let ف2 = 'https://raw.githubusercontent.com/The-King-Destroy/Adiciones/main/Contenido/1742790732658.mp4'
        let ف3 = 'https://raw.githubusercontent.com/The-King-Destroy/Adiciones/main/Contenido/1742790771185.mp4'
        let ف4 = 'https://raw.githubusercontent.com/The-King-Destroy/Adiciones/main/Contenido/1742790767541.mp4'
        let ف5 = 'https://raw.githubusercontent.com/The-King-Destroy/Adiciones/main/Contenido/1742790764155.mp4'
        let ف6 = 'https://raw.githubusercontent.com/The-King-Destroy/Adiciones/main/Contenido/1742790752990.mp4'
        let ف7 = 'https://raw.githubusercontent.com/The-King-Destroy/Adiciones/main/Contenido/1742790742850.mp4'
        let ف8 = 'https://raw.githubusercontent.com/The-King-Destroy/Adiciones/main/Contenido/1742790794852.mp4'
        let ف9 = 'https://raw.githubusercontent.com/The-King-Destroy/Adiciones/main/Contenido/1742790790619.mp4'
        let ف10 = 'https://raw.githubusercontent.com/The-King-Destroy/Adiciones/main/Contenido/1742790785503.mp4'
        let ف11 = 'https://raw.githubusercontent.com/The-King-Destroy/Adiciones/main/Contenido/1742790781953.mp4'
        let ف12 = 'https://raw.githubusercontent.com/The-King-Destroy/Adiciones/main/Contenido/1742790775403.mp4'
        let ف13 = 'https://raw.githubusercontent.com/The-King-Destroy/Adiciones/main/Contenido/1745595800133.mp4'
        let ف14 = 'https://raw.githubusercontent.com/The-King-Destroy/Adiciones/main/Contenido/1745595794273.mp4'
        let ف15 = 'https://raw.githubusercontent.com/The-King-Destroy/Adiciones/main/Contenido/1745595797089.mp4'
        
        const المقاطع = [ف1, ف2, ف3, ف4, ف5, ف6, ف7, ف8, ف9, ف10, ف11, ف12, ف13, ف14, ف15]
        const المقطع = المقاطع[Math.floor(Math.random() * المقاطع.length)]
        
        conn.sendMessage(
            m.chat,
            { video: { url: المقطع }, gifPlayback: true, caption: النص, ptt: true, mentions: [من] },
            { quoted: m }
        )
    }
}

handler.help = ['لسان']
handler.tags = ['انمي']
handler.command = ['لسان', 'بله']
handler.group = true

export default handler