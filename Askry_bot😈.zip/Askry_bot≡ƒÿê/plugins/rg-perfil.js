import moment from 'moment-timezone';
import PhoneNumber from 'awesome-phonenumber';
import fetch from 'node-fetch';

let handler = async (m, { conn, args }) => {
    let userId;
    if (m.quoted && m.quoted.sender) {
        userId = m.quoted.sender;
    } else {
        userId = m.mentionedJid && m.mentionedJid[0] ? m.mentionedJid[0] : m.sender;
    }

    let user = global.db.data.users[userId];

    let name = conn.getName(userId);
    let cumpleanos = user.birth || 'غير محدد';
    let genero = user.genre || 'غير محدد';
    let pareja = user.marry || 'لا أحد';
    let description = user.description || 'بدون وصف';
    let exp = user.exp || 0;
    let nivel = user.level || 0;
    let role = user.role || 'بدون رتبة';
    let coins = user.coin || 0;
    let bankCoins = user.bank || 0;

    let perfil = await conn.profilePictureUrl(userId, 'image').catch(_ => 'https://raw.githubusercontent.com/The-King-Destroy/Adiciones/main/Contenido/1745522645448.jpeg');

    let profileText = `
「✿」 *الملف الشخصي* ◢@${userId.split('@')[0]}◤
${description}

✦ العمر » ${user.age || 'غير معروف'}
♛ *تاريخ الميلاد* » ${cumpleanos}
⚥ *الجنس* » ${genero}
♡ *متزوج من* » ${pareja}

☆ *الخبرة* » ${exp.toLocaleString()}
❖ *المستوى* » ${nivel}
✎ الرتبة » ${role}

⛁ *عملات المحفظة* » ${coins.toLocaleString()} ${moneda}
⛃ *عملات البنك* » ${bankCoins.toLocaleString()} ${moneda}
❁ *مميز* » ${user.premium ? '✅' : '❌'}
  `.trim();

    await conn.sendMessage(m.chat, { 
        text: profileText,
        contextInfo: {
            mentionedJid: [userId],
            externalAdReply: {
                title: '✧ الملف الشخصي للمستخدم ✧',
                body: dev,
                thumbnailUrl: perfil,
                mediaType: 1,
                showAdAttribution: true,
                renderLargerThumbnail: true
            }
        }
    }, { quoted: m });
};

handler.help = ['الملف'];
handler.tags = ['rg'];
handler.command = ['انا', 'perfil'];

export default handler;