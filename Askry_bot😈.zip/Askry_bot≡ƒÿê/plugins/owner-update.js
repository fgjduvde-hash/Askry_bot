import { exec } from 'child_process';

let handler = async (m, { conn }) => {
  m.reply(`${emoji2} جاري تحديث البوت...`);

  exec('git pull', (err, stdout, stderr) => {
    if (err) {
      conn.reply(m.chat, `${msm} خطأ: لم يتمكن من إجراء التحديث.\nالسبب: ${err.message}`, m);
      return;
    }

    if (stderr) {
      console.warn('تحذير أثناء التحديث:', stderr);
    }

    if (stdout.includes('Already up to date.')) {
      conn.reply(m.chat, `${emoji4} البوت محدث بالفعل.`, m);
    } else {
      conn.reply(m.chat, `${emoji} تم التحديث بنجاح.\n\n${stdout}`, m);
    }
  });
};

handler.help = ['تحديث'];
handler.tags = ['owner'];
handler.command = ['تحديث'];
handler.rowner = true;

export default handler;