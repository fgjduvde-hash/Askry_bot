import { format } from 'util';

const وضع_التصحيح = false;
const نقاط_الفوز = 4999;
const نقاط_اللعب = 99;

export async function before(m) {
  let تحقق;
  let فاز = false;
  let تعادل = false;
  let استسلام = false;

  this.لعبة = this.لعبة ? this.لعبة : {};
  const الغرفة = Object.values(this.لعبة).find((غرفة) =>
    غرفة.id &&
    غرفة.لعبة &&
    غرفة.الحالة &&
    غرفة.id.startsWith('tictactoe') &&
    [غرفة.لعبة.لاعبX, غرفة.لعبة.لاعبO].includes(m.sender) &&
    غرفة.الحالة == 'PLAYING'
  );

  if (الغرفة) {
    if (!/^([1-9]|(me)?nyerah|\rendirse|rendirse|RENDIRSE|surr?ender)$/i.test(m.text)) {
      return true;
    }

    استسلام = !/^[1-9]$/.test(m.text);

    if (m.sender !== الغرفة.لعبة.الدور_الحالي) {
      if (!استسلام) return true;
    }

    if (وضع_التصحيح) {
      m.reply('[DEBUG]\n' + format({ استسلام, النص: m.text }));
    }

    if (
      !استسلام &&
      1 > (تحقق = الغرفة.لعبة.تحرك(m.sender === الغرفة.لعبة.لاعبO, parseInt(m.text) - 1))
    ) {
      m.reply({
        '-3': 'اللعبة انتهت',
        '-2': 'غير صالح',
        '-1': 'موضع غير صالح',
        '0': 'موضع غير صالح',
      }[تحقق]);
      return true;
    }

    if (m.sender === الغرفة.لعبة.الفائز) {
      فاز = true;
    } else if (الغرفة.لعبة.لوحة === 511) {
      تعادل = true;
    }

    const عرض = الغرفة.لعبة.عرض().map((v) => {
      return {
        X: '❎',
        O: '⭕',
        1: '1️⃣',
        2: '2️⃣',
        3: '3️⃣',
        4: '4️⃣',
        5: '5️⃣',
        6: '6️⃣',
        7: '7️⃣',
        8: '8️⃣',
        9: '9️⃣',
      }[v];
    });

    if (استسلام) {
      الغرفة.لعبة._الدور_الحالي = m.sender === الغرفة.لعبة.لاعبX;
      فاز = true;
    }

    const الفائز = استسلام ? الغرفة.لعبة.الدور_الحالي : الغرفة.لعبة.الفائز;

    const رسالة = `
🎮 لعبة إكس-أو 🎮

❎ = @${الغرفة.لعبة.لاعبX.split('@')[0]}
⭕ = @${الغرفة.لعبة.لاعبO.split('@')[0]}

${عرض.slice(0, 3).join('')}
${عرض.slice(3, 6).join('')}
${عرض.slice(6).join('')}

${
  فاز
    ? `@${الفائز.split('@')[0]} فزت 🥳، حصلت على +${نقاط_الفوز} XP`
    : تعادل
    ? 'اللعبة انتهت بالتعادل 😐'
    : `دور @${الغرفة.لعبة.الدور_الحالي.split('@')[0]}`
}
`.trim();

    const المستخدمين = global.db.data.users;

    if ((الغرفة.لعبة._الدور_الحالي ^ استسلام ? الغرفة.x : الغرفة.o) !== m.chat) {
      الغرفة[الغرفة.لعبة._الدور_الحالي ^ استسلام ? 'x' : 'o'] = m.chat;
    }

    if (الغرفة.x !== الغرفة.o) {
      await this.sendMessage(الغرفة.x, { text: رسالة, mentions: this.parseMention(رسالة) }, { quoted: m });
    }

    await this.sendMessage(الغرفة.o, { text: رسالة, mentions: this.parseMention(رسالة) }, { quoted: m });

    if (تعادل || فاز) {
      المستخدمين[الغرفة.لعبة.لاعبX].exp += نقاط_اللعب;
      المستخدمين[الغرفة.لعبة.لاعبO].exp += نقاط_اللعب;

      if (فاز) {
        المستخدمين[الفائز].exp += نقاط_الفوز - نقاط_اللعب;
      }

      if (وضع_التصحيح) {
        m.reply('[DEBUG]\n' + format(الغرفة));
      }

      delete this.لعبة[الغرفة.id];
    }
  }

  return true;
}