var handler = async (m, { conn, text, usedPrefix, command }) => {
  if (!text) return conn.reply(m.chat, `${emoji} من فضلك، أدخل سؤالاً.`, m)

  await m.react('❔')
  await delay(1000 * 1)
  await m.react('❓')
  await delay(1000 * 1)
  await m.react('❔')
  await delay(1000 * 1)

  await conn.reply(m.chat, `${dev}\n\n• *السؤال:* ${text}\n• *الجواب:* ${res}`, m)
}

handler.help = ['سؤال']
handler.tags = ['fun']
handler.command = ['سؤال','اسئلة']
handler.group = true
handler.register = true

export default handler

const delay = (ms) => new Promise((resolve) => setTimeout(resolve, ms))

let res = [
  'نعم',
  'ربما نعم',
  'من الممكن',
  'على الأرجح لا',
  'لا',
  'مستحيل',
  'لماذا تسأل هذه الأسئلة؟',
  'لهذا السبب سأتركك',
  'لماذا تريد أن تعرف؟',
  'لن أخبرك بالإجابة',
  'حاول مرة أخرى لاحقاً',
  'السماء تعلم الجواب',
  'ليس لدي فكرة',
  'العلامات تشير إلى نعم',
  'لا تحسب على ذلك',
  'بالتأكيد',
  'لا يمكن التنبؤ به الآن',
  'ركز واسأل مرة أخرى',
  'لا تعتمد عليه',
  'من المؤكد'
].getRandom()