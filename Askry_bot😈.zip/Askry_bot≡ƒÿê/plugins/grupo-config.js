let handler = async (m, { conn, args, usedPrefix, command }) => {
  const pp = await conn.profilePictureUrl(m.chat, 'image').catch(_ => icono);
  let الحالة = { 
    'open': 'not_announcement',
    'close': 'announcement',
    'abierto': 'not_announcement',
    'cerrado': 'announcement',
    'abrir': 'not_announcement',
    'cerrar': 'announcement',
  }[(args[0] || '')];

  if (الحالة === undefined)
    return conn.reply(m.chat, `${emoji} *اختر خيارًا لتكوين قروب*\n\nمثال:\n*✰ #${command} فتح*\n*✰ #${command} إغلاق*\n*✰ #${command} open*\n*✰ #${command} close*`, m);

  await conn.groupSettingUpdate(m.chat, الحالة);

  if (الحالة === 'not_announcement') {
    m.reply(`${emoji} *يمكن الآن للجميع الكتابة في هذه المجموعة.*`);
  }

  if (الحالة === 'announcement') {
    m.reply(`${emoji2} *فقط المشرفين يمكنهم الكتابة في هذه المجموعة.*`);
  }
};

handler.help = ['قروب فتح / إغلاق', 'group open / close'];
handler.tags = ['مجموعة'];
handler.command = ['مجموعة', 'group'];
handler.admin = true;
handler.botAdmin = true;

export default handler;