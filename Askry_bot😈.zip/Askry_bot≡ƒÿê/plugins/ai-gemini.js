import fetch from 'node-fetch'

var handler = async (m, { text, usedPrefix, command }) => {
  if (!text) return conn.reply(m.chat, `${emoji} يُرجى إدخال طلب للإجابة عليه من جيميني.`, m)
  
  try {
    await m.react(rwait)
    conn.sendPresenceUpdate('composing', m.chat)
    
    var apii = await fetch(`https://apis-starlights-team.koyeb.app/starlight/gemini?text=${text}`)
    var res = await apii.json()
    
    await m.reply(res.result)
    
  } catch {
    await m.react('❌')
    await conn.reply(m.chat, `${msm} لا يمكن لجيميني الإجابة على هذا السؤال.`, m)
  }
}

handler.command = ['جيميني', 'gemini']
handler.help = ['جيميني <طلب>']
handler.tags = ['ذكاء']
handler.group = true

export default handler