import { promises as fs } from 'fs'

const مسار_الشخصيات = './src/database/characters.json'
const مسار_الحريم = './src/database/harem.json'

const فترات_الانتظار = {}

async function تحميل_الشخصيات() {
    try {
        const البيانات = await fs.readFile(مسار_الشخصيات, 'utf-8')
        return JSON.parse(البيانات)
    } catch (خطأ) {
        throw new Error('❀ تعذر تحميل ملف الشخصيات.')
    }
}

async function حفظ_الشخصيات(شخصيات) {
    try {
        await fs.writeFile(مسار_الشخصيات, JSON.stringify(شخصيات, null, 2), 'utf-8')
    } catch (خطأ) {
        throw new Error('❀ تعذر حفظ ملف الشخصيات.')
    }
}

async function تحميل_الحريم() {
    try {
        const البيانات = await fs.readFile(مسار_الحريم, 'utf-8')
        return JSON.parse(البيانات)
    } catch (خطأ) {
        return []
    }
}

async function حفظ_الحريم(الحريم) {
    try {
        await fs.writeFile(مسار_الحريم, JSON.stringify(الحريم, null, 2), 'utf-8')
    } catch (خطأ) {
        throw new Error('❀ تعذر حفظ ملف الحريم.')
    }
}

let handler = async (m, { conn }) => {
    const معرف_المستخدم = m.sender
    const الآن = Date.now()

    if (فترات_الانتظار[معرف_المستخدم] && الآن < فترات_الانتظار[معرف_المستخدم]) {
        const الوقت_المتبقي = Math.ceil((فترات_الانتظار[معرف_المستخدم] - الآن) / 1000)
        const دقائق = Math.floor(الوقت_المتبقي / 60)
        const ثواني = الوقت_المتبقي % 60
        return await conn.reply(m.chat, `《✧》يجب أن تنتظر *${دقائق} دقيقة و ${ثواني} ثانية* لاستخدام *#rw* مرة أخرى.`, m)
    }

    try {
        const الشخصيات = await تحميل_الشخصيات()
        const شخصية_عشوائية = الشخصيات[Math.floor(Math.random() * الشخصيات.length)]
        const صورة_عشوائية = شخصية_عشوائية.img[Math.floor(Math.random() * شخصية_عشوائية.img.length)]

        const الحريم = await تحميل_الحريم()
        const إدخال_مستخدم = الحريم.find(entry => entry.characterId === شخصية_عشوائية.id)
        const رسالة_الحالة = شخصية_عشوائية.user 
            ? `مملوكة لـ @${شخصية_عشوائية.user.split('@')[0]}` 
            : 'غير مملوكة'

        const الرسالة = `❀ الاسم » *${شخصية_عشوائية.name}*
⚥ النوع » *${شخصية_عشوائية.gender}*
✰ القيمة » *${شخصية_عشوائية.value}*
♡ الحالة » ${رسالة_الحالة}
❖ المصدر » *${شخصية_عشوائية.source}*
✦ المعرف: *${شخصية_عشوائية.id}*`

        const منشنات = إدخال_مستخدم ? [إدخال_مستخدم.userId] : []
        await conn.sendFile(m.chat, صورة_عشوائية, `${شخصية_عشوائية.name}.jpg`, الرسالة, m, { mentions: منشنات })

        if (!شخصية_عشوائية.user) {
            await حفظ_الشخصيات(شخصيات)
        }

        فترات_الانتظار[معرف_المستخدم] = الآن + 15 * 60 * 1000

    } catch (خطأ) {
        await conn.reply(m.chat, `✘ حدث خطأ أثناء تحميل الشخصية: ${خطأ.message}`, m)
    }
}

handler.help = ['عرض', 'rw', 'rollwaifu']
handler.tags = ['gacha']
handler.command = ['عرض', 'rw', 'rollwaifu']
handler.group = true

export default handler