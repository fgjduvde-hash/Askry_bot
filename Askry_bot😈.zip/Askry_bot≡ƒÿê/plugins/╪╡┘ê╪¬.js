import { toAudio } from '../lib/converter.js';

const handler = async (m, { conn, usedPrefix, command }) => {
  try {
    const q = m.quoted ? m.quoted : m;
    const mime = (q.msg && q.msg.mimetype) || q.mimetype || q.mediaType || '';

    if (!/video|audio/.test(mime)) {
      return conn.reply(m.chat, '⚠️ من فضلك قم بالرد على فيديو أو رسالة صوتية لتحويلها إلى صوت/MP3.', m);
    }

    const media = await q.download();
    if (!media) {
      return conn.reply(m.chat, '❌ حدث خطأ أثناء تحميل الفيديو أو الرسالة الصوتية.', m);
    }

    const audio = await toAudio(media, 'mp3');
    if (!audio?.data) {
      return conn.reply(m.chat, '❌ حدث خطأ أثناء تحويل الملف إلى صوت/MP3.', m);
    }

    await conn.sendMessage(m.chat, { audio: audio.data, mimetype: 'audio/mpeg' }, { quoted: m });
  } catch (e) {
    console.error(e);
    return conn.reply(m.chat, `❌ حدث خطأ: ${e.message || e}`, m);
  }
};

handler.help = ['tomp3', 'toaudio'];
handler.command = ['tomp3', 'toaudio', 'صوت'];
handler.group = true;
handler.register = true;

export default handler;