let handler = async (m, { conn }) => {
  const imageURL = 'https://files.catbox.moe/8ty53e.jpg'

  let text = `
*🎭┇╾⪼ قسم الشخصيات*

> ⩺ ⌟.شخصية — عرض شخصية عشوائية  
> ⩺ ⌟.معلومات شخصية — معلومات تفصيلية  
> ⩺ ⌟.وايفو — اختيار وايفو عشوائية  
> ⩺ ⌟.هاريم — قائمة الشخصيات الخاصة بك  
> ⩺ ⌟.اعط شخصية — إهداء شخصية لمستخدم  
> ⩺ ⌟.تصويت — التصويت على شخصيات  
> ⩺ ⌟.ترتيب وايفو — أفضل الشخصيات حسب القيمة  

*🎀┇لا تنسَ كتابة (.) قبل كل أمر لاستخدامه!*
`.trim()

  await conn.sendMessage(m.chat, {
    image: { url: imageURL },
    caption: text,
    mentions: [m.sender]
  }, { quoted: m })
}

handler.help = ['س10']
handler.tags = ['menu']
handler.command = /^س10$/i

export default handler