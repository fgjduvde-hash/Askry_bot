import fetch from 'node-fetch';
import baileys from '@whiskeysockets/baileys';

/* دالة إرسال التفاعل (بديلة لـ m.react) */
async function sendReaction(conn, jid, key, emoji) {
    await conn.sendMessage(jid, {
        react: {
            text: emoji,
            key: key
        }
    });
}

async function sendAlbumMessage(jid, medias, options = {}) {
    if (typeof jid !== "string") throw new TypeError(`يجب أن يكون jid نصياً، تم استلام: ${jid}`);
    if (medias.length < 2) throw new RangeError("يحتاج الألبوم إلى صورتين على الأقل");

    const caption = options.text || options.caption || "";
    const delay = !isNaN(options.delay) ? options.delay : 500;
    delete options.text;
    delete options.caption;
    delete options.delay;

    const album = baileys.generateWAMessageFromContent(
        jid,
        { messageContextInfo: {}, albumMessage: { expectedImageCount: medias.length } },
        {}
    );

    await conn.relayMessage(album.key.remoteJid, album.message, { messageId: album.key.id });

    for (let i = 0; i < medias.length; i++) {
        const { type, data } = medias[i];
        const img = await baileys.generateWAMessage(
            album.key.remoteJid,
            { [type]: data, ...(i === 0 ? { caption } : {}) },
            { upload: conn.waUploadToServer }
        );
        img.message.messageContextInfo = {
            messageAssociation: { associationType: 1, parentMessageKey: album.key },
        };
        await conn.relayMessage(img.key.remoteJid, img.message, { messageId: img.key.id });
        await baileys.delay(delay);
    }
    return album;
}

const pinterest = async (m, { conn, text }) => {
    if (!text) return conn.reply(m.chat, `❀ من فضلك أدخل ما تريد البحث عنه في Pinterest.`, m);

    await sendReaction(conn, m.chat, m.key, '🕒');

    conn.reply(m.chat, '✧ *جاري تحميل الصور من Pinterest...*', m, {
        contextInfo: {
            externalAdReply: {
                mediaUrl: null,
                mediaType: 1,
                showAdAttribution: true,
                title: packname,
                body: dev,
                previewType: 0,
                thumbnail: icono,
                sourceUrl: redes
            }
        }
    });

    try {
        const res = await fetch(`https://api.dorratz.com/v2/pinterest?q=${encodeURIComponent(text)}`);
        const data = await res.json();

        if (!Array.isArray(data) || data.length < 2) {
            return conn.reply(m.chat, '✧ لم يتم العثور على صور كافية لإنشاء ألبوم.', m);
        }

        const images = data.slice(0, 10).map(img => ({ type: "image", data: { url: img.image_large_url } }));
        const caption = `❀ *نتائج البحث عن:* ${text}`;

        await sendAlbumMessage(m.chat, images, { caption, quoted: m });
        await sendReaction(conn, m.chat, m.key, '✅');
    } catch (error) {
        console.error(error);
        await sendReaction(conn, m.chat, m.key, '❌');
        conn.reply(m.chat, '⚠︎ حدث خطأ أثناء جلب الصور من Pinterest.', m);
    }
};

pinterest.help = ['pinterest <بحث>'];
pinterest.tags = ['محرك بحث', 'تحميلات'];
pinterest.command = ['pinterest', 'pin', 'بينتيريست'];
pinterest.register = true;
pinterest.group = true;

export default pinterest;