// plugins/tools/translate-code.js

import translate from '@vitalets/google-translate-api'

let handler = async (m, { text, command }) => {
  if (!text) return m.reply(`📥 أرسل كود فيه تعليقات بالإنجليزية لترجمته، مثال:\n${command} // this is a test`)

  try {
    // استخراج جميع التعليقات
    let matches = [...text.matchAll(/(\/\/.*$|\/\*[\s\S]*?\*\/)/gm)]

    if (!matches.length) return m.reply('❌ لم يتم العثور على تعليقات في الكود.')

    let translatedText = text

    for (let match of matches) {
      let original = match[0]
      let trans = await translate(original.replace(/(\/\/|\/\*|\*\/)/g, '').trim(), { to: 'ar' })
      let translatedComment = original.startsWith('//') 
        ? `// ${trans.text}`
        : `/* ${trans.text} */`
      translatedText = translatedText.replace(original, translatedComment)
    }

    m.reply(translatedText)
  } catch (e) {
    m.reply('❌ حدث خطأ أثناء الترجمة، تأكد من صحة الكود.')
    console.error(e)
  }
}

handler.help = ['ترجم_كود']
handler.tags = ['tools']
handler.command = /^ترجم_كود$/i

export default handler