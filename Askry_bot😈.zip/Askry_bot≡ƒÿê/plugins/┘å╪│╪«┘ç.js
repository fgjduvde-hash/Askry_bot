import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import { dirname } from 'path';
import { spawn } from 'child_process';

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

const allowedNumbers = [
  '967711516106@s.whatsapp.net',
  '218927472437@s.whatsapp.net'
];

const handler = async (m, { conn }) => {
  if (!allowedNumbers.includes(m.sender)) {
    await conn.sendMessage(m.chat, { text: `😈 يا عبد، هذا الأمر للمطور فقط` }, { quoted: m });
    return;
  }

  try {
    const botFolderPath = path.join(__dirname, '../');
    const zipFilePath = path.join(__dirname, '../bot_files.zip');

    await conn.sendMessage(m.chat, { text: `📂 بدء ضغط ملفات البوت...` }, { quoted: m });

    console.log('🔧 تنفيذ أمر الضغط...');
    const zipProcess = spawn('zip', ['-r', zipFilePath, '.', '-x', '.npm/*', 'node_modules/*', '*.git/*'], {
      cwd: botFolderPath
    });

    zipProcess.stdout.on('data', (data) => {
      console.log(`stdout: ${data}`);
    });

    zipProcess.stderr.on('data', (data) => {
      console.error(`stderr: ${data}`);
    });

    zipProcess.on('close', async (code) => {
      console.log('📦 الضغط انتهى بكود:', code);
      if (code !== 0) {
        await conn.sendMessage(m.chat, { text: `❌ فشل ضغط الملفات. كود: ${code}` }, { quoted: m });
        return;
      }

      if (!fs.existsSync(zipFilePath)) {
        console.log("❌ الملف لم يتم إنشاؤه.");
        await conn.sendMessage(m.chat, { text: `❌ لم يتم العثور على ملف zip.` }, { quoted: m });
        return;
      }

      const zipBuffer = fs.readFileSync(zipFilePath);
      console.log("✅ حجم الملف:", zipBuffer.length);

      await conn.sendMessage(m.chat, {
        document: zipBuffer,
        mimetype: 'application/zip',
        fileName: 'bot_files.zip',
        caption: '🤖 هذه نسخة ملفات البوت.'
      }, { quoted: m });

      fs.unlink(zipFilePath, async (err) => {
        if (!err) {
          console.log("🗑️ تم حذف الملف بعد الإرسال.");
          await conn.sendMessage(m.chat, { text: `🗑️ تم حذف ملف ZIP بعد الإرسال.` }, { quoted: m });
        } else {
          console.error("⚠️ فشل الحذف:", err.message);
        }
      });
    });

  } catch (err) {
    console.error("❌ خطأ:", err.message);
    await conn.sendMessage(m.chat, {
      text: `❌ خطأ في ضغط/إرسال الملفات: ${err.message}`
    }, { quoted: m });
  }
};

handler.help = ['نسخه'];
handler.tags = ['owner'];
handler.command = /^(نسخه)$/i;
handler.owner = true;

export default handler;