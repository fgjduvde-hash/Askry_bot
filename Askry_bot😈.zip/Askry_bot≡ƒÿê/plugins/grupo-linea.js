import axios from "axios"

let handler = async (m, { conn, args }) => {
  try {
    let id = args?.[0]?.match(/\d+\-\d+@g.us/) || m.chat

    const المشاركون = Object.values(conn.chats[id]?.messages || {})
      .map((item) => item.key.participant)
      .filter((value, index, self) => self.indexOf(value) === index)

    const المشاركون_المرتبون = المشاركون
      .filter(p => p)
      .sort((a, b) => {
        if (a && b) {
          return a.split("@")[0].localeCompare(b.split("@")[0])
        }
        return 0
      })

    const القائمة =
      المشاركون_المرتبون
        .map((k) => `*●* @${k.split("@")[0]}`)
        .join("\n") || "✧ لا يوجد مستخدمين متصلين حالياً."

    await conn.sendMessage(
      m.chat,
      {
        text: `*❀ قائمة المستخدمين المتصلين:*\n\n${القائمة}\n\n> ${dev}`,
        contextInfo: { mentionedJid: المشاركون_المرتبون },
      },
      { quoted: m }
    )

    await m.react("✅")
  } catch (error) {
    await m.reply(`⚠︎ حدث خطأ: ${error.message}`)
  }
}

handler.help = ["listonline"]
handler.tags = ["owner"]
handler.command = ["listonline", "online", "متصل", "المتصلين"]
handler.group = true

export default handler