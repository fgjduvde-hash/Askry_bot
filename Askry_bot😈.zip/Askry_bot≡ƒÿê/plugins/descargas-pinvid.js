import fetch from 'node-fetch'

let handler = async (m, { conn, text, usedPrefix, command }) => {
if (!text) throw m.reply(`${emoji} من فضلك أدخل رابط فيديو/صورة من Pinterest.`);
conn.sendMessage(m.chat, { react: { text: "🕒", key: m.key } });
	let ouh = await fetch(`https://api.agatz.xyz/api/pinterest?url=${text}`)
  let gyh = await ouh.json()
	await conn.sendFile(m.chat, gyh.data.result, `pinvideobykeni.mp4`, `*${emoji} الرابط:* ${gyh.data.url}`, m)
	await conn.sendMessage(m.chat, { react: { text: '✅', key: m.key }})
}
handler.help = ['pinvid *<رابط>*']
handler.tags = ['تحميلات']
handler.command = ['pinvideo', 'pinvid', 'بينتيريست']
handler.premium = false
handler.group = true
handler.register = true
handler.coin = 2

export default handler