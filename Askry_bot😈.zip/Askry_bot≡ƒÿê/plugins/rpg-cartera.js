let handler = async (m, { conn, usedPrefix }) => {
  let من = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : m.sender;
  if (من == conn.user.jid) return error;
  if (!(من in global.db.data.users)) return conn.reply(m.chat, `${emoji4} المستخدم غير موجود في قاعدة بياناتي.`, m);
  let المستخدم = global.db.data.users[من];
  await m.reply(`${من == m.sender ? `لديك *${المستخدم.coin} ${moneda} 💸* في محفظتك` : `المستخدم @${من.split('@')[0]} لديه *${المستخدم.coin} ${moneda} 💸* في محفظته`}. `, null, { mentions: [من] });
}

handler.help = ['محفظة'];
handler.tags = ['اقتصاد'];
handler.command = ['محفظة', 'cartera'];
handler.group = true;
handler.register = true;

export default handler;