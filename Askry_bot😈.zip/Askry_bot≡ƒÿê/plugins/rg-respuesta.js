let handler = async (m, { conn, text, usedPrefix, command }) => {
    if (!text) throw m.reply(`${emoji} مثال:\n\n${usedPrefix + command} <المعرف> <الرسالة>\n\n*${emoji2} الاستخدام:* ${usedPrefix + command} 1234 شكراً على اعترافك.`);
    
    let split = text.trim().split(/ (.+)/); 
    let id = split[0]; 
    let pesan = split[1]; 

    if (!id || !pesan) throw m.reply(`${emoji} مثال:\n\n${usedPrefix + command} <المعرف> <الرسالة>\n\n*${emoji2} الاستخدام:* ${usedPrefix + command} 1234 شكراً على اعترافك.`);
    
    id = id.trim();
    pesan = pesan.trim();

    console.log("conn.menfess", conn.menfess); 
    
    if (!conn.menfess || !conn.menfess[id]) {
        throw m.reply(`${msm} خطأ: لم يتم العثور على أي رسالة بالمعرف *${id}*.`);
    }
    
    let { dari, penerima } = conn.menfess[id];
    
    if (m.sender !== penerima) throw m.reply(`${emoji} ليس لديك إذن للرد على هذه الرسالة.`);
    
    let teks = `*مرحباً، لقد تلقيت ردًا على رسالتك المجهولة.*\n\n*\`المعرف:\`* *${id}*\n*\`الرد:\`* \n\n${pesan}`.trim();
    
    try {
        
        let sentMessage = await conn.sendMessage(dari, {
            text: teks,
            contextInfo: {
                mentionedJid: [dari],
                externalAdReply: {
                    title: 'الردود',
                    body: 'شكراً لاستخدامك خدمة الاعترافات!',
                    mediaType: 1,
                    renderLargerThumbnail: true,
                    thumbnailUrl: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRIyz1dMPkZuNleUyfXPMsltHwKKdVddTf4-A&usqp=CAU',
                    sourceUrl: channel,
                }
            }
        });
        
        if (sentMessage) {
           return conn.reply(m.chat, `${emoji} تم إرسال الرد بنجاح.\n*المعرف:*` + ` *${id}*`, m);
            
            conn.menfess[id].status = true;
        } else {
            throw new Error('تعذر إرسال الرسالة.');
        }
    } catch (e) {
        console.error(e);
        m.reply(`${msm} حدث خطأ أثناء إرسال الرد. تأكد من صحة الرقم وأن المرسل يمكنه استقبال الرسائل.`);
    }
};

handler.tags = ['rg'];
handler.help = ['رد'].map(v => v + ' <معرف الرسالة>');
handler.command = ['رد', 'responder']
handler.register = true;
handler.private = true;

export default handler;