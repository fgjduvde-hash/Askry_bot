let handler = async (m, { conn, usedPrefix, command }) => {

  if (!m.quoted) return conn.reply(m.chat, `${emoji} من فضلك قم بالرد على الرسالة التي تريد حذفها.`, m);
  try {
    let delet = m.message.extendedTextMessage.contextInfo.participant;
    let bang = m.message.extendedTextMessage.contextInfo.stanzaId;
    return conn.sendMessage(m.chat, { delete: { remoteJid: m.chat, fromMe: false, id: bang, participant: delet }});
  } catch {
    return conn.sendMessage(m.chat, { delete: m.quoted.vM.key });
  }
};

handler.help = ['حذف'];
handler.tags = ['مجموعة'];
handler.command = ['مسح', 'حذف', 'del', 'delete'];
handler.group = false;
handler.admin = true;
handler.botAdmin = true;

export default handler;