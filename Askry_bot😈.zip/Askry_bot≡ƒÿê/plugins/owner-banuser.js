var handler = async (m, { conn, text, usedPrefix, command }) => {
    let user, number, bot, bant, ownerNumber, aa, users, usr

    try {
        function no(number) {
            return number.replace(/\s/g, '').replace(/([@+-])/g, '')
        }
        text = no(text)
        number = isNaN(text) ? text.split`@`[1] : text
        user = conn.user.jid.split`@`[0] + '@s.whatsapp.net'
        bot = conn.user.jid.split`@`[0]
        bant = `❀ من فضلك، قم بوضع إشارة أو اكتب رقم المستخدم الذي تريد حظره من البوت.`
        const nn = conn.getName(m.sender)
        if (!text && !m.quoted) return conn.reply(m.chat, bant, m, { mentions: [user] })
        
        if (text) {
            user = number + '@s.whatsapp.net'
        } else if (m.quoted.sender) {
            user = m.quoted.sender
        } else if (m.mentionedJid) {
            user = number + '@s.whatsapp.net'
        }

        number = user.split('@')[0]
        if (user === conn.user.jid) return conn.reply(m.chat, `✧ @${bot} لا يمكن حظره بهذا الأمر.`, m, { mentions: [user] })

        for (let i = 0; i < global.owner.length; i++) {
            ownerNumber = global.owner[i][0]
            if (user.replace(/@s\.whatsapp\.net$/, '') === ownerNumber) {
                aa = ownerNumber + '@s.whatsapp.net'
                await conn.reply(m.chat, `✧ لا يمكنني حظر مالك البوت @${ownerNumber}.`, m, { mentions: [aa] })
                return
            }
        }

        users = global.db.data.users
        if (!users[user]) {
            users[user] = { banned: false }
        }
        if (users[user].banned === true) return conn.reply(m.chat, `✦ لا حاجة لحظر @${number} مرة أخرى.`, m, { mentions: [user] })

        users[user].banned = true
        usr = m.sender.split('@')[0]
        await conn.reply(m.chat, `❀ تم حظر المستخدم بنجاح.`, m, { mentions: [user] })
        let nametag = conn.getName(user)
        await conn.reply(`${suittag}@s.whatsapp.net`, `❀ تم حظر المستخدم *${nametag}* بواسطة *${nn}*.`, m)
    } catch (e) {
        await conn.reply(m.chat, `⚠︎ حدث خطأ.`, m)
    }
}

handler.help = ['بلوك <@tag> <السبب>']
handler.command = ['بلوك']
handler.tags = ['mods']
handler.rowner = true

export default handler