import { readdirSync, unlinkSync, existsSync, promises as fs, rmSync } from 'fs'
import path from 'path'

var handler = async (m, { conn, usedPrefix }) => {

  if (global.conn.user.jid !== conn.user.jid) {
    return conn.reply(m.chat, `${emoji} استخدم هذا الأمر مباشرة من الرقم الرئيسي للبوت.`, m)
  }

  let chatId = m.isGroup ? [m.chat, m.sender] : [m.sender]
  let sessionPath = `./${sessions}/`

  try {
    let files = await fs.readdir(sessionPath)
    let filesDeleted = 0
    for (let file of files) {
      for (let id of chatId) {
        if (file.includes(id.split('@')[0])) {
          await fs.unlink(path.join(sessionPath, file))
          filesDeleted++
          break
        }
      }
    }

    if (filesDeleted === 0) {
      await conn.reply(m.chat, `${emoji2} لم يتم العثور على أي ملف يحتوي على معرف الدردشة.`, m)
    } else {
      await conn.reply(m.chat, `${emoji2} تم حذف ${filesDeleted} من ملفات الجلسة.`, m)
      conn.reply(m.chat, `${emoji} مرحبًا! هل يمكنك رؤيتي الآن؟`, m)
    }
  } catch (err) {
    console.error('خطأ أثناء قراءة مجلد أو ملفات الجلسة:', err)
    await conn.reply(m.chat, `${emoji} مرحبًا، أنا ${botname}. الرجاء متابعة القناة ودعمنا.\n\n> ${channel}`, m)
  }

}

handler.help = ['ds', 'fixmsgespera']
handler.tags = ['info']
handler.command = ['fixmsgespera', 'ds']
handler.register = true

export default handler