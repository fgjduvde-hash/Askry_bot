import fs from 'fs'
import cp, { exec as _exec } from 'child_process'
import { promisify } from 'util'

const exec = promisify(_exec).bind(cp)

let handler = async (m, { conn, args, usedPrefix, command }) => {
  const pluginsList = Object.keys(plugins).map(v => v.replace('.js', ''))
  const fileName = args[0]

  if (!fileName) {
    let listText = `╭──── ⬤ قائمة البلوجنات المتاحة ⬤ ────╮\n`
    listText += pluginsList.map((v, i) => `│ ${i + 1}. ${v}`).join('\n')
    listText += `\n╰────────────────────────────╯\n`
    return m.reply(listText.trim())
  }

  if (!pluginsList.includes(fileName)) {
    let errorText = `⚠️ لا يوجد ملف بهذا الاسم: *${fileName}*\n\n╭── ⬤ قائمة الملفات ⬤ ──╮\n`
    errorText += pluginsList.map((v, i) => `│ ${i + 1}. ${v}`).join('\n')
    errorText += `\n╰────────────────────╯`
    return m.reply(errorText.trim())
  }

  let output
  try {
    output = await exec('cat plugins/' + fileName + '.js')
  } catch (e) {
    output = e
  }

  const { stdout, stderr } = output

  if (stdout.trim()) {
    const quotedMsg = await conn.sendMessage(m.chat, { text: stdout }, { quoted: m })
    await conn.sendMessage(m.chat, {
      document: fs.readFileSync(`./plugins/${fileName}.js`),
      mimetype: 'application/javascript',
      fileName: `${fileName}.js`
    }, { quoted: quotedMsg })
  }

  if (stderr.trim()) {
    const errorMsg = await conn.sendMessage(m.chat, { text: stderr }, { quoted: m })
    await conn.sendMessage(m.chat, {
      document: fs.readFileSync(`./plugins/${fileName}.js`),
      mimetype: 'application/javascript',
      fileName: `${fileName}.js`
    }, { quoted: errorMsg })
  }
}

handler.command = /^(باتش|gp|plugin|getplugin)$/i
handler.help = ['getplugin <اسم الملف>']
handler.tags = ['owner']
handler.owner = true

export default handler