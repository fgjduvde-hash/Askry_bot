let cooldowns = {};

let handler = async (m, { conn, text, command }) => {
  let المستخدمون = global.db.data.users;
  let معرف_المرسل = m.sender;

  let وقت_الانتظار = 5 * 60;

  if (cooldowns[m.sender] && Date.now() - cooldowns[m.sender] < وقت_الانتظار * 1000) {
    let الوقت_المتبقي = segundosAHMS(Math.ceil((cooldowns[m.sender] + وقت_الانتظار * 1000 - Date.now()) / 1000));
    m.reply(`${emoji} لقد استكشفت الغابة مؤخراً. انتظر ⏳ *${الوقت_المتبقي}* قبل أن تخوض المغامرة مرة أخرى.`);
    return;
  }

  cooldowns[m.sender] = Date.now();

  if (!المستخدمون[معرف_المرسل]) {
    المستخدمون[معرف_المرسل] = { health: 100, coin: 0, exp: 0 };
  }

  const الأحداث = [
    { الاسم: '💰 كنز مخفي', coin: 100, exp: 50, health: 0, رسالة: `لقد وجدت صندوق كنز مليء بـ${moneda}!` },
    { الاسم: '🐻 دب بري', coin: -50, exp: 20, health: -10, رسالة: `هاجمك دب و خسرت بعض ${moneda} أثناء الهروب.` },
    { الاسم: '🕸️ فخ قديم', coin: 0, exp: 10, health: 0, رسالة: 'وقعت في فخ لكنك نجوت بدون أذى.' },
    { الاسم: '💎 حجر سحري', coin: 200, exp: 100, health: 0, رسالة: `اكتشفت حجر سحري منحك ${moneda} إضافية!` },
    { الاسم: '🧙 حكيم قديم', coin: 50, exp: 30, health: 0, رسالة: 'كافأك الحكيم لسماعك قصصه.' },
    { الاسم: '⚔️ عدو مخفي', coin: -30, exp: 15, health: -10, رسالة: `واجهت عدواً مخفياً وخسرت بعض ${moneda}.` },
    { الاسم: '🍄 فطر غريب', coin: 0, exp: 5, health: 0, رسالة: 'أكلت فطر الغابة، لكن لم يحدث شيء مثير.' }
  ];

  let حدث = الأحداث[Math.floor(Math.random() * الأحداث.length)];

  المستخدمون[معرف_المرسل].coin += حدث.coin;
  المستخدمون[معرف_المرسل].exp += حدث.exp;
  المستخدمون[معرف_المرسل].health += حدث.health;

  let صورة = 'https://raw.githubusercontent.com/The-King-Destroy/Adiciones/main/Contenido/1745557951898.jpeg';
  let معلومات = `╭━〔 استكشاف الغابة〕\n` +
                `┃المهمة: *${حدث.الاسم}*\n` +
                `┃الحدث: ${حدث.رسالة}\n` +
                `┃المكافأة: ${حدث.coin > 0 ? '+' : '-'}${Math.abs(حدث.coin)} *${moneda}* و +${حدث.exp} *خبرة*.\n` +
                `┃صحتك ${حدث.health < 0 ? 'انخفضت بمقدار: ' + Math.abs(حدث.health) : 'ظلت كما هي.'}\n` +
                `╰━━━━━━━━━━━━⬣`;

  await conn.sendFile(m.chat, صورة, 'exploracion.jpg', معلومات, fkontak);

  global.db.write();
};

handler.tags = ['rpg'];
handler.help = ['استكشاف'];
handler.command = ['استكشاف', 'bosque'];
handler.register = true;
handler.group = true;

export default handler;

function segundosAHMS(ثواني) {
  let دقائق = Math.floor(ثواني / 60);
  let ثواني_متبقية = ثواني % 60;
  return `${دقائق} دقائق و ${ثواني_متبقية} ثواني`;
}

