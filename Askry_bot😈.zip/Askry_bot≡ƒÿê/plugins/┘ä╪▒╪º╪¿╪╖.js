import fs from 'fs';
import axios from 'axios';
import fetch from 'node-fetch';
import FormData from 'form-data';
import { fileTypeFromBuffer } from 'file-type';

let handler = async (m, { conn, text, usedPrefix, command }) => {
  const q = m.quoted ? m.quoted : m;
  const mime = (q.msg || q).mimetype || '';

  if (!mime) throw `❗ *يرجى الرد على ملف لرفعه كـ رابط.*\n📌 مثال: ${usedPrefix + command} 1`;

  const media = await q.download();
  const { ext, mime: fileMime } = await fileTypeFromBuffer(media);
  const fileType = fileMime.split('/')[0];

  if (!text) throw `🔰 *حدد الخدمة التي تريد الرفع إليها:*\n\n1 - Gofile\n2 - File.io\n3 - Imgbb\n4 - Quax\n5 - Ezgif\n6 - Uguu\n7 - Catbox`;

  let link;
  switch (text) {
    case '1': link = await uploadToGofile(media, ext); break;
    case '2': link = await uploadToFileio(media, ext); break;
    case '3':
      if (!/image/.test(mime)) throw '❌ هذا الخيار للصور فقط.';
      link = await uploadToImgbb(media); break;
    case '4': link = await uploadToQuax(media, ext); break;
    case '5':
      if (!/image/.test(mime)) throw '❌ هذا الخيار للصور فقط.';
      link = await uploadToEzgif(media); break;
    case '6': link = await uploadToUguu(media, ext); break;
    case '7': link = await uploadToCatbox(media, ext); break;
    default: throw '❗ *خيار غير صحيح.*';
  }

  let msg = `🎯 *معلومات الملف:*\n`;
  msg += `📄 الاسم: ${q.filename || `file.${ext}`}\n`;
  msg += `🧩 النوع: ${fileType}\n`;
  msg += `📦 الصيغة: ${ext}\n`;
  msg += `🔗 الرابط: ${link}`;

  await conn.sendMessage(m.chat, { text: msg }, { quoted: m });
};

handler.help = ['لرابط <رد على ملف>'];
handler.tags = ['tools'];
handler.command = ['لرابط']; // أمر التشغيل

export default handler;

// -- الدوال الخاصة بالرفع (بدون تغيير) --
const uploadToGofile = async (buffer, ext) => {
  const form = new FormData();
  form.append('file', buffer, `file.${ext}`);
  const res = await fetch('https://store2.gofile.io/uploadFile', { method: 'POST', body: form });
  const result = await res.json();
  if (result.status !== 'ok') throw 'فشل رفع الملف';
  return result.data.downloadPage;
};

const uploadToFileio = async (buffer, ext) => {
  const form = new FormData();
  form.append('file', buffer, `file.${ext}`);
  const res = await fetch('https://file.io', { method: 'POST', body: form });
  const result = await res.json();
  if (!result.success) throw 'فشل رفع الملف';
  return result.link;
};

const uploadToImgbb = async (buffer) => {
  const form = new FormData();
  form.append('image', buffer, { filename: 'file' });
  const res = await axios.post('https://api.imgbb.com/1/upload?key=10604ee79e478b08aba6de5005e6c798', form, {
    headers: form.getHeaders()
  });
  return res.data.data.url;
};

const uploadToQuax = async (buffer, ext) => {
  const form = new FormData();
  form.append('files[]', buffer, `file.${ext}`);
  const res = await fetch('https://qu.ax/upload.php', { method: 'POST', body: form });
  const result = await res.json();
  if (!result.success) throw 'فشل رفع الملف';
  return result.files[0].url;
};

const uploadToEzgif = async (buffer) => {
  let base64 = buffer.toString('base64');
  const res = await axios.post('https://zoro-foryou.vercel.app/api/img-to-url', { image: base64 }, {
    headers: { 'Content-Type': 'application/json' }
  });
  if (!res.data.status) throw 'فشل رفع الملف';
  return res.data.imageUrl;
};

const uploadToUguu = async (buffer, ext) => {
  const form = new FormData();
  form.append('files[]', buffer, `file.${ext}`);
  const res = await fetch('https://uguu.se/upload.php', { method: 'POST', body: form });
  const result = await res.json();
  if (!result.files || !result.files[0]) throw 'فشل رفع الملف';
  return result.files[0].url;
};

const uploadToCatbox = async (buffer, ext) => {
  const form = new FormData();
  form.append('fileToUpload', buffer, `file.${ext}`);
  form.append('reqtype', 'fileupload');
  const res = await fetch('https://catbox.moe/user/api.php', { method: 'POST', body: form });
  const text = await res.text();
  if (!text.startsWith('https://')) throw text;
  return text;
};