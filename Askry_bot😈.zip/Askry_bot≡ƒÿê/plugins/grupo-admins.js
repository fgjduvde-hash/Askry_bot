const handler = async (m, {conn, participants, groupMetadata, args}) => {
  const pp = await conn.profilePictureUrl(m.chat, 'image').catch((_) => null) || './src/catalogo.jpg';
  const adminsGroup = participants.filter((p) => p.admin);
  const listaAdmins = adminsGroup.map((v, i) => `${i + 1}. @${v.id.split('@')[0]}`).join('\n');
  const propietario = groupMetadata.owner || adminsGroup.find((p) => p.admin === 'superadmin')?.id || m.chat.split`-`[0] + '@s.whatsapp.net';
  const mensaje = args.join` `;
  const oi = `» ${mensaje}`;
  const texto = `『✦』مدراء المجموعة:  
  
${listaAdmins}

${emoji} الرسالة: ${oi}

『✦』تجنب استخدام هذا الأمر لأغراض أخرى أو سيتم *حذفك* أو *حظرك* من البوت.`.trim();
  
  conn.sendFile(m.chat, pp, 'error.jpg', texto, m, false, {mentions: [...adminsGroup.map((v) => v.id), propietario]});
};

handler.help = ['admins <نص>'];
handler.tags = ['المجموعة'];
// كشف كلمة بدون حساسية حالة الحروف
handler.customPrefix = /a|@/i;
handler.command = /^(admins|@admins|dmins)$/i;
handler.group = true;

export default handler;