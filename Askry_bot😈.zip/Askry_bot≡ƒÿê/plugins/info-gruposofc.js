import fetch from 'node-fetch'

let handler  = async (m, { conn, usedPrefix, command }) => {

  let grupos = `*مرحبًا! أدعوك للانضمام إلى المجموعات الرسمية للبوت لتتفاعل مع المجتمع.....*

- ${namegrupo}
> *❀* ${gp1}

${namecomu}
> *❀* ${comunidad1}

*ׄ─ׄ⭒─ׄ─ׅ─ׄ⭒─ׄ─ׅ─ׄ⭒─ׄ─ׅ─ׄ⭒─ׄ─ׅ─ׄ⭒─ׄ*

⚘ الرابط ملغى؟ ادخل من هنا!

- ${namechannel}
> *❀* ${channel}

> ${dev}`

  await conn.sendFile(m.chat, catalogo, "grupos.jpg", grupos, m)

  await m.react(emojis)

}
handler.help = ['grupos']
handler.tags = ['info']
handler.command = ['دعوة', 'links', 'groups']

export default handler