let handler = async (m, { conn }) => {
  const imageURL = 'https://files.catbox.moe/oztzw4.jpg'

  let text = `
*🪽┇╾⪼ قــســم آلَنــقــابــات*

> ⩺ ⌟.معلومات القروب — معلومات النقابة
> ⩺ ⌟.انضم — الانضمام لنقابة
> ⩺ ⌟.اخرج — مغادرة النقابة
> ⩺ ⌟.guildlist — قائمة النقابات
> ⩺ ⌟.guildrank — ترتيب الأعضاء
> ⩺ ⌟.انشاء قروب — إنشاء نقابة جديدة
> ⩺ ⌟.guildmsg — إرسال رسالة للنقابة
> ⩺ ⌟.طرد — طرد عضو من النقابة
> ⩺ ⌟.ارفع — ترقية عضو
> ⩺ ⌟.تنزيل — تنزيل رتبة عضو

*🎀┇لا تنسى كتابة (.) قبل كل أمر لاستخدامه!*
`.trim()

  await conn.sendMessage(m.chat, {
    image: { url: imageURL },
    caption: text,
    mentions: [m.sender]
  }, { quoted: m })
}

handler.help = ['س3']
handler.tags = ['menu']
handler.command = /^س3$/i

export default handler