import db from '../lib/database.js'

let handler = async (m, { args }) => {
  let المستخدم = global.db.data.users[m.sender]
  if (!args[0]) return m.reply(`${emoji} من فضلك أدخل كمية من *${moneda}* تريد إيداعها.`)
  if (args[0] < 1) return m.reply(`${emoji} من فضلك أدخل كمية صالحة من *${moneda}*.`)
  
  if (args[0] == 'all') {
    let المبلغ = parseInt(المستخدم.coin)
    المستخدم.coin -= المبلغ * 1
    المستخدم.bank += المبلغ * 1
    await m.reply(`${emoji} لقد أودعت *${المبلغ} ${moneda}* في البنك، لن يستطيع أحد سرقتها منك.`)
    return !0
  }
  
  if (!Number(args[0])) return m.reply(`${emoji2} يجب عليك إيداع كمية صحيحة.\n> مثال 1 » *#d 25000*\n> مثال 2 » *#d all*`)
  
  let المبلغ = parseInt(args[0])
  if (!المستخدم.coin) return m.reply(`${emoji2} ليس لديك ما يكفي من *${moneda}* في المحفظة.`)
  if (المستخدم.coin < المبلغ) return m.reply(`${emoji2} لديك فقط *${المستخدم.coin} ${moneda}* في المحفظة.`)
  
  المستخدم.coin -= المبلغ * 1
  المستخدم.bank += المبلغ * 1
  await m.reply(`${emoji} لقد أودعت *${المبلغ} ${moneda}* في البنك، لن يستطيع أحد سرقتها منك.`)
}

handler.help = ['إيداع']
handler.tags = ['rpg']
handler.command = ['deposit', 'depositar', 'd', 'aguardar']
handler.group = true
handler.register = true

export default handler