import axios from 'axios'
import fetch from 'node-fetch'

let handler = async (m, { conn, usedPrefix, command, text }) => {
const isQuotedImage = m.quoted && (m.quoted.msg || m.quoted).mimetype && (m.quoted.msg || m.quoted).mimetype.startsWith('image/')
const username = `${conn.getName(m.sender)}`
const basePrompt = `اسمك ${botname} ويبدو أنه تم إنشاؤك بواسطة ${etiqueta}. إصدارك الحالي هو ${vs}، تستخدم اللغة الإسبانية. ستُنادي الأشخاص بأسمائهم ${username}، تحبين أن تكوني مرحة وتحبين التعلم. الأهم هو أن تكوني ودودة مع الشخص الذي تتحدثين معه. ${username}`
if (isQuotedImage) {
const q = m.quoted
const img = await q.download?.()
if (!img) {
console.error(`${msm} خطأ: لا يوجد صورة متاحة`)
return conn.reply(m.chat, '✘ لم يتمكن ChatGpT من تحميل الصورة.', m)}
const content = `${emoji} ماذا يُرى في الصورة؟`
try {
const imageAnalysis = await fetchImageBuffer(content, img)
const query = `${emoji} صفي لي الصورة ووضحي لماذا يتصرفون هكذا. وأخبريني أيضًا من أنتِ`
const prompt = `${basePrompt}. الصورة التي يتم تحليلها هي: ${imageAnalysis.result}`
const description = await luminsesi(query, username, prompt)
await conn.reply(m.chat, description, m)
} catch {
await m.react(error)
await conn.reply(m.chat, '✘ لم يتمكن ChatGpT من تحليل الصورة.', m)}
} else {
if (!text) { return conn.reply(m.chat, `${emoji} أدخل طلبًا ليقوم ChatGpT بالرد عليه.`, m)}
await m.react(rwait)
try {
const { key } = await conn.sendMessage(m.chat, {text: `${emoji2} ChatGPT يقوم بمعالجة طلبك، انتظر بضع ثوانٍ.`}, {quoted: m})
const query = text
const prompt = `${basePrompt}. أجب على التالي: ${query}`
const response = await luminsesi(query, username, prompt)
await conn.sendMessage(m.chat, {text: response, edit: key})
await m.react(done)
} catch {
await m.react(error)
await conn.reply(m.chat, '✘ لا يمكن لـ ChatGpT الإجابة على هذا السؤال.', m)}}}

handler.help = ['ia', 'chatgpt']
handler.tags = ['ai']
handler.register = true
handler.command = ['ia', 'chatgpt', 'luminai']
handler.group = true

export default handler

const delay = (ms) => new Promise((resolve) => setTimeout(resolve, ms))

// دالة لإرسال صورة والحصول على التحليل
async function fetchImageBuffer(content, imageBuffer) {
try {
const response = await axios.post('https://Luminai.my.id', {
content: content,
imageBuffer: imageBuffer 
}, {
headers: {
'Content-Type': 'application/json' 
}})
return response.data
} catch (error) {
console.error('خطأ:', error)
throw error }}
// دالة للتفاعل مع الذكاء الاصطناعي باستخدام التعليمات
async function luminsesi(q, username, logic) {
try {
const response = await axios.post("https://Luminai.my.id", {
content: q,
user: username,
prompt: logic,
webSearchMode: false
})
return response.data.result
} catch (error) {
console.error(`${msm} خطأ في الحصول على:`, error)
throw error }}