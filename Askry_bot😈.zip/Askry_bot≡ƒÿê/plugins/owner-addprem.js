const handler = async (m, { conn, command, text }) => {
  let who
  if (m.isGroup) who = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : false
  else who = m.chat

  if (!who) return m.reply('❀ من فضلك، قم بذكر أو اقتباس رسالة لمستخدم.')

  const user = global.db.data.users[who]
  const now = Date.now()

  try {
    switch (command) {
      case 'addprem':
      case 'addpremium':
        const args = text.split(' ').filter(arg => arg)
        let tiempo = 0

        if (args.length < 2) return m.reply('✧ أرسل وقتًا صالحًا\n> مثال (1h، 2d، 3s، 4m).')

        if (args[1] === 'h') {
          tiempo = 3600000 * parseInt(args[0])
        } else if (args[1] === 'd') {
          tiempo = 86400000 * parseInt(args[0])
        } else if (args[1] === 's') {
          tiempo = 604800000 * parseInt(args[0])
        } else if (args[1] === 'm') {
          tiempo = 2592000000 * parseInt(args[0])
        } else {
          return m.reply(`✧ وقت غير صالح. الخيارات المتاحة:\n\n° *h :* ساعات\n° *d :* أيام\n° *s :* أسابيع\n° *m :* شهور\n\n✦ مثال:\n${command} 1 h ---> اشتراك بريميوم لمدة ساعة.\n${command} 1 d ---> اشتراك بريميوم لمدة يوم.\n${command} 1 s ---> اشتراك بريميوم لمدة أسبوع.\n${command} 1 m ---> اشتراك بريميوم لمدة شهر.`)
        }

        if (now < user.premiumTime) user.premiumTime += tiempo
        else user.premiumTime = now + tiempo

        user.premium = true
        const timeLeft = await formatTime(user.premiumTime - now)
        m.reply(`*✰ مستخدم بريميوم جديد!!!*\n\n*ᰔᩚ المستخدم » @${who.split`@`[0]}*\n*ⴵ مدة البريميوم » ${args[0]}${args[1]}*\n*✧ الوقت المتبقي » ${timeLeft}*`, null, { mentions: [who] })
        break

      case 'delprem':
      case 'delpremium':
        if (user.premiumTime === 0) throw `✧ المستخدم ليس من مستخدمي البريميوم.`
        user.premiumTime = 0
        user.premium = false
        m.reply(`❀ @${who.split`@`[0]} لم يعد مستخدم بريميوم.`, null, { mentions: [who] })
        break

      default:
        m.reply(`✧ الأمر *${command}* غير صالح.`)
    }
  } catch (error) {
    m.reply(error);
  }
}

handler.help = ['addprem', 'delprem']
handler.tags = ['owner']
handler.command = ['ادبرايم', 'addpremium', 'delprem', 'delpremium']
handler.rowner = true

export default handler

async function formatTime(ms) {
  let seconds = Math.floor(ms / 1000)
  let minutes = Math.floor(seconds / 60)
  let hours = Math.floor(minutes / 60)
  const days = Math.floor(hours / 24)
  seconds %= 60
  minutes %= 60
  hours %= 24
  let timeString = ''
  
  if (days) {
    timeString += `${days} يوم${days > 1 ? 's' : ''} `
  }
  if (hours) {
    timeString += `${hours} ساعة${hours > 1 ? 's' : ''} `
  }
  if (minutes) {
    timeString += `${minutes} دقيقة${minutes > 1 ? 's' : ''} `
  }
  if (seconds) {
    timeString += `${seconds} ثانية${seconds > 1 ? 's' : ''} `
  }
  return timeString.trim()
}