const handler = async (m, { conn, text, command, usedPrefix, args }) => {
  // رابط صورة اللعبة
  const pp = 'https://telegra.ph/file/c7924bf0e0d839290cc51.jpg';

  // مدة الانتظار 10 ثواني (10000 مللي ثانية)
  const time = global.db.data.users[m.sender].wait + 10000;
  if (new Date() - global.db.data.users[m.sender].wait < 10000) 
    throw `${emoji} عليك الانتظار ${Math.floor((time - new Date()) / 1000)} ثانية قبل أن تلعب مرة أخرى.`;

  if (!args[0]) 
    return conn.reply(m.chat, `*حجرة 🗿، ورقة 📄 أو مقص ✂️*\n\n*—◉ يمكنك استخدام هذه الأوامر:*\n*◉ ${usedPrefix + command} حجر*\n*◉ ${usedPrefix + command} ورقة*\n*◉ ${usedPrefix + command} مقص*`, m);

  let botChoice = Math.random();
  if (botChoice < 0.34) {
    botChoice = 'حجر';
  } else if (botChoice > 0.34 && botChoice < 0.67) {
    botChoice = 'مقص';
  } else {
    botChoice = 'ورقة';
  }

  const userChoice = text.toLowerCase();

  if (userChoice === botChoice) {
    global.db.data.users[m.sender].exp += 500;
    m.reply(`*${emoji2} تعادل!*\n\n*👉🏻 أنت: ${userChoice}*\n*👉🏻 البوت: ${botChoice}*\n*🎁 جائزة +500 نقطة خبرة*`);
  } else if (userChoice === 'ورقة') {
    if (botChoice === 'حجر') {
      global.db.data.users[m.sender].exp += 1000;
      m.reply(`*${emoji} أنت فزت! 🎉*\n\n*👉🏻 أنت: ${userChoice}*\n*👉🏻 البوت: ${botChoice}*\n*🎁 جائزة +1000 نقطة خبرة*`);
    } else {
      global.db.data.users[m.sender].exp -= 300;
      m.reply(`*💀 أنت خسرت! ❌*\n\n*👉🏻 أنت: ${userChoice}*\n*👉🏻 البوت: ${botChoice}*\n*❌ خسارة -300 نقطة خبرة*`);
    }
  } else if (userChoice === 'مقص') {
    if (botChoice === 'ورقة') {
      global.db.data.users[m.sender].exp += 1000;
      m.reply(`*${emoji} أنت فزت! 🎉*\n\n*👉🏻 أنت: ${userChoice}*\n*👉🏻 البوت: ${botChoice}*\n*🎁 جائزة +1000 نقطة خبرة*`);
    } else {
      global.db.data.users[m.sender].exp -= 300;
      m.reply(`*☠️ أنت خسرت! ❌*\n\n*👉🏻 أنت: ${userChoice}*\n*👉🏻 البوت: ${botChoice}*\n*❌ خسارة -300 نقطة خبرة*`);
    }
  } else if (userChoice === 'حجر') {
    if (botChoice === 'مقص') {
      global.db.data.users[m.sender].exp += 1000;
      m.reply(`*${emoji} أنت فزت! 🎉*\n\n*👉🏻 أنت: ${userChoice}*\n*👉🏻 البوت: ${botChoice}*\n*🎁 جائزة +1000 نقطة خبرة*`);
    } else {
      global.db.data.users[m.sender].exp -= 300;
      m.reply(`*${emoji} أنت خسرت! ❌*\n\n*👉🏻 أنت: ${userChoice}*\n*👉🏻 البوت: ${botChoice}*\n*❌ خسارة -300 نقطة خبرة*`);
    }
  } else {
    return conn.reply(m.chat, `❌ الخيار غير صحيح! من فضلك اختر: حجر، ورقة، أو مقص.`, m);
  }

  global.db.data.users[m.sender].wait = new Date() * 1;
};

handler.help = ['ppt'];
handler.tags = ['games'];
handler.command = ['ppt'];
handler.group = true;
handler.register = true;

export default handler;