const handler = async (m, { isPrems, conn }) => {
  if (!global.db.data.users[m.sender]) {
    throw `${emoji4} المستخدم غير موجود.`;
  }

  const اخر_وقت_صندوق = global.db.data.users[m.sender].lastcofre;
  const الوقت_حتى_الصندوق_التالي = اخر_وقت_صندوق + 86400000;

  if (Date.now() < الوقت_حتى_الصندوق_التالي) {
    const الوقت_المتبقي = الوقت_حتى_الصندوق_التالي - Date.now();
    const رسالة_انتظار = `${emoji3} لقد استلمت صندوقك بالفعل\n⏰️ ارجع بعد: *${msToTime(الوقت_المتبقي)}* لاستلامه مرة أخرى.`;
    await conn.sendMessage(m.chat, { text: رسالة_انتظار }, { quoted: m });
    return;
  }

  const الصورة = 'https://raw.githubusercontent.com/The-King-Destroy/Adiciones/main/Contenido/1745557947304.jpeg';
  const عملات = Math.floor(Math.random() * 100);
  const توكنات = Math.floor(Math.random() * 10);
  const الماسات = Math.floor(Math.random() * 40);
  const خبرة = Math.floor(Math.random() * 5000);

  global.db.data.users[m.sender].coin += عملات;
  global.db.data.users[m.sender].diamonds += الماسات;
  global.db.data.users[m.sender].joincount += توكنات;
  global.db.data.users[m.sender].exp += خبرة;
  global.db.data.users[m.sender].lastcofre = Date.now();

  const النص = `
╭━〔 صندوق عشوائي 〕⬣
┃📦 *حصلت على صندوق*
┃ مبروك!
╰━━━━━━━━━━━━⬣

╭━〔 موارد جديدة 〕⬣
┃ *${عملات} ${moneda}* 💸
┃ *${توكنات} توكن* ⚜️
┃ *${الماسات} ماسة* 💎
┃ *${خبرة} خبرة* ✨
╰━━━━━━━━━━━━⬣`;

  try {
    await conn.sendFile(m.chat, الصورة, 'yuki.jpg', النص, fkontak);
  } catch (error) {
    throw `${msm} حدث خطأ أثناء إرسال الصندوق.`;
  }
};

handler.help = ['صندوق'];
handler.tags = ['rpg'];
handler.command = ['صندوق'];
handler.level = 5;
handler.group = true;
handler.register = true;

export default handler;

function msToTime(duration) {
  const milliseconds = parseInt((duration % 1000) / 100);
  let seconds = Math.floor((duration / 1000) % 60);
  let minutes = Math.floor((duration / (1000 * 60)) % 60);
  let hours = Math.floor((duration / (1000 * 60 * 60)) % 24);

  hours = (hours < 10) ? '0' + hours : hours;
  minutes = (minutes < 10) ? '0' + minutes : minutes;
  seconds = (seconds < 10) ? '0' + seconds : seconds;

  return `${hours} ساعات ${minutes} دقائق`;
}