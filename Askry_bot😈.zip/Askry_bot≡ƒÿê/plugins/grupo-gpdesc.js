const handler = async (m, { conn, args }) => {
  await conn.groupUpdateDescription(m.chat, `${args.join(' ')}`);
  m.reply(`${emoji} تم تعديل وصف المجموعة بنجاح.`);
};
handler.help = ['وصف القروب <النص>'];
handler.tags = ['مجموعة'];
handler.command = ['وصف_مجموعة', 'gpdesc', 'groupdesc'];
handler.group = true;
handler.admin = true;
handler.botAdmin = true;

export default handler;