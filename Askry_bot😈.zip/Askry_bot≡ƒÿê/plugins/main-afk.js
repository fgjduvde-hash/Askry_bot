export function before(m) {
  // الحصول على بيانات المستخدم من قاعدة البيانات العالمية
  const user = global.db.data.users[m.sender];
  
  // التحقق إذا كان المستخدم في وضع AFK (غير متوفر)
  if (user.afk > -1) {
    // إرسال رسالة تفيد أن المستخدم عاد من وضع AFK
    conn.reply(m.chat, `${emoji} لقد عدت من وضع عدم التوفر\n${user.afkReason ? 'سبب عدم التوفر: ' + user.afkReason : ''}\n\n*مدة عدم التوفر: ${(new Date - user.afk).toTimeString()}*`, m);
    
    // إعادة تعيين حالة AFK للمستخدم
    user.afk = -1;
    user.afkReason = '';
  }
  
  // الحصول على كل الـJIDs (المستخدمين) المذكورين في الرسالة أو المقتبسين
  const jids = [...new Set([...(m.mentionedJid || []), ...(m.quoted ? [m.quoted.sender] : [])])];
  
  // التكرار على كل المستخدمين المذكورين أو المقتبسين
  for (const jid of jids) {
    const user = global.db.data.users[jid];
    
    if (!user) continue; // إذا لم يوجد المستخدم في قاعدة البيانات، تخطى
    
    const afkTime = user.afk;
    
    if (!afkTime || afkTime < 0) continue; // إذا المستخدم ليس في وضع AFK، تخطى
    
    const reason = user.afkReason || '';
    
    // إرسال رسالة تحذير أن المستخدم المُشار إليه في وضع AFK ولا يجب منشنه
    conn.reply(m.chat, `${emoji2} المستخدم غير متوفر حالياً، لا تقم بذكره.`, m);
  }
  
  return true; // تأكيد إكمال التنفيذ لبقية المعالجات
}