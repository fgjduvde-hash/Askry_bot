import { igdl } from 'ruhend-scraper';

const handler = async (m, { args, conn }) => {
  if (!args[0]) {
    return conn.reply(m.chat, `${emoji} من فضلك أدخل رابط إنستغرام.`, m);
  }

  try {
    await m.react(rwait);
    const res = await igdl(args[0]);
    const data = res.data;

    for (let media of data) {
      await conn.sendFile(m.chat, media.url, 'instagram.mp4', `${emoji} هذا هو المحتوى الخاص بك ฅ^•ﻌ•^ฅ.`, m);
    await m.react(done);
    }
  } catch (e) {
    return conn.reply(m.chat, `${msm} حدث خطأ ما.`, m);
    await m.react(error);
  }
};

handler.command = ['instagram', 'ig', 'انستغرام'];
handler.tags = ['تحميلات'];
handler.help = ['instagram', 'ig', 'انستغرام'];
handler.group = true;
handler.register = true;
handler.coin = 2;

export default handler;