let handler = async (m, { conn, text, usedPrefix, command, participants }) => {
  if (!text) throw `⚠️ اكتب الرسالة بعد الأمر مثل:\n${usedPrefix + command} مرحباً بالجميع`;

  let users = participants.map(p => p.id).filter(v => v !== undefined);

  await conn.sendMessage(m.chat, {
    text,
    mentions: users,
  }, {
    quoted: {
      key: {
        participant: '0@s.whatsapp.net',
        remoteJid: m.chat,
      },
      message: {
        videoMessage: {
          title: 'Waguri Bot',
          h: 'h',
          seconds: 99999,
          gifPlayback: true,
          caption: '˚ ₊⊹𝑌𝑢𝑘𝑖୨🌕𝐵𝑜𝑡₊',
          jpegThumbnail: Buffer.alloc(0),
        }
      }
    }
  });
};

handler.help = ['hidetag <text>'];
handler.tags = ['group'];
handler.command = /^(hidetag|notificar|مخفي)$/i;

handler.group = true;
handler.admin = true;

export default handler;