let handler = async (m, { text, usedPrefix, command }) => {
  global.db.data.sticker = global.db.data.sticker || {}

  if (!m.quoted) return conn.reply(m.chat, `${emoji} قم بالرد على ملصق لإضافة أمر.`, m)
  if (!m.quoted.fileSha256) return conn.reply(m.chat, `${emoji} قم بالرد على ملصق لإضافة أمر.`, m)
  if (!text) return conn.reply(m.chat, `${emoji2} أدخل اسم الأمر.`, m)

  try {
    let sticker = global.db.data.sticker
    let hash = m.quoted.fileSha256.toString('base64')
    if (sticker[hash] && sticker[hash].locked) return conn.reply(m.chat, `${emoji2} ليس لديك صلاحية لتعديل هذا الأمر.`, m)

    sticker[hash] = {
      text,
      mentionedJid: m.mentionedJid,
      creator: m.sender,
      at: +new Date,
      locked: false,
    }

    await conn.reply(m.chat, `${emoji} تم حفظ الأمر بنجاح.`, m)
    await m.react('✅')

  } catch {
    await m.react('✖️')
  }
}

handler.help = ['cmd'].map(v => 'set' + v + ' *<النص>*')
handler.tags = ['owner']
handler.command = ['تعيين امر', 'addcmd', 'cmdadd', 'cmdset']
handler.owner = true

export default handler