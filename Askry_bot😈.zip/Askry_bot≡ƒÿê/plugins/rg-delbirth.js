import { createHash } from 'crypto';  
import fetch from 'node-fetch';

const handler = async (m, { conn, command, usedPrefix, text }) => {

  let user = global.db.data.users[m.sender];

  if (!user.birth) {
    return conn.reply(m.chat, `${emoji2} لا توجد لديك تاريخ ميلاد محفوظ يمكن حذفه.`, m);
  }

  user.birth = '';

  return conn.reply(m.chat, `${emoji} تم حذف تاريخ ميلادك بنجاح.`, m);
};

handler.help = ['ميلادي'];
handler.tags = ['rg'];
handler.command = ['ميلادي'];
export default handler;