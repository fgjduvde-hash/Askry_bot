import fs from 'fs'  // استيراد مكتبة ملفات النظام

// الدالة الرئيسية للتعامل مع الأمر
async function handler(m, { usedPrefix }) {
  // استخراج معرف المستخدم من رقم الجوال (مثلاً 1234567890)
  const user = m.sender.split('@')[0]

  // التحقق هل ملف بيانات الاعتماد (token) موجود لهذا المستخدم
  if (fs.existsSync(`./${jadi}/` + user + '/creds.json')) {
    // قراءة محتوى ملف creds.json وتحويله إلى نص مشفر base64
    let token = Buffer.from(
      fs.readFileSync(`./${jadi}/` + user + '/creds.json'), 
      'utf-8'
    ).toString('base64')

    // إرسال رسالة توضح أهمية الـ token مع إرسال الـ token نفسه
    await conn.reply(m.chat, `${emoji} هذا التوكن يسمح لك بتسجيل الدخول في بوتات أخرى، ننصح بعدم مشاركته مع أي شخص\n\n*توكنك هو:*`, m)
    await conn.reply(m.chat, token, m)
  } else {
    // في حال عدم وجود توكن للمستخدم، تنبيه لاستخدام الأمر #jadibot لإنشاء توكن جديد
    await conn.reply(m.chat, `${emoji2} لا تملك أي توكن مفعل، استخدم #jadibot لإنشاء واحد.`, m)
  }
}

// إعدادات الأمر
handler.help = ['token']           // اسم الأمر للمساعدة
handler.command = ['توكين']        // الكلمات المفتاحية للأمر
handler.tags = ['توكين']          // تصنيف الأمر (سير بوت - Sub Bot)
handler.private = true             // الأمر خاص (يمكن استخدامه في الخاص فقط)

export default handler             // تصدير الأمر ليتم استخدامه في البوت