let handler = async (m, { conn, usedPrefix, command, text }) => {
  const emoji = '⚠️' // رمز تحذير للرسائل التنبيهية
  const done = '✅'  // رمز نجاح

  // التأكد من وجود نص أو رد مقتبس
  if (!text && !m.quoted) {
    return conn.reply(m.chat, `${emoji} يجب ذكر مستخدم لترقيته إلى مسؤول.`, m)
  }

  let number

  if (text) {
    if (isNaN(text)) {
      // النص يحتوي @
      if (text.includes('@')) {
        number = text.split('@')[1].replace(/[^0-9]/g, '')  // استخراج الرقم فقط
      } else {
        return conn.reply(m.chat, `${emoji} يجب الرد أو ذكر شخص صالح لاستخدام هذا الأمر.`, m)
      }
    } else {
      // النص رقم فقط
      number = text
    }
  } else if (m.quoted && m.quoted.sender) {
    number = m.quoted.sender.split('@')[0]
  } else {
    return conn.reply(m.chat, `${emoji} يجب الرد أو ذكر شخص لاستخدام هذا الأمر.`, m)
  }

  // التحقق من طول الرقم
  if (number.length > 13 || (number.length < 11 && number.length > 0)) {
    return conn.reply(m.chat, `${emoji} رقم غير صالح لاستخدام هذا الأمر.`, m)
  }

  const user = number + '@s.whatsapp.net'

  try {
    await conn.groupParticipantsUpdate(m.chat, [user], 'promote')
    await conn.reply(m.chat, `${done} تم ترقية المستخدم إلى مسؤول المجموعة بنجاح.`, m)
  } catch (e) {
    conn.reply(m.chat, `${emoji} لم يتمكن من ترقية المستخدم. تحقق أنه عضو في المجموعة.`, m)
  }
}

handler.help = ['promote']
handler.tags = ['مجموعة']
handler.command = ['promote', 'darpija', 'promover']
handler.group = true
handler.admin = true
handler.botAdmin = true
handler.fail = null

export default handler