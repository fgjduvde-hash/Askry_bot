const الحد_الأقصى_للسرقة = 30;
const المعالج = async (m, { conn, usedPrefix, command }) => {
  const الوقت = global.db.data.users[m.sender].lastrob2 + 7200000;
  if (new Date() - global.db.data.users[m.sender].lastrob2 < 7200000) {
    conn.reply(m.chat, `${emoji3} يجب أن تنتظر ${تحويل_ميلي_الى_وقت(الوقت - new Date())} لاستخدام #rob مرة أخرى.`, m);
    return;
  }
  
  let الهدف;
  if (m.isGroup) الهدف = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : false;
  else الهدف = m.chat;
  
  if (!الهدف) {
    conn.reply(m.chat, `${emoji} يجب أن تذكر شخصًا لمحاولة سرقته.`, m);
    return;
  }
  
  if (!(الهدف in global.db.data.users)) {
    conn.reply(m.chat, `${emoji2} المستخدم غير موجود في قاعدة بياناتي.`, m);
    return;
  }
  
  const المستخدم_المستهدف = global.db.data.users[الهدف];
  const مبلغ_السرقة = Math.floor(Math.random() * الحد_الأقصى_للسرقة);
  
  if (المستخدم_المستهدف.coin < مبلغ_السرقة) {
    return conn.reply(m.chat, `${emoji2} @${الهدف.split`@`[0]} لا يملك ما يكفي من *${عملة}* خارج البنك لتستحق المحاولة.`, m, { mentions: [الهدف] });
  }
  
  global.db.data.users[m.sender].coin += مبلغ_السرقة;
  global.db.data.users[الهدف].coin -= مبلغ_السرقة;
  
  conn.reply(m.chat, `${emoji} سرقت ${مبلغ_السرقة} ${عملة} من @${الهدف.split`@`[0]}`, m, { mentions: [الهدف] });
  
  global.db.data.users[m.sender].lastrob2 = new Date() * 1;
};

المعالج.help = ['rob'];
المعالج.tags = ['rpg'];
المعالج.command = ['سرقه', 'steal', 'rob'];
المعالج.group = true;
المعالج.register = true;

export default المعالج;

function تحويل_ميلي_الى_وقت(مدة) {
  const ميلي_ثواني = parseInt((مدة % 1000) / 100);
  let ثواني = Math.floor((مدة / 1000) % 60);
  let دقائق = Math.floor((مدة / (1000 * 60)) % 60);
  let ساعات = Math.floor((مدة / (1000 * 60 * 60)) % 24);
  ساعات = (ساعات < 10) ? '0' + ساعات : ساعات;
  دقائق = (دقائق < 10) ? '0' + دقائق : دقائق;
  ثواني = (ثواني < 10) ? '0' + ثواني : ثواني;
  return ساعات + ' ساعة ' + دقائق + ' دقيقة';
}

