import yts from 'yt-search'

var handler = async (m, { text, conn, args, command, usedPrefix }) => {

if (!text) return conn.reply(m.chat, `${emoji} من فضلك أدخل بحثًا على يوتيوب.`, m)

conn.reply(m.chat, wait, m)

let results = await yts(text)
let tes = results.all
let teks = results.all.map(v => {
switch (v.type) {
case 'video': return `「✦」نتائج البحث عن *<${text}>*

> ☁️ العنوان » *${v.title}*
> 🍬 القناة » *${v.author.name}*
> 🕝 المدة » *${v.timestamp}*
> 📆 تاريخ النشر » *${v.ago}*
> 👀 المشاهدات » *${v.views}*
> 🔗 الرابط » ${v.url}`}}).filter(v => v).join('\n\n••••••••••••••••••••••••••••••••••••\n\n')

conn.sendFile(m.chat, tes[0].thumbnail, 'yts.jpeg', teks, fkontak, m)

}
handler.help = ['ytsearch']
handler.tags = ['محرك بحث']
handler.command = ['ytbuscar', 'ytsearch', 'yts', 'بحثيوتيوب']
handler.register = true
handler.coin = 1

export default handler