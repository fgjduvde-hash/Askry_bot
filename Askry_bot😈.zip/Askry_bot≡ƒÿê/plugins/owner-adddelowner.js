// plugins/owner/owner-manager.js
// ╔════════════════════════════════════════════════════════════════╗
// ║  💀 ASKRY-BOT - OWNER MANAGER - HACKER EDITION 💀             ║
// ║  Author: Al Askry | Telegram: @askry47 | © 2026               ║
// ╚════════════════════════════════════════════════════════════════╝

const handler = async (m, { conn, text, args, usedPrefix, command }) => {
  
  // 💀 ثيم الهاكر الفاخر
  const emoji = '💀'
  const emoji2 = '⚠️'
  const success = '✅'
  const error = '❌'
  
  const why = `
${emoji}━━━━━━━━━━━━━━${emoji}
💀 *ASKRY-BOT - نظام المالكين* 💀
${emoji}━━━━━━━━━━━━━━${emoji}

⚠️ من فضلك، قم بذكر مستخدم لإضافته أو إزالته كـ *مالك (Owner)*.

📝 *طريقة الاستخدام:*
• للإضافة: ${usedPrefix}addowner @المستخدم
• للحذف: ${usedPrefix}delowner @المستخدم
• أو بالرقم: ${usedPrefix}addowner 2010xxxxxxxx

🔐 *ملاحظة:* هذا الأمر حصري للمطور: عسكري 👑

${emoji}━━━━━━━━━━━━━━${emoji}
  `.trim()

  const who = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : text ? text.replace(/[^0-9]/g, '') + '@s.whatsapp.net' : false
  if (!who) return conn.reply(m.chat, why, m, { mentions: [m.sender] })

  switch (command) {
    
    case 'addowner':
    case 'نخبة اضف':
      const nuevoNumero = who
      // تأكد إن الرقم مش مضاف قبل كده
      const exists = global.owner.some(owner => owner[0] === nuevoNumero)
      if (exists) {
        return conn.reply(m.chat, `${error} *هذا المستخدم موجود بالفعل في قائمة المالكين!*`, m)
      }
      global.owner.push([nuevoNumero, 'Owner', true])
      await conn.reply(m.chat, `
${success}━━━━━━━━━━━━━━${success}
💀 *تمت الإضافة بنجاح* 💀
${success}━━━━━━━━━━━━━━${success}

👤 المستخدم: @${nuevoNumero.split('@')[0]}
🔐 الصلاحية: *مالك (Owner)*
👑 أضيف بواسطة: عسكري

${usedPrefix}owners لعرض قائمة المالكين

${success}━━━━━━━━━━━━━━${success}
      `.trim(), m, { mentions: [nuevoNumero] })
      break

    case 'delowner':
    case 'نخبة حذف':
      const numeroAEliminar = who
      const index = global.owner.findIndex(owner => owner[0] === numeroAEliminar)
      if (index !== -1) {
        const removed = global.owner.splice(index, 1)[0]
        await conn.reply(m.chat, `
${error}━━━━━━━━━━━━━━${error}
💀 *تم الحذف بنجاح* 💀
${error}━━━━━━━━━━━━━━${error}

👤 المستخدم: @${numeroAEliminar.split('@')[0]}
🔐 الصلاحية: *تم سحبها*
👑 حُذف بواسطة: عسكري

⚠️ *تحذير:* هذا المستخدم لم يعد يملك صلاحيات المطور!

${error}━━━━━━━━━━━━━━${error}
        `.trim(), m, { mentions: [numeroAEliminar] })
      } else {
        await conn.reply(m.chat, `
${error}━━━━━━━━━━━━━━${error}
💀 *عملية فاشلة* 💀
${error}━━━━━━━━━━━━━━${error}

${emoji2} الرقم غير موجود في قائمة المالكين.

📋 *للعرض:* ${usedPrefix}owners
🔍 *للتحقق:* تأكد من صحة الرقم أو المنشن

${error}━━━━━━━━━━━━━━${error}
        `.trim(), m)
      }
      break
  }
}

// 💀 أوامر الملف
handler.command = ['addowner', 'delowner', 'نخبة اضف', 'نخبة حذف', 'مالك اضف', 'مالك حذف']
handler.rowner = true  // 🔐 حصري للمطور الرئيسي (عسكري)
handler.group = false
handler.private = false
handler.admin = false
handler.botAdmin = false

// 💀 تاجات الملف
handler.tags = ['owner', 'askry', 'system']
handler.help = ['addowner @user', 'delowner @user', 'نخبة اضف @مستخدم', 'نخبة حذف @مستخدم']

// 💀 ASKRY-BOT © 2026 Al Askry - All Rights Reserved
export default handler