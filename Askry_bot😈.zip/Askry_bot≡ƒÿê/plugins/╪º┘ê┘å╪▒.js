let handler = async (m, { conn, text, args, usedPrefix, command }) => {
  const usage = `❗ *طريقة الاستخدام:*\n\n◉ ${usedPrefix + command} @رقم\n◉ ${usedPrefix + command} ${m.sender.split('@')[0]}\n◉ ${usedPrefix + command} (بالرد على رسالة الشخص)`;

  const who = m.mentionedJid?.[0]
    || (m.quoted ? m.quoted.sender : text ? text.replace(/\D/g, '') + '@s.whatsapp.net' : false);

  if (!who) return conn.reply(m.chat, usage, m, { mentions: [m.sender] });

  const number = who.split('@')[0];
  const name = await conn.getName(who);

  if (command === 'لاونر') {
    if (global.owner.find(o => o[0] === number)) {
      return conn.reply(m.chat, `⚠️ *${name}* موجود بالفعل في قائمة المالكين.`, m);
    }
    global.owner.push([number, name]);
    return conn.reply(m.chat, `✅ تم إضافة *${name}* (@${number}) إلى قائمة *المالكين* بنجاح.`, m, { mentions: [who] });
  }

  if (command === 'لمطور') {
    if (global.rowner.find(o => o[0] === number)) {
      return conn.reply(m.chat, `⚠️ *${name}* موجود بالفعل في قائمة المطورين.`, m);
    }
    global.rowner.push([number, name]);
    return conn.reply(m.chat, `✅ تم إضافة *${name}* (@${number}) إلى قائمة *المطورين* بنجاح.`, m, { mentions: [who] });
  }

  if (command === 'ليوسر') {
    let removed = false;

    const ownerIndex = global.owner.findIndex(o => o[0] === number);
    if (ownerIndex !== -1) {
      const [removedNumber, removedName] = global.owner.splice(ownerIndex, 1)[0];
      await conn.reply(m.chat, `🗑️ تم إزالة *${removedName}* (@${removedNumber}) من *قائمة المالكين*.`, m, { mentions: [who] });
      removed = true;
    }

    const rownerIndex = global.rowner.findIndex(o => o[0] === number);
    if (rownerIndex !== -1) {
      const [removedNumber, removedName] = global.rowner.splice(rownerIndex, 1)[0];
      await conn.reply(m.chat, `🗑️ تم إزالة *${removedName}* (@${removedNumber}) من *قائمة المطورين*.`, m, { mentions: [who] });
      removed = true;
    }

    if (!removed) {
      return conn.reply(m.chat, `⚠️ هذا الشخص ليس موجودًا في قائمة المالكين أو المطورين.`, m);
    }
  }
};

handler.command = /^(لاونر|لمطور|ليوسر)$/i;
handler.owner = true;

export default handler;