// تصدير دالة تعالج جميع الرسائل الواردة
export async function all(m) {
    // إذا لم تكن المحادثة في مجموعة/خاص أو كانت الرسالة من البوت نفسه أو من بث الحالة (Status)، توقف
    if (!m.chat.endsWith('.net') || m.fromMe || m.key.remoteJid.endsWith('status@broadcast')) return;
    
    // إذا كانت المجموعة محظورة، توقف
    if (global.db.data.chats[m.chat].isBanned) return;
    
    // إذا كان المستخدم محظورًا، توقف
    if (global.db.data.users[m.sender].banned) return;
    
    // إذا كانت الرسالة من البوت نفسه (Baileys)، توقف
    if (m.isBaileys) return;
    
    // جلب جميع الردود المحفوظة في قاعدة البيانات
    let msgs = global.db.data.msgs;
    
    // إذا لم يكن النص المرسل موجودًا في قائمة الردود، توقف
    if (!(m.text in msgs)) return;
    
    // تحضير الرسالة المخزنة وإعادة إنشائها بشكل صحيح
    let _m = this.serializeM(JSON.parse(JSON.stringify(msgs[m.text]), (_, v) => {
        // إذا كانت البيانات من نوع Buffer (مثل الملفات)، تحويلها إلى Buffer
        if (
            v !== null &&
            typeof v === 'object' &&
            'type' in v &&
            v.type === 'Buffer' &&
            'data' in v &&
            Array.isArray(v.data)
        ) {
            return Buffer.from(v.data);
        }
        return v;
    }));
    
    // إعادة إرسال الرسالة المخزنة كرد على المستخدم
    await _m.copyNForward(m.chat, true);
}