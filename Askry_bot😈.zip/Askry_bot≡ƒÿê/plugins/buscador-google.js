import fetch from 'node-fetch';

let handler = async (m, { text }) => {
  if (!text) {
    m.reply(`${emoji} من فضلك، أدخل مصطلح البحث الذي تريد البحث عنه في *جوجل*.`);
    return;
  }

  const apiUrl = `https://delirius-apiofc.vercel.app/search/googlesearch?query=${encodeURIComponent(text)}`;

  try {
    const response = await fetch(apiUrl);
    const result = await response.json();

    if (!result.status) {
      m.reply('حدث خطأ أثناء البحث.');
      return;
    }

    let replyMessage = `${emoji2} نتائج البحث:\n\n`;
    result.data.slice(0, 1).forEach((item, index) => {
      replyMessage += `☁️ *${index + 1}. ${item.title}*\n`;
      replyMessage += `📰 *${item.description}*\n`;
      replyMessage += `🔗 الرابط: ${item.url}`;
    });

    m.react('✅')

    m.reply(replyMessage);
  } catch (error) {
    console.error(`${msm} خطأ في الاتصال بالواجهة البرمجية:`, error);
    m.reply(`${msm} حدث خطأ أثناء جلب النتائج.`);
  }
};

handler.command = ['google', 'جوجل'];

export default handler;