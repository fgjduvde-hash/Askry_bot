let handler = async (m, { conn, text }) => {
  let الرمز = text.trim().toUpperCase();

  if (!الرمز) {
    return conn.reply(m.chat, `${emoji} من فضلك أدخل رمز للاستبدال.`, m);
  }

  let قاعدة_الرموز = global.db.data.codes || {};
  let المستخدم = global.db.data.users[m.sender];

  if (!قاعدة_الرموز[الرمز]) {
    return conn.reply(m.chat, `${emoji2} الرمز غير صالح.`, m);
  }

  if (قاعدة_الرموز[الرمز].claimedBy.includes(m.sender)) {
    return conn.reply(m.chat, `${emoji2} لقد استبدلت هذا الرمز من قبل.`, m);
  }

  if (قاعدة_الرموز[الرمز].claimedBy.length >= 5) {
    return conn.reply(m.chat, `${emoji2} تم استنفاد هذا الرمز بالكامل... انتظر حتى يضع المنشئ رمزًا جديدًا.`, m);
  }

  المستخدم.coin += قاعدة_الرموز[الرمز].coin;
  قاعدة_الرموز[الرمز].claimedBy.push(m.sender);

  let المتبقي = 50 - قاعدة_الرموز[الرمز].claimedBy.length;

  conn.reply(m.chat, `${emoji} تم استبدال الرمز بنجاح. لقد حصلت على ${قاعدة_الرموز[الرمز].coin} ${moneda}.\nتبقى ${المتبقي} فرص لاستبدال الرمز.`, m);
}

handler.help = ['استبدال <رمز>'];
handler.tags = ['اقتصاد'];
handler.command = ['استبدال'];
handler.group = true;
handler.register = true;

export default handler;