const handler = async (m, {conn}) => {
  global.prefix = new RegExp('^[' + (opts['prefix'] || '‎xzXZ/i!#$%+£¢€¥^°=¶∆×÷π√✓©®:;?&.\\-').replace(/[|\\{}()[\]^$+*?.\-\^]/g, '\\$&') + ']');
  //await m.reply(`✅️ *تمت إعادة تعيين البادئة بنجاح!*`);
  conn.fakeReply(m.chat, `${emoji} *تمت إعادة تعيين البادئة بنجاح!*`, '0@s.whatsapp.net', '✨ تم استعادة البادئة ✨')
};
handler.help = ['إعادة_البادئة'];
handler.tags = ['owner'];
handler.command = ['اعادة تعيين بيرفكس'];
handler.rowner = true;

export default handler;