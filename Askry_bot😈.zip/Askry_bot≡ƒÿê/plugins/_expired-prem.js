// تعريف دالة أساسية (لا تفعل شيئًا هنا إلا تمرير الرسالة)
const handler = (m) => m;

// تصدير دالة تعالج جميع الرسائل الواردة
export async function all(m) {
  // البحث عن جميع المستخدمين في قاعدة البيانات
  for (const user of Object.values(global.db.data.users)) {
    // إذا كان المستخدم مميزًا (Premium) وله وقت انتهاء محدد
    if (user.premiumTime != 0 && user.premium) {
      // إذا انتهى الوقت (أصبح الوقت الحالي أكبر من وقت الانتهاء)
      if (new Date() * 1 >= user.premiumTime) {
        // إلغاء الاشتراك المميز
        user.premiumTime = 0;
        user.premium = false;

        // البحث عن معرف المستخدم (JID) المرتبط بهذا الحساب
        const JID = Object.keys(global.db.data.users).find(
          (key) => global.db.data.users[key] === user
        );

        // استخراج رقم الهاتف من الـ JID (مثال: 1234567890@s.whatsapp.net → 1234567890)
        const usuarioJid = JID.split`@`[0];

        // نص الإشعار بانتهاء الاشتراك
        const textoo = `「✐」@${usuarioJid} لقد انتهى وقت اشتراكك المميز`;

        // إرسال رسالة للمستخدم لإعلامه بانتهاء الاشتراك
        await this.sendMessage(
          JID,                     // المرسل إليه (المستخدم)
          { 
            text: textoo,          // النص المرسل
            mentions: [JID]        // ذكر المستخدم في الرسالة
          }, 
          { quoted: m }           // الاقتباس من الرسالة الأصلية (إذا وجدت)
        );
      }
    }
  }
}