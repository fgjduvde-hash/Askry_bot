let handler = async (m, { conn, text, isRowner }) => {
  if (!text) return m.reply(`${emoji} من فضلك، أدخل رسالة ترحيب للبوت.\n> مثال: #setwelcome مرحبًا user`);

  global.welcom1 = text.trim();
  
  m.reply(`${emoji} تم تغيير رسالة ترحيب البوت إلى: ${global.welcom1}`);
};

handler.help = ['تعيين رسالة ترحيب'];
handler.tags = ['tools'];
handler.command = ['تعيين رسالة ترحيب'];
handler.owner = false;
handler.admin = true;

export default handler;