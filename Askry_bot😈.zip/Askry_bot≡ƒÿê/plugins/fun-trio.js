let handler = async(m, { conn, text, usedPrefix, command }) => {

    if (m.mentionedJid && m.mentionedJid.length === 2) {
        let person1 = m.mentionedJid[0];
        let person2 = m.mentionedJid[1];
        let name1 = conn.getName(person1);
        let name2 = conn.getName(person2);
        let name3 = conn.getName(m.sender);
        const pp = './src/Imagen.jpg';

        let trio = `\t\t*ثلاثي مميز!*
        
${name1} و ${name2} لديهم *${Math.floor(Math.random() * 100)}%* من التوافق كزوجين.
بينما ${name1} و ${name3} لديهم *${Math.floor(Math.random() * 100)}%* من التوافق.
و ${name2} و ${name3} لديهم *${Math.floor(Math.random() * 100)}%* من التوافق.
ما رأيكم في ثلاثي؟ 😉`;

        conn.sendMessage(m.chat, { image: { url: pp }, caption: trio, mentions: [person1, person2, m.sender] }, { quoted: m });
    } else {
        conn.reply(m.chat, `${emoji} يرجى ذكر مستخدمين آخرين لحساب التوافق.`, m);
    }
}

handler.help = ['ثلاثي @مستخدم1 @مستخدم2'];
handler.tags = ['fun'];
handler.command = ['ثلاثي','علاقة-ثلاثية']
handler.group = true;
handler.register = true;

export default handler;