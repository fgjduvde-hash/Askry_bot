let cooldowns = {}

let handler = async (m, { conn, isPrems }) => {
let user = global.db.data.users[m.sender]
let tiempo = 5 * 60
if (cooldowns[m.sender] && Date.now() - cooldowns[m.sender] < tiempo * 1000) {
const tiempo2 = segundosAHMS(Math.ceil((cooldowns[m.sender] + tiempo * 1000 - Date.now()) / 1000))
conn.reply(m.chat, `${emoji3} يجب عليك الانتظار *${tiempo2}* لاستخدام أمر *#w* مرة أخرى.`, m)
return
}
let rsl = Math.floor(Math.random() * 500)
cooldowns[m.sender] = Date.now()
await conn.reply(m.chat, `${emoji} ${pickRandom(trabajo)} *${toNum(rsl)}* ( *${rsl}* ) ${moneda} 💸.`, m)
user.coin += rsl
}

handler.help = ['عمل']
handler.tags = ['economy']
handler.command = ['w','عمل','chambear','chamba', 'trabajar']
handler.group = true;
handler.register = true;

export default handler

function toNum(number) {
if (number >= 1000 && number < 1000000) {
return (number / 1000).toFixed(1) + 'k'
} else if (number >= 1000000) {
return (number / 1000000).toFixed(1) + 'M'
} else if (number <= -1000 && number > -1000000) {
return (number / 1000).toFixed(1) + 'k'
} else if (number <= -1000000) {
return (number / 1000000).toFixed(1) + 'M'
} else {
return number.toString()}}

function segundosAHMS(segundos) {
let minutos = Math.floor((segundos % 3600) / 60)
let segundosRestantes = segundos % 60
return `${minutos} دقيقة و ${segundosRestantes} ثانية`
}

function pickRandom(list) {
return list[Math.floor(list.length * Math.random())];
}

// Thanks to FG98
const trabajo = [
   "تعمل كقاطع بسكويت وتربح",
   "تعمل لصالح شركة عسكرية خاصة وتربح",
   "تنظم حدث تذوق نبيذ وتحصل على",
   "تنظف المدخنة وتجد",
   "تطور ألعاب كمصدر رزق وتربح",
   "عملت ساعات إضافية في المكتب مقابل",
   "تعمل كخاطف عرائس وتربح",
   "شخص قدم مسرحية، ولأنك شاهدتها أُعطيت",
   "قمت ببيع وشراء أشياء وربحت",
   "تعمل في مطعم الجدة كطباخ وتربح",
   "تعمل 10 دقائق في بيتزا هت المحلي. ربحت",
   "تعمل ككاتب لرسائل البسكويت وتربح",
   "تفحص حقيبتك وتبيع بعض الأغراض عديمة الفائدة، وتكتشف أن كل تلك الخردة كانت تساوي",
   "تطور ألعاب كمصدر رزق وتربح",
   "تعمل طوال اليوم في الشركة مقابل",
   "صممت شعارًا لشركة مقابل",
   "عملت بأفضل ما لديك في مطبعة توظف الناس وربحت ما تستحقه!",
   "تعمل كقاطع شجيرات وتربح",
   "تعمل كمؤدي صوت لبوب إسفنجة وتمكنت من ربح",
   "كنت تزرع وربحت",
   "تعمل كبنّاء قلاع رملية وتربح",
   "تعمل كفنان شارع وتربح",
   "قمت بعمل تطوعي لسبب نبيل! ولأجل ذلك السبب تلقيت",
   "قمت بإصلاح دبابة T-60 معطلة في أفغانستان. الطاقم دفع لك",
   "تعمل كعالم بيئة للثعابين وتربح",
   "تعمل في ديزني لاند كدب باندا مقنع وتربح",
   "قمت بإصلاح آلات التسلية وتلقت",
   "قمت ببعض الأعمال العشوائية في المدينة وربحت",
   "نظفت بعض العفن السام من التهوية وتربح",
   "حللت لغز تفشي الكوليرا وكافأتك الحكومة بمبلغ",
   "تعمل كعالم حيوانات وتربح",
   "بعت شطائر سمك وربحت",
   "قمت بإصلاح آلات التسلية وتلقيت",
]

