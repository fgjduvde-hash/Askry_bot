const handler = async (m, { conn, isAdmin, groupMetadata }) => {
  if (isAdmin) return m.reply(`${emoji} أنت بالفعل مشرف.`);
  try {
    await conn.groupParticipantsUpdate(m.chat, [m.sender], 'promote');
    await m.react(done);
    m.reply(`${emoji} لقد قمت بترقيتك إلى مشرف.`);
  } catch {
    m.reply(`${msm} حدث خطأ.`);
  }
};
handler.tags = ['owner'];
handler.help = ['ارفع'];
handler.command = ['ارفع'];
handler.rowner = true;
handler.group = true;
handler.botAdmin = true;

export default handler;