const handler = async (m, { conn, command, participants, text }) => {
    let users = participants.map(u => u.id).filter(v => v !== conn.user.jid)
    let who = m.quoted ? m.quoted.sender : m.mentionedJid && m.mentionedJid[0] ? m.mentionedJid[0] : m.fromMe ? conn.user.jid : m.sender

    if (!text) throw `${emoji} أدخل نصًا ليتم إرساله بعد ساعتين.*`;
    m.reply(`${emoji} سيتم إرسال النص بعد الوقت المحدد.`);

    function espera() {
        conn.reply(m.chat, text, null, { forward: text.fakeObj, mentions: users } )
    }
    setTimeout(espera, 720000);

};
handler.command = ['ليت'];
handler.rowner = true;

export default handler;