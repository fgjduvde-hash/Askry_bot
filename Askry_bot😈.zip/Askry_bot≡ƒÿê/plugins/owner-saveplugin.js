import fs from 'fs';

let handler = async (m, { text, usedPrefix, command }) => {
    if (!text) {
        return m.reply(`${emoji} من فضلك، أدخل اسم البلوجن.`);
    }

    if (!m.quoted || !m.quoted.text) {
        return m.reply(`${emoji2} قم بالرد على الرسالة التي تحتوي على محتوى البلوجن.`);
    }

    const ruta = `plugins/${text}.js`;
    
    try {
        await fs.writeFileSync(ruta, m.quoted.text);
        m.reply(`${emoji} تم حفظ البلوجن في ${ruta}`);
    } catch (error) {
        m.reply(`${msm} حدث خطأ أثناء حفظ البلوجن: ${error.message}`);
    }
};

handler.help = ['حفظ_بلوجن'];
handler.tags = ['owner'];
handler.command = ["saveplugin"];
handler.owner = true;

export default handler;