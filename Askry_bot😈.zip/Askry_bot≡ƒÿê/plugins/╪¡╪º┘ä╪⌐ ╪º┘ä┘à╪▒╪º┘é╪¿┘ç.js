/*  ────  Watch Status | 𝐘𝐮𝐤𝐢 𝐁𝐨𝐭 ────  */
import Database from '../lib/database.js'
const dbWatch = new Database('./database/adminWatch.json', null, 2)

const eliteNumbers = ['218927472437', '218917747795']

let handler = async (m, { conn, command }) => {
  if (!m.isGroup) return m.reply('❌ هذا الأمر يعمل فقط داخل المجموعات.')

  const sender = m.sender.replace(/@.+/, '')
  const isElite = eliteNumbers.includes(sender)
  const watching = dbWatch.data[m.chat]

  let status = watching
    ? '✅ *مفعّلة حالياً في هذه المجموعة.*'
    : '❌ *غير مفعّلة في هذه المجموعة.*'

  let reply = `📊 *حالة مراقبة المشرفين:*\n\n🔄 ${status}\n\n`

  if (!isElite) {
    reply += `⚠️ *تنبيه:* هذا الأمر مخصص لأعضاء النخبة فقط.\n`
  }

  reply += `\n👑 *أعضاء النخبة المعتمدون:*\n${eliteNumbers.map(n => `• +${n}`).join('\n')}`

  m.reply(reply)
}

handler.help = ['الحالة']
handler.tags = ['protect']
handler.command = /^الحالة$/i
handler.group = true
export default handler