let handler = async (m, { conn, usedPrefix, text }) => {
  let { key } = await conn.sendMessage(m.chat, { text: "جاري تحضير شيء ممتع!" }, { quoted: m });
  const array = [
    "🎈", "🎈🎈", "🎈🎈🎈", "🎈🎈", "🎈", 
    "🎈🎈🎈", "🎈🎈", "🎈", "🎈🎈🎈🎈",
    "🎈🎈", "🎈", "🎈🎈🎈", "🎈🎈", "🎈",
    "🎈🎈🎈🎈", "🎈🎈", "🎈", "🎈🎈🎈",
    "🎈🎈", "🎈", "🎉🎉"
  ];

  for (let item of array) {
    await conn.sendMessage(m.chat, { text: `${item}`, edit: key }, { quoted: m });
    await new Promise(resolve => setTimeout(resolve, 500)); // Half second delay
  }
  return conn.sendMessage(m.chat, { text: `لقد انتهى الأمر بسرعة!`.trim(), edit: key, mentions: [m.sender] }, { quoted: m });
};

handler.help = ['لعب'];
handler.tags = ['fun'];
handler.command = ['لعب','العب']
handler.group = true
handler.register = true

export default handler;