let handler = async (m, { conn }) => {
  const imageURL = 'https://files.catbox.moe/vtmt8r.jpg'

  let text = `
*🎨┇╾⪼ قــســم آلَرســم (AI Drawing)*

> ⩺ ⌟.dalle — رسم بالذكاء الاصطناعي
> ⩺ ⌟.draw — تحويل وصف إلى صورة
> ⩺ ⌟.gptimg — توليد صورة من وصف
> ⩺ ⌟.img2prompt — تحليل صورة وإنشاء وصف
> ⩺ ⌟.styleai — تحويل صورة لأنمي/ستايل فني
> ⩺ ⌟.waifudiffusion — توليد رسمة وايفو
> ⩺ ⌟.drawhd — توليد صور بجودة عالية
> ⩺ ⌟.reimagine — إعادة رسم صورة
> ⩺ ⌟.colorize — تلوين صورة أبيض وأسود
> ⩺ ⌟.restore — استعادة صور قديمة

*🎀┇لا تنسى كتابة (.) قبل كل أمر لاستخدامه!*
`.trim()

  await conn.sendMessage(m.chat, {
    image: { url: imageURL },
    caption: text,
    mentions: [m.sender]
  }, { quoted: m })
}

handler.help = ['س2']
handler.tags = ['menu']
handler.command = /^س2$/i

export default handler