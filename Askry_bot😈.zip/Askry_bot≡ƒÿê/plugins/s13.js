let handler = async (m, { conn }) => {
  const imageURL = 'https://files.catbox.moe/nm1qnn.jpg'

  let text = `
*🎸┇╾⪼ قسم الأغاني*

> ⩺ ⌟.play — تشغيل أغنية  
> ⩺ ⌟.lyrics — كلمات الأغاني  
> ⩺ ⌟.فيديو — تشغيل فيديو موسيقي  
> ⩺ ⌟.بحث_أغاني — بحث عن أغنية  
> ⩺ ⌟.تحميل_أغنية — تحميل الأغاني  
> ⩺ ⌟.راديو — تشغيل الراديو  
> ⩺ ⌟.قائمة_تشغيل — عرض قائمة التشغيل  

*🎀┇لا تنسَ كتابة (.) قبل كل أمر لاستخدامه!*
`.trim()

  await conn.sendMessage(m.chat, {
    image: { url: imageURL },
    caption: text,
    mentions: [m.sender]
  }, { quoted: m })
}

handler.help = ['س13']
handler.tags = ['menu']
handler.command = /^س13$/i

export default handler