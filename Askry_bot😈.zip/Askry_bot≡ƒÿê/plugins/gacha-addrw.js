/* Code created by @Emma (Violet's Version) @Elpapiema
Modified and adapted by @The-King-Destroy */

import fetch from 'node-fetch'

const handler = async (m, { text, usedPrefix, command, conn }) => {
    const args = text.split(',').map(arg => arg.trim())

    if (args.length < 7) {
        return m.reply(`❀ الرجاء إدخال معلومات الشخصية.\n✧ مثال: ${usedPrefix}${command} <اسم الشخصية>, <الجنس>, <القيمة>, <المصدر>, <رابط الصورة 1>, <رابط الصورة 2>, <رابط الصورة 3>\n\n> ملاحظة: يجب أن تكون الروابط من catbox.moe أو qu.ax، إذا استخدمت qu.ax يجب أن يكون الرابط دائمًا.`)
    }

    const [name, gender, value, source, img1, img2, img3] = args

    if (!img1.startsWith('http') || !img2.startsWith('http') || !img3.startsWith('http')) {
        return m.reply('✧ الرجاء تقديم روابط صالحة للصور.')
    }

    const characterData = {
        id: Date.now().toString(),
        name,
        gender,
        value,
        source,
        img: [img1, img2, img3],
        vid: [],
        user: null,
        status: "متاح",
        votes: 0
    }

    const tagNumber = '218927472437@s.whatsapp.net'

    const jsonMessage = `❀ تمت إضافة شخصية جديدة ❀\n\n\`\`\`${JSON.stringify(characterData, null, 2)}\`\`\``
    await conn.sendMessage(tagNumber, { text: jsonMessage })

    m.reply(`❀ تم إرسال الشخصية *"${name}"* إلى الإدارة للمراجعة والإضافة.`)
}

handler.command = ['إضافة-شخصية', 'addcharacter']
handler.tags = ['rw']
handler.admin = true
handler.group = false

export default handler