import { exec } from 'child_process';

let handler = async (m, { conn, command }) => {
  try {
    // أرسل رسالة انتظار
    await conn.reply(m.chat, '⏳ جارٍ تحديث وتثبيت الحزم، الرجاء الانتظار...', m);

    // دالة تنفذ أوامر shell وتنتظر النتيجة
    const runCommand = (cmd) => new Promise((resolve, reject) => {
      exec(cmd, (error, stdout, stderr) => {
        if (error) reject(stderr || error.message);
        else resolve(stdout);
      });
    });

    // تحديث الحزم
    const updateOutput = await runCommand('npm update');

    // تثبيت الحزم
    const installOutput = await runCommand('npm install');

    // أرسل نتائج التحديث والتثبيت
    await conn.reply(m.chat, `✅ تم تحديث وتثبيت الحزم بنجاح!\n\nنتيجة التحديث:\n${updateOutput}\n\nنتيجة التثبيت:\n${installOutput}`, m);

  } catch (e) {
    await conn.reply(m.chat, `❌ حدث خطأ أثناء التحديث: ${e}`, m);
  }
};

handler.command = /^تحديث$/i;
handler.owner = true;  // فقط المطور يمكنه تشغيل الأمر

export default handler;