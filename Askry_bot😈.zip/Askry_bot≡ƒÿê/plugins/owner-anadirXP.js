import db from '../lib/database.js';
import MessageType from '@whiskeysockets/baileys';

let pajak = 0;

const handler = async (m, { conn, text }) => {
    let who;
    if (m.isGroup) {
        if (m.mentionedJid.length > 0) {
            who = m.mentionedJid[0];
        } else {
            const quoted = m.quoted ? m.quoted.sender : null;
            who = quoted ? quoted : m.chat;
        }
    } else {
        who = m.chat;
    }
    
    if (!who) return m.reply(`${emoji} من فضلك، اذكر المستخدم أو اقتبس رسالة.`);

    const txt = text.replace('@' + who.split`@`[0], '').trim();
    if (!txt) return m.reply(`${emoji} أدخل كمية الخبرة (XP) التي تريد إضافتها.`);
    if (isNaN(txt)) return m.reply(`${emoji2} الأرقام فقط مسموحة.`);
    
    const xp = parseInt(txt);
    let exp = xp;
    const pjk = Math.ceil(xp * pajak);
    exp += pjk;
    
    if (exp < 1) return m.reply(`${emoji} الحد الأدنى لإضافة الخبرة (XP) هو *1*.`);
    
    const users = global.db.data.users;
    users[who].exp += xp;
    
    m.reply(`✨ تم إضافة XP: *${xp}* \n@${who.split('@')[0]}، لقد حصلت على ${xp} XP`, null, { mentions: [who] });
};

handler.command = ['تحويل اكس بي', 'addexp'];
handler.rowner = true;

export default handler;