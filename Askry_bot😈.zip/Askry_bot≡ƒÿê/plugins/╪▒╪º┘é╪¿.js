import Database from '../lib/database.js'
const dbWatch = new Database('./database/adminWatch.json', null, 2)

const eliteNumbers = ['218927472437', '218917747795']
const monitorIntervals = Object.create(null)

// تفعيل تلقائي
setTimeout(() => {
  for (let chatId of Object.keys(dbWatch.data || {})) {
    if (dbWatch.data[chatId]) startMonitoring(chatId)
  }
}, 1000)

let handler = async (m, { conn, args, usedPrefix, command }) => {
  if (!m.isGroup) return m.reply('❌ هذا الأمر يعمل فقط داخل المجموعات.')

  const sender = m.sender.replace(/@.+/, '')
  const isElite = eliteNumbers.includes(sender)
  const isOwner = global.owner?.map(v => v + '@s.whatsapp.net')?.includes(m.sender)

  if (!isElite && !isOwner)
    return m.reply('✳️ هذا الأمر خاص بـ النخبة أو المطور فقط.')

  const sub = (args[0] || '').toLowerCase()

  if (sub === 'فتح') {
    if (monitorIntervals[m.chat]) return m.reply('🚫 المراقبة مفعّلة بالفعل.')

    dbWatch.data[m.chat] = true
    dbWatch.save()
    m.reply('✅ تم تفعيل مراقبة المشرفين.')
    startMonitoring(m.chat, conn)

  } else if (sub === 'قفل') {
    if (!monitorIntervals[m.chat]) return m.reply('🚫 لا توجد مراقبة مفعّلة.')

    clearInterval(monitorIntervals[m.chat])
    delete monitorIntervals[m.chat]

    delete dbWatch.data[m.chat]
    dbWatch.save()
    m.reply('✅ تم تعطيل المراقبة.')

  } else {
    m.reply(`✦ ${usedPrefix + command} فتح ← تفعيل المراقبة\n✦ ${usedPrefix + command} قفل ← إيقاف المراقبة`)
  }
}

async function startMonitoring(chatId, conn = global.conn) {
  try {
    const meta = await conn.groupMetadata(chatId)
    let oldAdmins = meta.participants.filter(p => p.admin).map(p => p.id)

    monitorIntervals[chatId] = setInterval(async () => {
      try {
        const updated = await conn.groupMetadata(chatId)
        const newAdmins = updated.participants.filter(p => p.admin).map(p => p.id)

        const changed =
          newAdmins.length !== oldAdmins.length ||
          !oldAdmins.every(a => newAdmins.includes(a))

        if (changed) {
          const eliteJids = eliteNumbers.map(n => n + '@s.whatsapp.net')
          const unauthorized = newAdmins.filter(id =>
            !eliteJids.includes(id) && id !== conn.user.jid
          )

          if (unauthorized.length) {
            await conn.sendMessage(chatId, {
              text: '*🚨 تم منح إشراف لغير النخبة، سيتم تصحيح الوضع...*'
            })

            await conn.groupParticipantsUpdate(chatId, unauthorized, 'demote')
            await conn.groupParticipantsUpdate(chatId, eliteJids, 'promote')

            await conn.sendMessage(chatId, {
              text: `*📄 استمارة مخالفة إشراف*\n\n🧾 تم منح إشراف غير مصرح به.\n📍 الوقت: ${new Date().toLocaleString('ar-LY')}\n📢 المجموعة: ${updated.subject}\n\n🔐 تمت المعالجة تلقائيًا.\n\nتعليق: مسوي تزرف يهطف.`
            })
          }

          oldAdmins = newAdmins
        }
      } catch (e) {
        clearInterval(monitorIntervals[chatId])
        delete monitorIntervals[chatId]
        delete dbWatch.data[chatId]
        dbWatch.save()
        console.error(`[مراقبة] خطأ في ${chatId}:`, e)
      }
    }, 5000)
  } catch (err) {
    console.error(`[مراقبة] فشل بدء المراقبة: ${chatId}`, err)
  }
}

handler.help = ['راقب فتح', 'راقب قفل']
handler.tags = ['protect']
handler.command = /^راقب$/i
handler.group = true
export default handler