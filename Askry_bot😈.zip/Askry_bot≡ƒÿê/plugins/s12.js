let handler = async (m, { conn }) => {
  const imageURL = 'https://files.catbox.moe/urrsor.jpg'

  let text = `
*☕┇╾⪼ قسم النخبة*

> ⩺ ⌟.مطور — أوامر خاصة بالمطور  
> ⩺ ⌟.تحديث — تحديث البوت  
> ⩺ ⌟.أوامر_سرية — أوامر خاصة  
> ⩺ ⌟.إحصائيات — بيانات وتحليلات  
> ⩺ ⌟.سيرفر — معلومات الاستضافة  
> ⩺ ⌟.أوامر_مطور — أوامر مطورين  
> ⩺ ⌟.تنظيف — تنظيف بيانات  
> ⩺ ⌟.ريستارت — إعادة تشغيل البوت  

*🎀┇لا تنسَ كتابة (.) قبل كل أمر لاستخدامه!*
`.trim()

  await conn.sendMessage(m.chat, {
    image: { url: imageURL },
    caption: text,
    mentions: [m.sender]
  }, { quoted: m })
}

handler.help = ['س12']
handler.tags = ['menu']
handler.command = /^س12$/i

export default handler