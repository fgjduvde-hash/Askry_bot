import fetch from 'node-fetch';

let handler = async (m, { conn, text }) => {
if (!text) return conn.reply(m.chat, `${emoji} من فضلك، أدخل اسم البوكيمون الذي تريد البحث عنه.`, m)
await m.react(rwait)
conn.reply(m.chat, `${emoji2} جاري البحث عن *<${text}>*، انتظر لحظة...`, m)
const url = `https://some-random-api.com/pokemon/pokedex?pokemon=${encodeURIComponent(text)}`;
const response = await fetch(url);
const json = await response.json();
if (!response.ok) {
await m.react(error)
return conn.reply(m.chat, '⚠️ حدث خطأ أثناء البحث عن البوكيمون.', m)}
const aipokedex = `${emoji} *بوكيديكس - معلومات عن ${json.name}*\n\n☁️ *الاسم:* ${json.name}\n🔖 *الرقم:* ${json.id}\n💬 *النوع:* ${json.type}\n💪 *القدرات:* ${json.abilities}\n🎴 *الطول:* ${json.height}\n⚖️ *الوزن:* ${json.weight}\n\n📖 *الوصف:*\n${json.description}\n\n🔍 يمكنك العثور على المزيد من التفاصيل عن هذا البوكيمون في البوكيديكس!\n\n🔗 https://www.pokemon.com/ar/pokedex/${json.name.toLowerCase()}`
conn.reply(m.chat, aipokedex, m)
await m.react(done) }

handler.help = ['بوكيديكس *<اسم البوكيمون>*']
handler.tags = ['fun']
handler.group = true;
handler.register = true
handler.command = ['بوكيديكس','بوكيمون']

export default handler