import uploadImage from '../lib/uploadImage.js'
import fetch from 'node-fetch'

let handler = async (m, { conn, usedPrefix, command, args, text }) => {
  let q = m.quoted ? m.quoted : m
  let mime = (q.msg || q).mimetype || ''
  if (!mime) return conn.reply(m.chat, `${emoji} من فضلك، قم بالرد على *صورة* أو *فيديو*.`, m)
  if (!text) return conn.reply(m.chat, `${emoji} أدخل الحجم الجديد للصورة/الفيديو.`, m)
  await m.react('🕓')
  try {
    if (isNaN(text)) return conn.reply(m.chat, `${emoji2} يُسمح بالأرقام فقط.`, m).then(_ => m.react('✖️'))
    if (!/image\/(jpe?g|png)|video|document/.test(mime)) return conn.reply(m.chat, `${emoji2} التنسيق غير مدعوم.`, m)
    let img = await q.download()
    let url = await uploadImage(img)

    if (/image\/(jpe?g|png)/.test(mime)) {
      await conn.sendMessage(m.chat, { image: { url: url }, caption: ``, fileLength: `${text}`, mentions: [m.sender] }, { ephemeralExpiration: 24 * 3600, quoted: m })
      await m.react('✅')
    } else if (/video/.test(mime)) {
      await conn.sendMessage(m.chat, { video: { url: url }, caption: ``, fileLength: `${text}`, mentions: [m.sender] }, { ephemeralExpiration: 24 * 3600, quoted: m })
      await m.react('✅')
    }
  } catch {
    await m.react('✖️')
  }
}

handler.tags = ['أدوات']
handler.help = ['الحجم *<الكمية>*']
handler.command = ['filelength', 'length', 'الحجم']
//handler.limit = 1
handler.register = true

export default handler