import { createHash } from 'crypto';  
import fetch from 'node-fetch';

const handler = async (m, { conn }) => {
  let user = global.db.data.users[m.sender];

  if (!user.description) {
    return conn.reply(m.chat, `${emoji2} لا يوجد وصف محفوظ لديك يمكن حذفه.`, m);
  }

  user.description = '';

  return conn.reply(m.chat, `${emoji} تم حذف وصفك بنجاح.`, m);
};

handler.help = ['وصفي'];
handler.tags = ['rg'];
handler.command = ['وصفي', 'حذف وصفي'];
export default handler;