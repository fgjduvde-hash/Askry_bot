let handler = async (m, { conn }) => {
  let audio = 'https://files.catbox.moe/kte9q2.opus'
  let thumbnail = await (await fetch('https://files.catbox.moe/vtmt8r.jpg')).buffer()

  await conn.sendMessage(m.chat, {
    audio: { url: audio },
    mimetype: 'audio/mp4',
    ptt: true,
    fileName: 'forina.mp3',
    contextInfo: {
      externalAdReply: {
        title: "˚ ₊⊹𝑊𝑎𝑔𝑢𝑟𝑖୨🌸𝐵𝑜𝑡₊",
        body: "اضغط لفتح المحادثة مع المطور",
        thumbnail,
        mediaType: 1,
        renderLargerThumbnail: true,
        mediaUrl: "https://wa.me/218927472437",
        sourceUrl: "https://wa.me/218927472437"
      }
    }
  }, { quoted: m })
}
handler.customPrefix = /^(بوت|واغوري)$/i
handler.command = new RegExp
handler.limit = false
export default handler