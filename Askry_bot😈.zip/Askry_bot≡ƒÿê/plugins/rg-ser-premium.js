
const pHora = 30
const pDia = 700
const cHora = 1  
const cDia = 20  

let handler = async (m, { conn, usedPrefix, command, args }) => {

  let texto = `
✐ الخيارات المتاحة لشراء البريميوم:

° *h :* ساعات = ${pHora} ${moneda}
° *d :* أيام = ${pDia} ${moneda}

✧ مثال:
${command} 1 h ---> بريميوم لمدة ساعة واحدة.
${command} 1 d ---> بريميوم لمدة يوم واحد.`
  
  let name = await conn.getName(m.sender)
  if (!args[0]) return conn.reply(m.chat, texto, fkontak)
  
  let type
  let user = global.db.data.users[m.sender]
  let users = global.db.data.chats[m.chat].users[m.sender]
  
  if (isNaN(args[0])) return conn.reply(m.chat, `✧ يُسمح فقط بالأرقام.\n> مثال: ${command} 1 h`, m)
  
  let kk = args[1] || "h"
  let precio = kk === "h" ? pHora : pDia
  let comision = kk === "h" ? cHora : cDia 
  
  if (!args[1] || (args[1] !== "h" && args[1] !== "d")) {
    return conn.reply(m.chat, `✧ تنسيق غير صالح.`, m)
  }
  
  if (users.coin < (precio + comision)) {
    return conn.reply(m.chat, `✧ ليس لديك ما يكفي من ${moneda} لشراء عضوية البريميوم!`, m)
  }
  
  let tiempo
  if (args[1] === "h") {
    tiempo = 3600000 * args[0]
    let now = new Date() * 1
    if (now < user.premiumTime) user.premiumTime += tiempo
    else user.premiumTime = now + tiempo
    user.premium = true
    users.coin -= (pHora * args[0]) + (cHora * args[0])
    type = "ساعة(ساعات)"
  } else if (args[1] === "d") {
    tiempo = 86400000 * args[0]
    let now = new Date() * 1
    if (now < user.premiumTime) user.premiumTime += tiempo
    else user.premiumTime = now + tiempo
    user.premium = true
    users.coin -= (pDia * args[0]) + (cDia * args[0]) 
    type = "يوم(أيام)"
  }
  
  let cap = `  \`\`\`乂 شراء - بريميوم 乂\`\`\`

ᰔᩚ المستخدم » @${m.sender.split`@`[0]}
ⴵ مدة البريميوم » ${args[0]} ${type}
✦ الإجمالي المدفوع » ${precio * args[0] + comision * args[0]} ${moneda}
⛁ ${moneda} » ${users.coin}
✰ كان لديه » ${users.coin + precio * args[0] + comision * args[0]}
✧ العمولة » -${comision * args[0]} (شاملة)`
  
  conn.sendMessage(m.chat, { text: cap, mentions: [m.sender] }, { quoted: fkontak })
}

handler.tags = ['rg']
handler.help = ['بريميوم']
handler.command = ['vip', 'premium', 'prem']

export default handler