let handler = async (m, { conn, args }) => {
  if (!args.length) return conn.sendMessage(m.chat, { text: `${emoji} من فضلك اكتب النص الذي تريد تكراره.` });
  let message = args.join(' ');

  let invisibleChar = '\u200B';
  let finalMessage = invisibleChar + message;

  let mentions = [...message.matchAll(/@(\d+)/g)].map(v => v[1] + '@s.whatsapp.net');
  if (mentions.length) {
    conn.sendMessage(m.chat, { text: finalMessage, mentions });
  } else {
    conn.sendMessage(m.chat, { text: finalMessage });
  }
};

handler.command = ['قل', 'قلها']
handler.tag = ['أدوات'];
handler.group = true;

export default handler;