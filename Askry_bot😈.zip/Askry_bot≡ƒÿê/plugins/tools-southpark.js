/* معلومات الدولة بواسطة WillZek
- https://github.com/WillZek
- https://whatsapp.com/channel/0029Vb1AFK6HbFV9kaB3b13W
*/

import fetch from 'node-fetch';

let handler = async (m, { conn, text, usedPrefix, command }) => {

  if (!text) return m.reply(m.chat, `${emoji} من فضلك أدخل اسم دولة.`, m);

  try {
    let api = `https://delirius-apiofc.vercel.app/tools/flaginfo?query=${text}`;

    let response = await fetch(api);
    let json = await response.json();
    let datas = json.data;

    let park = `🍭 *معلومات عن:* ${text}\n\n🍬 *الاسم الرسمي:* ${datas.officialName}\n🍰 *العضوية في منظمة:* ${datas.memberOf}\n🔖 *العاصمة:* ${datas.capitalCity}\n🗺️ *القارة:* ${datas.continent}\n👥 *عدد السكان:* ${datas.population}\n💬 *رمز الاتصال:* ${datas.callingCode}\n💸 *العملة:* ${datas.currency}\n📜 *الوصف:* ${datas.description}`;

    let img = datas.image;

    conn.sendMessage(m.chat, { image: { url: img }, caption: park }, { quoted: fkontak });

  } catch (e) {
    m.reply(`${msm} حدث خطأ: ${e.message}`);
    m.react('✖️');
  }
};

handler.command = ['معلومات_دولة', 'علم'];

export default handler;