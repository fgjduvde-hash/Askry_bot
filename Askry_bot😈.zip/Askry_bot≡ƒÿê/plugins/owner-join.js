
let linkRegex = /https:\/\/chat\.whatsapp\.com\/([0-9A-Za-z]{20,24})/i;

let handler = async (m, { conn, text, isOwner }) => {
    if (!text) return m.reply(`${emoji} يجب إرسال دعوة لينضم *${botname}* إلى المجموعة.`);

    let [_, code] = text.match(linkRegex) || [];

    if (!code) return m.reply(`${emoji2} رابط الدعوة غير صالح.`);

    if (isOwner) {
        await conn.groupAcceptInvite(code)
            .then(res => m.reply(`${emoji} انضممت إلى المجموعة بنجاح.`))
            .catch(err => m.reply(`${msm} حدث خطأ أثناء الانضمام إلى المجموعة.`));
    } else {
        let message = `${emoji} دعوة إلى مجموعة:\n${text}\n\nبواسطة: @${m.sender.split('@')[0]}`;
        await conn.sendMessage(`${suittag}` + '@s.whatsapp.net', { text: message, mentions: [m.sender] }, { quoted: m });
        m.reply(`${emoji} تم إرسال رابط المجموعة، شكرًا على دعوتك. ฅ^•ﻌ•^ฅ`);
    }
};

handler.help = ['ادخل'];
handler.tags = ['المالك', 'أدوات'];
handler.command = ['انضم', 'ادخل'];

export default handler;