import fs from 'fs';
import path from 'path';

let handler = async (m, { conn, text }) => {
  if (!text) {
    return conn.reply(m.chat, '⚠️ يرجى إدخال الكلمة المطلوبة للبحث عنها.', m);
  }

  await conn.reply(m.chat, '🔍 جاري البحث عن الكلمة في ملفات المسار plugins...', m);

  const basePath = './plugins'; // تأكد من المسار الصحيح
  let files;
  try {
    files = fs.readdirSync(basePath).filter(file => file.endsWith('.js'));
  } catch (e) {
    return conn.reply(m.chat, `❌ لم أستطع قراءة مجلد plugins.\nالخطأ: ${e.message}`, m);
  }

  const matchedResults = [];
  const fileReadErrors = [];

  // الأنماط المحددة
  const validPatterns = [
    /^handler\.command\s*=\s*\/\^(tr)\$\/i/,
    /^const\s+audioCommands\s*=\s*\[.*\]/,
    /handler\.help\s*=\s*\[.*\]/,
    /handler\.command\s*=\s*\/\^.*\$/i,
    /=\s*\[.*\]/,
  ];

  for (let i = 0; i < files.length; i++) {
    const fileName = files[i];
    const filePath = path.join(basePath, fileName);

    try {
      const fileContent = fs.readFileSync(filePath, 'utf-8');
      const fileLines = fileContent.split('\n');

      fileLines.forEach((line, idx) => {
        if (line.includes(text)) {
          if (validPatterns.some(pattern => pattern.test(line))) {
            matchedResults.push({
              fileIndex: i + 1,
              fileName,
              lineNumber: idx + 1,
              lineContent: line.trim(),
            });
          }
        }
      });
    } catch (error) {
      fileReadErrors.push({ fileName, error: error.message });
    }
  }

  if (matchedResults.length > 0) {
    let responseMessage = `✅ تم العثور على "${text}" في الملفات التالية:\n\n`;
    matchedResults.forEach(({ fileIndex, fileName, lineNumber, lineContent }) => {
      responseMessage += `📄 رقم الكود: ${fileIndex}\n📄 الملف: ${fileName}\n🔢 السطر: ${lineNumber}\n➡️ السطر: ${lineContent}\n\n`;
    });
    await conn.reply(m.chat, responseMessage.trim(), m);
  } else {
    let errorMessage = `❌ لم يتم العثور على "${text}" في أي ملف ضمن المسار plugins.\n`;

    if (fileReadErrors.length > 0) {
      errorMessage += '\n⚠️ أخطاء أثناء قراءة بعض الملفات:\n';
      fileReadErrors.forEach(({ fileName, error }) => {
        errorMessage += `- الملف: ${fileName}\n  السبب: ${error}\n`;
      });
    }

    await conn.reply(m.chat, errorMessage.trim(), m);
  }
};

handler.help = ['كشف *<الكلمة>*'];
handler.tags = ['owner'];
handler.command = /^(تورك)$/i;
handler.owner = true;  // فقط مالك البوت

export default handler;