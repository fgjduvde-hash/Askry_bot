global.math = global.math ? global.math : {};

const handler = async (m, { conn }) => {
  const id = m.chat;
  if (!m.quoted) return;
  if (m.quoted.sender != conn.user.jid) return;
  if (!/^كم هو ناتج:/i.test(m.quoted.text) && !/^Cuanto es el resultado de:/i.test(m.quoted.text)) return;
  if (!(id in global.math)) return conn.reply(m.chat, `${emoji2} تم الإجابة على هذا السؤال بالفعل.`, m);

  if (m.quoted.id == global.math[id][0].id) {
    const math = global.math[id][1];

    if (m.text == math.result) {
      conn.reply(m.chat, `✅ إجابة صحيحة!\n🎉 ربحت: ${math.bonus} نقطة خبرة.`, m);
      global.db.data.users[m.sender].exp += math.bonus;
      clearTimeout(global.math[id][3]);
      delete global.math[id];
    } else {
      if (--global.math[id][2] == 0) {
        conn.reply(m.chat, `❌ انتهت محاولاتك.\n✅ الجواب الصحيح هو: ${math.result}`, m);
        clearTimeout(global.math[id][3]);
        delete global.math[id];
      } else {
        conn.reply(m.chat, `❌ إجابة خاطئة!\n📌 عدد المحاولات المتبقية: ${global.math[id][2]}`, m);
      }
    }
  }
};

handler.customPrefix = /^-?[0-9]+(\.[0-9]+)?$/;
handler.command = new RegExp;

export default handler;