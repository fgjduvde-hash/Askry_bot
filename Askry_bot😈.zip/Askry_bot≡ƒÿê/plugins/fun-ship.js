var handler = async (m, { conn, command, text }) => {
  if (!text) return conn.reply(m.chat, `${emoji} اكتب اسمك واسم الشخص الآخر لحساب فرص الحب بينكما.`, m)
  
  let [text1, ...text2] = text.split(' ')
  text2 = (text2 || []).join(' ')
  
  if (!text2) return conn.reply(m.chat, `${emoji2} اكتب اسم الشخص الثاني.`, m)
  
  let love = `❤️ *${text1}* فرصتك في الوقوع في حب *${text2}* هي ${Math.floor(Math.random() * 100)}% 👩🏻‍❤️‍👨🏻`
  
  m.reply(love, null, { mentions: conn.parseMention(love) })
}

handler.help = ['حب', 'علاقة']
handler.tags = ['fun']
handler.command = ['حب','علاقة']
handler.group = true;
handler.register = true

export default handler