import { exec } from 'child_process'
import fs from 'fs/promises'
import path from 'path'
import os from 'os'

const tempAudioPath = path.join(os.tmpdir(), 'savedAudio.mp3')

// دمج صوت وفيديو
async function mergeAudioVideo(videoBuffer, audioBuffer) {
  const videoPath = path.join(os.tmpdir(), `video_${Date.now()}.mp4`)
  const audioPath = path.join(os.tmpdir(), `audio_${Date.now()}.mp3`)
  const outputPath = path.join(os.tmpdir(), `output_${Date.now()}.mp4`)

  await fs.writeFile(videoPath, videoBuffer)
  await fs.writeFile(audioPath, audioBuffer)

  return new Promise((resolve, reject) => {
    const cmd = `ffmpeg -i "${videoPath}" -i "${audioPath}" -c:v copy -c:a aac -map 0:v:0 -map 1:a:0 -shortest "${outputPath}"`
    exec(cmd, async (err) => {
      await fs.unlink(videoPath).catch(() => {})
      await fs.unlink(audioPath).catch(() => {})
      if (err) return reject(err)
      try {
        const data = await fs.readFile(outputPath)
        await fs.unlink(outputPath).catch(() => {})
        resolve(data)
      } catch (e) {
        reject(e)
      }
    })
  })
}

let handler = async (m, { conn, command }) => {
  let q = m.quoted
  if (!q) return m.reply('*✳️ يجب الرد على رسالة صوتية أو فيديو*')
  let mime = q?.mimetype || ''

  if (command === 'حفظصوت') {
    if (!/audio/.test(mime)) return m.reply('*✳️ يجب الرد على رسالة صوتية لحفظها*')
    let audio = await q.download?.()
    if (!audio) return m.reply('❎ فشل تحميل الصوت')
    await fs.writeFile(tempAudioPath, audio)
    return m.reply('✅ تم حفظ الصوت بنجاح!')
  }

  if (command === 'تركيبصوت') {
    if (!/video/.test(mime)) return m.reply('*✳️ يجب الرد على فيديو لتركيب الصوت عليه*')
    let video = await q.download?.()
    if (!video) return m.reply('❎ فشل تحميل الفيديو')

    // تأكد أن الصوت محفوظ
    let exists = await fs.stat(tempAudioPath).catch(() => false)
    if (!exists) return m.reply('❎ لم يتم حفظ أي صوت. استخدم "حفظصوت" أولاً')

    let savedAudio = await fs.readFile(tempAudioPath)
    let finalVideo = await mergeAudioVideo(video, savedAudio).catch(() => null)
    if (!finalVideo) return m.reply('❎ فشل تركيب الصوت على الفيديو')
    await conn.sendFile(m.chat, finalVideo, 'output.mp4', '✅ تم تركيب الصوت بنجاح', m)
  }
}

handler.help = ['حفظ صوت', 'تركيب صوت']
handler.tags = ['fun']
handler.command = /^(حفظ صوت|تركيب صوت)$/i

export default handler