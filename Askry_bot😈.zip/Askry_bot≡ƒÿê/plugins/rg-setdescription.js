import { createHash } from 'crypto';  
import fetch from 'node-fetch';

const handler = async (m, { conn, command, usedPrefix, text }) => {

let user = global.db.data.users[m.sender];

if (user.description) {
return conn.reply(m.chat, `${emoji2} لديك وصف مُحدد مسبقًا، إذا أردت حذف الوصف الحالي استخدم:\n> » ${usedPrefix}deldescription`, m);
}

if (!text) return conn.reply(m.chat, `${emoji}︎ يجب عليك تحديد وصف صالح لملفك الشخصي.\n\n> ✐ مثال » *${usedPrefix + command} مرحبًا، أستخدم واتساب!*`, m);

user.description = text;

return conn.reply(m.chat, `${emoji} تم تعيين وصفك.\n\n> *${user.description}*`, m);
};

handler.help = ['تعيين_الوصف']
handler.tags = ['rg']
handler.command = ['وصف ملفي', 'setdesc']
export default handler;