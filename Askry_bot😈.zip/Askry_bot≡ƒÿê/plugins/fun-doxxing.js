// كود مقدم من طرف LAN تابعني على انستغرام https://www.instagram.com/lansg___/

import {performance} from 'perf_hooks';
const handler = async (m, {conn, text}) => {
const start = performance.now();    
const end = performance.now();
const executionTime = (end - start);
async function loading() {
var hawemod = [
    "حقن برمجيات خبيثة",
    " █ 10%",
    " █ █ 20%",
    " █ █ █ 30%",
    " █ █ █ █ 40%",
    " █ █ █ █ █ 50%",
    " █ █ █ █ █ █ 60%",
    " █ █ █ █ █ █ █ 70%",
    " █ █ █ █ █ █ █ █ 80%",
    " █ █ █ █ █ █ █ █ █ 90%",
    " █ █ █ █ █ █ █ █ █ █ 100%",
    "جاري اختراق النظام.. \\n الاتصال بالسيرفر... خطأ 404",
    "تم الاتصال بالجهاز بنجاح... \\n جاري استقبال البيانات...",
    "تم سرقة البيانات بنسبة 100% \\n جاري مسح الأدلة...",
    " !تم الاختراق بنجاح ",
    " جاري إرسال المستندات...",
    " تم إرسال البيانات بنجاح وقطع الاتصال",
    "تم مسح السجلات"
  ];
      let { key } = await conn.sendMessage(m.chat, {text: `*☠ بدء عملية الاختراق ☠*`}, {quoted: m})
 for (let i = 0; i < hawemod.length; i++) {
   await new Promise(resolve => setTimeout(resolve, 1000)); 
   await conn.sendMessage(m.chat, {text: hawemod[i], edit: key}, {quoted: m}); 
  }     
 }
loading()    
};
handler.help = ['اختراق <اسم> | <@منشن>'];
handler.tags = ['fun'];
handler.command = ['اختراق','هاك']
handler.group = true
handler.register = true

export default handler;

function getRandomValue(arr) {
    return arr[Math.floor(Math.random() * arr.length)];
}