import util from 'util'
import path from 'path'

let user = a => '@' + a.split('@')[0]

function handler(m, { groupMetadata, command, conn, text, usedPrefix }) {
  if (!text) return conn.reply(m.chat, `${emoji} من فضلك، أدخل نصًا لعمل قائمة أفضل 10 *النص*.`, m)
  
  let ps = groupMetadata.participants.map(v => v.id)
  let [a, b, c, d, e, f, g, h, i, j] = Array(10).fill().map(() => ps.getRandom())
  let k = Math.floor(Math.random() * 70)
  let x = `${pickRandom(['🤓','😅','😂','😳','😎', '🥵', '😱', '🤑', '🙄', '💩','🍑','🤨','🥴','🔥','👇🏻','😔', '👀','🌚'])}`
  let vn = `https://hansxd.nasihosting.com/sound/sound${k}.mp3`
  
  let top = `*${x} أفضل 10 ${text} ${x}*
  
*1. ${user(a)}*
*2. ${user(b)}*
*3. ${user(c)}*
*4. ${user(d)}*
*5. ${user(e)}*
*6. ${user(f)}*
*7. ${user(g)}*
*8. ${user(h)}*
*9. ${user(i)}*
*10. ${user(j)}*`
  
  m.reply(top, null, { mentions: [a, b, c, d, e, f, g, h, i, j] })
}

handler.help = ['أفضل *<النص>*']
handler.command = ['أفضل','توب']
handler.tags = ['fun']
handler.group = true
handler.register = true

export default handler

function pickRandom(list) {
  return list[Math.floor(Math.random() * list.length)]
}