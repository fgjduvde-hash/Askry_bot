let cooldowns = {}

let handler = async (m, { conn, text, command, usedPrefix }) => {
  let المستخدمون = global.db.data.users
  let معرف_المرسل = m.sender
  let اسم_المرسل = conn.getName(معرف_المرسل)

  let وقت_الانتظار = 5 * 60
  if (cooldowns[m.sender] && Date.now() - cooldowns[m.sender] < وقت_الانتظار * 1000) {
    let الوقت_المتبقي = segundosAHMS(Math.ceil((cooldowns[m.sender] + وقت_الانتظار * 1000 - Date.now()) / 1000))
    m.reply(`${emoji3} لقد ارتكبت جريمة مؤخراً، انتظر ⏱️ *${الوقت_المتبقي}* لارتكاب جريمتك التالية وتجنب الوقوع.`)
    return
  }
  cooldowns[m.sender] = Date.now()

  let عملات_المرسل = المستخدمون[معرف_المرسل].coin || 0
  let معرف_عشوائي = Object.keys(المستخدمون)[Math.floor(Math.random() * Object.keys(المستخدمون).length)]

  while (معرف_عشوائي === معرف_المرسل) {
    معرف_عشوائي = Object.keys(المستخدمون)[Math.floor(Math.random() * Object.keys(المستخدمون).length)]
  }

  let عملات_المستخدم_العشوائي = المستخدمون[معرف_عشوائي].coin || 0
  let الحد_الأدنى = 15
  let الحد_الأقصى = 50
  let مبلغ_السرقة = Math.floor(Math.random() * (الحد_الأقصى - الحد_الأدنى + 1)) + الحد_الأدنى
  let اختيار_عشوائي = Math.floor(Math.random() * 3)

  switch (اختيار_عشوائي) {
    case 0:
      المستخدمون[معرف_المرسل].coin += مبلغ_السرقة
      المستخدمون[معرف_عشوائي].coin -= مبلغ_السرقة
      conn.sendMessage(m.chat, {
        text: `${emoji} نجحت في ارتكاب جريمتك بنجاح! لقد سرقت *${مبلغ_السرقة} ${moneda} 💸* من @${معرف_عشوائي.split("@")[0]}\n\nتمت إضافة *+${مبلغ_السرقة} ${moneda} 💸* إلى رصيد ${اسم_المرسل}.`,
        contextInfo: {
          mentionedJid: [معرف_عشوائي],
        }
      }, { quoted: m })
      break

    case 1:
      let مبلغ_الخصم = Math.min(Math.floor(Math.random() * (عملات_المرسل - الحد_الأدنى + 1)) + الحد_الأدنى, الحد_الأقصى)
      المستخدمون[معرف_المرسل].coin -= مبلغ_الخصم
      conn.reply(m.chat, `${emoji2} لم تكن حذراً وتم القبض عليك أثناء ارتكاب جريمتك، تم خصم *-${مبلغ_الخصم} ${moneda} 💸* من رصيد ${اسم_المرسل}.`, m)
      break

    case 2:
      let مبلغ_صغير_مأخوذ = Math.min(Math.floor(Math.random() * (عملات_المستخدم_العشوائي / 2 - الحد_الأدنى + 1)) + الحد_الأدنى, الحد_الأقصى)
      المستخدمون[معرف_المرسل].coin += مبلغ_صغير_مأخوذ
      المستخدمون[معرف_عشوائي].coin -= مبلغ_صغير_مأخوذ
      conn.sendMessage(m.chat, {
        text: `${emoji} نجحت في ارتكاب جريمتك لكن تم اكتشافك، ولم تستطع أخذ سوى *${مبلغ_صغير_مأخوذ} ${moneda} 💸* من @${معرف_عشوائي.split("@")[0]}\n\nتمت إضافة *+${مبلغ_صغير_مأخوذ} ${moneda} 💸* إلى رصيد ${اسم_المرسل}.`,
        contextInfo: {
          mentionedJid: [معرف_عشوائي],
        }
      }, { quoted: m })
      break
  }
  global.db.write()
}

handler.tags = ['اقتصاد']
handler.help = ['جريمة']
handler.command = ['جريمة', 'crime']
handler.register = true
handler.group = true

export default handler

function segundosAHMS(ثواني) {
  let ساعات = Math.floor(ثواني / 3600)
  let دقائق = Math.floor((ثواني % 3600) / 60)
  let ثواني_متبقية = ثواني % 60
  return `${دقائق} دقائق و ${ثواني_متبقية} ثواني`
}

