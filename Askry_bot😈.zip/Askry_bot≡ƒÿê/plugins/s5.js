let handler = async (m, { conn }) => {
  const imageURL = 'https://files.catbox.moe/3hngg9.jpg'

  let text = `
*📚┇╾⪼ قسم الفروع*

> ⩺ ⌟.انمي — عرض معلومات أنمي  
> ⩺ ⌟.مانجا — عرض معلومات مانجا  
> ⩺ ⌟.character — عرض معلومات شخصية أنمي  
> ⩺ ⌟.wallanime — خلفيات أنمي  
> ⩺ ⌟.nekopoi — محتوى خاص نيكوبوي  
> ⩺ ⌟.quotesanime — اقتباسات من الأنمي  
> ⩺ ⌟.waifu • .loli — شخصيات أنمي عشوائية  
> ⩺ ⌟.randomanime — صور أنمي عشوائية 
> ⩺ ⌟.cosplay — صور كوسبلاي  

*🎀┇لا تنسَ كتابة (.) قبل كل أمر لاستخدامه!*
`.trim()

  await conn.sendMessage(m.chat, {
    image: { url: imageURL },
    caption: text,
    mentions: [m.sender]
  }, { quoted: m })
}

handler.help = ['س5']
handler.tags = ['menu']
handler.command = /^س5$/i

export default handler