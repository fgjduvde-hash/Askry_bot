const handler = async (m, { conn, args, text, usedPrefix, command }) => {
    let user;
    let db = global.db.data.users;

    if (m.quoted) {
        user = m.quoted.sender;
    } else if (args.length >= 1) {
        user = args[0].replace('@', '') + '@s.whatsapp.net';
    } else {
        await conn.reply(m.chat, `${emoji} من فضلك، قم بذكر المستخدم أو أدخل رقمه لفك الحظر عنه.`, m);
        return;
    }

    if (db[user]) {
        db[user].banned = false;
        db[user].banRazon = '';

        const nametag = await conn.getName(user);
        const nn = await conn.getName(m.sender);

        await conn.reply(m.chat, `${done} تم فك الحظر عن المستخدم *${nametag}*.`, m, { mentionedJid: [user] });
        conn.reply(`${suittag}@s.whatsapp.net`, `${emoji} تم فك الحظر عن المستخدم *${nametag}* بواسطة *${nn}*.`, m);
    } else {
        await conn.reply(m.chat, `${emoji4} المستخدم غير مسجل في قاعدة البيانات.`, m);
    }
};

handler.help = ['فك حظر <@tag>'];
handler.command = ['فك حظر'];
handler.tags = ['mods'];
handler.rowner = true;

export default handler;