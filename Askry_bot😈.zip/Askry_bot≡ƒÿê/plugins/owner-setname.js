let handler = async (m, { conn, text, isRowner }) => {
  if (!text) return m.reply(`${emoji} من فضلك، أدخل اسمًا للبوت.\n> مثال: #setname الاسم/النص`);

  const names = text.split('/');
  if (names.length !== 2) 
    return m.reply(`${emoji} من فضلك، أدخل الاسمين مفصولين بشرطة مائلة (/) بالصيغة التالية: الاسم1/النص`);

  global.botname = names[0].trim();
  const texto1bot = ` • مُدار بواسطة ${etiqueta}`;
  global.textbot = `${names[1].trim()}${texto1bot}`;
  
  m.reply(`${emoji} تم تغيير اسم البوت إلى: ${global.botname}\n\n> ${emoji2} تم تغيير نص البوت إلى: ${global.textbot}`);
};

handler.help = ['بايو'];
handler.tags = ['tools'];
handler.command = ['بايو'];
handler.rowner = true;

export default handler;