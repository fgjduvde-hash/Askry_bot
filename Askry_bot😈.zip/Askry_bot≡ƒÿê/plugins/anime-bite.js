/*
❀ الكود من إنشاء Destroy
✧ https://github.com/The-King-Destroy/Yuki_Suou-Bot.git
*/

import fs from 'fs'
import path from 'path'

let handler = async (m, { conn, usedPrefix }) => {
    let من = m.mentionedJid.length > 0 ? m.mentionedJid[0] : (m.quoted ? m.quoted.sender : m.sender)
    let اسم = conn.getName(من)
    let اسم_المرسل = conn.getName(m.sender)

    let النص = m.mentionedJid.length > 0 || m.quoted
        ? `\`${اسم_المرسل}\` عضَّ \`${اسم || من}\` ≽^•⩊•^≼`
        : `\`${اسم_المرسل}\` عضَّ نفسه ≽^•⩊•^≼`
    
    if (m.isGroup) {
        let ف1 = 'https://raw.githubusercontent.com/The-King-Destroy/Adiciones/main/Contenido/1742789640809.mp4'
        let ف2 = 'https://raw.githubusercontent.com/The-King-Destroy/Adiciones/main/Contenido/1742789647443.mp4'
        let ف3 = 'https://raw.githubusercontent.com/The-King-Destroy/Adiciones/main/Contenido/1742789653530.mp4'
        let ف4 = 'https://raw.githubusercontent.com/The-King-Destroy/Adiciones/main/Contenido/1742789660235.mp4'
        let ف5 = 'https://raw.githubusercontent.com/The-King-Destroy/Adiciones/main/Contenido/1742789666686.mp4'
        let ف6 = 'https://raw.githubusercontent.com/The-King-Destroy/Adiciones/main/Contenido/1742789604757.mp4'
        let ف7 = 'https://raw.githubusercontent.com/The-King-Destroy/Adiciones/main/Contenido/1742789611045.mp4'
        let ف8 = 'https://raw.githubusercontent.com/The-King-Destroy/Adiciones/main/Contenido/1742789617091.mp4'
        let ف9 = 'https://raw.githubusercontent.com/The-King-Destroy/Adiciones/main/Contenido/1742789623357.mp4'
        let ف10 = 'https://raw.githubusercontent.com/The-King-Destroy/Adiciones/main/Contenido/1742789629746.mp4'
        let ف11 = 'https://raw.githubusercontent.com/The-King-Destroy/Adiciones/main/Contenido/1742789592139.mp4'
        let ف12 = 'https://raw.githubusercontent.com/The-King-Destroy/Adiciones/main/Contenido/1742789597656.mp4'
        let ف13 = 'https://raw.githubusercontent.com/The-King-Destroy/Adiciones/main/Contenido/1745595529576.mp4'
        let ف14 = 'https://raw.githubusercontent.com/The-King-Destroy/Adiciones/main/Contenido/1745595524733.mp4'
        let ف15 = 'https://raw.githubusercontent.com/The-King-Destroy/Adiciones/main/Contenido/1745595520348.mp4'
        
        const المقاطع = [ف1, ف2, ف3, ف4, ف5, ف6, ف7, ف8, ف9, ف10, ف11, ف12, ف13, ف14, ف15]
        const المقطع = المقاطع[Math.floor(Math.random() * المقاطع.length)]
        
        conn.sendMessage(
            m.chat,
            { video: { url: المقطع }, gifPlayback: true, caption: النص, ptt: true, mentions: [من] },
            { quoted: m }
        )
    }
}

handler.help = ['عض']
handler.tags = ['انمي']
handler.command = ['عض', 'عضة']
handler.group = true

export default handler