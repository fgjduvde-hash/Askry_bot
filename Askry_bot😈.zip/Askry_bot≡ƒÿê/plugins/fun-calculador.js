const handler = async (m, { conn, command, text, usedPrefix }) => {
  if (!text) return conn.reply(m.chat, `❀ من فضلك، ضع علامة على مستخدم للتحقق من اختباره.`, m);
  const percentages = (500).getRandom();
  let emoji = '';
  let description = '';
  switch (command) {
    case 'gay':
      emoji = '🏳️‍🌈';
      if (percentages < 50) {
        description = `💙 أظهرت الحسابات أن ${text.toUpperCase()} هو *${percentages}%* مثلي ${emoji}\n> ✰ هذه نسبة منخفضة، أنت لست مثليًا بل مجرد خجول!`;
      } else if (percentages > 100) {
        description = `💜 أظهرت الحسابات أن ${text.toUpperCase()} هو *${percentages}%* مثلي ${emoji}\n> ✰ أكثر مثليًا مما كنا نعتقد!`;
      } else {
        description = `🖤 أظهرت الحسابات أن ${text.toUpperCase()} هو *${percentages}%* مثلي ${emoji}\n> ✰ أنت بالتأكيد مثلي الجنس.`;
      }
      break;
    case 'lesbiana':
      emoji = '🏳️‍🌈';
      if (percentages < 50) {
        description = `👻 أظهرت الحسابات أن ${text.toUpperCase()} هي *${percentages}%* ${command} ${emoji}\n✰ ربما تحتاجين إلى المزيد من الأفلام الرومانسية في حياتك.`;
      } else if (percentages > 100) {
        description = `❣️ أظهرت الحسابات أن ${text.toUpperCase()} هي *${percentages}%* ${command} ${emoji}\n> ✰ هذا حب شديد للفتيات!`;
      } else {
        description = `💗 أظهرت الحسابات أن ${text.toUpperCase()} هي *${percentages}%* ${command} ${emoji}\n> ✰ حافظي على الحب المزدهر!`;
      }
      break;
    case 'pajero':
    case 'pajera':
      emoji = '😏💦';
      if (percentages < 50) {
        description = `🧡 أظهرت الحسابات أن ${text.toUpperCase()} هو *${percentages}%* ${command} ${emoji}\n> ✰ ربما تحتاج إلى هوايات أكثر!`;
      } else if (percentages > 100) {
        description = `💕 أظهرت الحسابات أن ${text.toUpperCase()} هو *${percentages}%* ${command} ${emoji}\n> ✰ هذا تحمل رائع!`;
      } else {
        description = `💞 أظهرت الحسابات أن ${text.toUpperCase()} هو *${percentages}%* ${command} ${emoji}\n> ✰ استمر في العمل الجيد (بمفردك).`;
      }
      break;
    case 'puto':
    case 'puta':
      emoji = '🔥🥵';
      if (percentages < 50) {
        description = `😼 أظهرت الحسابات أن ${text.toUpperCase()} هو *${percentages}%* ${command} ${emoji}\n> ✧ حظًا أوفر في مغامرتك القادمة!`;
      } else if (percentages > 100) {
        description = `😻 أظهرت الحسابات أن ${text.toUpperCase()} هو *${percentages}%* ${command}. ${emoji}\n> ✰ أنت مشتعل!`;
      } else {
        description = `😺 أظهرت الحسابات أن ${text.toUpperCase()} هو *${percentages}%* ${command} ${emoji}\n> ✰ حافظ على هذا السحر الحار!`;
      }
      break;
    case 'manco':
    case 'manca':
      emoji = '💩';
      if (percentages < 50) {
        description = `🌟 أظهرت الحسابات أن ${text.toUpperCase()} هو *${percentages}%* ${command} ${emoji}\n> ✰ لست الوحيد في هذا النادي!`;
      } else if (percentages > 100) {
        description = `💌 أظهرت الحسابات أن ${text.toUpperCase()} هو *${percentages}%* ${command} ${emoji}\n> ✰ لديك موهبة خاصة جدًا!`;
      } else {
        description = `🥷 أظهرت الحسابات أن ${text.toUpperCase()} هو *${percentages}%* ${command} ${emoji}\n> ✰ حافظ على هذه الشجاعة!`;
      }
      break;
    case 'rata':
      emoji = '🐁';
      if (percentages < 50) {
        description = `💥 أظهرت الحسابات أن ${text.toUpperCase()} هو *${percentages}%* ${command} ${emoji}\n> ✰ لا بأس في الاستمتاع بالجبن!`;
      } else if (percentages > 100) {
        description = `💖 أظهرت الحسابات أن ${text.toUpperCase()} هو *${percentages}%* ${command} ${emoji}\n> ✰ فأر فاخر حقيقي!`;
      } else {
        description = `👑 أظهرت الحسابات أن ${text.toUpperCase()} هو *${percentages}%* ${command} ${emoji}\n> ✰ تناول الجبن بمسؤولية!`;
      }
      break;
    case 'prostituto':
    case 'prostituta':
      emoji = '🫦👅';
      if (percentages < 50) {
        description = `❀ أظهرت الحسابات أن ${text.toUpperCase()} هو *${percentages}%* ${command} ${emoji}\n> ✰ السوق في ازدهار!`;
      } else if (percentages > 100) {
        description = `💖 أظهرت الحسابات أن ${text.toUpperCase()} هو *${percentages}%* ${command} ${emoji}\n> ✰ محترف حقيقي!`;
      } else {
        description = `✨️ أظهرت الحسابات أن ${text.toUpperCase()} هو *${percentages}%* ${command} ${emoji}\n> ✰ دائمًا وقت العمل!`;
      }
      break;
      default:
      m.reply(`🍭 أمر غير صالح.`);
  }
  const responses = [
    "لقد تحدث الكون.",
    "العلماء يؤكدون ذلك.",
    "مفاجأة!"
  ];
  const response = responses[Math.floor(Math.random() * responses.length)];
  const cal = `💫 *حاسبة السمات الشخصية*

${description}

➤ ${response}`.trim()  
  async function loading() {
var hawemod = [
"《 █▒▒▒▒▒▒▒▒▒▒▒》10%",
"《 ████▒▒▒▒▒▒▒▒》30%",
"《 ███████▒▒▒▒▒》50%",
"《 ██████████▒▒》80%",
"《 ████████████》100%"
]
   let { key } = await conn.sendMessage(m.chat, {text: `🤍 جاري حساب النسبة!`, mentions: conn.parseMention(cal)}, {quoted: fkontak})
 for (let i = 0; i < hawemod.length; i++) {
   await new Promise(resolve => setTimeout(resolve, 1000)); 
   await conn.sendMessage(m.chat, {text: hawemod[i], edit: key, mentions: conn.parseMention(cal)}, {quoted: fkontak}); 
  }
  await conn.sendMessage(m.chat, {text: cal, edit: key, mentions: conn.parseMention(cal)}, {quoted: fkontak});         
 }
loading()    
};
handler.help = ['gay <@علامة> | <اسم>', 'lesbiana <@علامة> | <اسم>', 'pajero <@علامة> | <اسم>', 'pajera <@علامة> | <اسم>', 'puto <@علامة> | <اسم>', 'puta <@علامة> | <اسم>', 'manco <@علامة> | <اسم>', 'manca <@علامة> | <اسم>', 'rata <@علامة> | <اسم>', 'prostituta <@علامة> | <اسم>', 'prostituto <@علامة> | <اسم>'];
handler.tags = ['مرح'];
handler.register = true;
handler.group = true;
handler.command = ['gay', 'lesbiana', 'pajero', 'pajera', 'puto', 'puta', 'manco', 'manca', 'rata', 'prostituta', 'prostituto'];

export default handler;