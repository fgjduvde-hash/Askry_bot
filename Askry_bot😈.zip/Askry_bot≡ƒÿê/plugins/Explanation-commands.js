let handler = async (m, { conn, text, usedPrefix, command }) => {
  if (!text) throw `🍬┇اكتب اسم الأمر الذي تريد شرحه\nمثال: ${usedPrefix}${command} ملصق`

  let plugin = Object.values(global.plugins).find(
    plugin =>
      plugin.help &&
      plugin.help.map(cmd => cmd.toLowerCase()).includes(text.toLowerCase())
  )

  if (!plugin) throw `❌ لم أتمكن من العثور على شرح لهذا الأمر: *${text}*`

  let info = `🍬┇*شرح الأمر: ${text}*\n\n`
  info += plugin.help ? `🧩 *الاستخدامات:*\n- ${plugin.help.join('\n- ')}\n\n` : ''
  info += plugin.tags ? `📁 *التصنيف:* ${plugin.tags.join(', ')}\n` : ''
  info += plugin.command ? `⚙️ *الأوامر المدعومة:*\n${Array.isArray(plugin.command) ? plugin.command.map(c => usedPrefix + c).join(', ') : usedPrefix + plugin.command}\n` : ''
  info += plugin.desc ? `\n📝 *الوصف:*\n${plugin.desc}` : ''

  await m.reply(info.trim())
}

handler.help = ['شرح <اسم_الأمر>']
handler.tags = ['info']
handler.command = /^شرح$/i

export default handler