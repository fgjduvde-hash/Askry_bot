let handler = async (m, { conn }) => {
  const imageURL = 'https://files.catbox.moe/sl1onr.jpg'

  let text = `
*✍️┇╾⪼ قسم الزخرفة والتنسيق*

> ⩺ ⌟.زخرفه [نص] — زخرفة عربية تلقائية  
> ⩺ ⌟.زخرفة_انجليزي [نص] — زخرفة إنجليزية  
> ⩺ ⌟.نص_مزخرف [نص] — توليد أشكال زخرفة  
> ⩺ ⌟.زخارف — عرض أنماط زخرفة  
> ⩺ ⌟.fancytext — توليد خطوط متنوعة  
> ⩺ ⌟.stylishname — زخرفة أسماء  
> ⩺ ⌟.زخرفة_سريعة [نص] — زخرفة سريعة وجاهزة  
> ⩺ ⌟.خطوط • .fonts — خطوط جاهزة  

*🎀┇لا تنسَ كتابة (.) قبل كل أمر لاستخدامه!*
`.trim()

  await conn.sendMessage(m.chat, {
    image: { url: imageURL },
    caption: text,
    mentions: [m.sender]
  }, { quoted: m })
}

handler.help = ['س7']
handler.tags = ['menu']
handler.command = /^س7$/i

export default handler