import fetch from 'node-fetch';

const handler = async (m, { conn, command, text, isAdmin }) => {
  if (command === 'mute') {
    if (!isAdmin) throw '🍬 *Solo un administrador puede ejecutar este comando*'; // فقط المسؤول يمكنه تنفيذ الأمر
    
    // رقم المالك (المطور)
    const ownerJid = global.owner[0][0] + '@s.whatsapp.net';
    
    // لا يمكن كتم المطور
    if (m.mentionedJid?.[0] === ownerJid) throw '🍬 *El creador del bot no puede ser mutado*';
    
    // تحديد المستخدم المستهدف (مذكور أو رد أو نص)
    let userToMute = m.mentionedJid?.[0] || m.quoted?.sender || text;
    
    if (userToMute === conn.user.jid) throw '🍭 *No puedes mutar el bot*'; // لا يمكن كتم البوت نفسه
    
    // الحصول على بيانات المجموعة
    const groupMetadata = await conn.groupMetadata(m.chat);
    const groupOwner = groupMetadata.owner || m.sender.split('-')[0] + '@s.whatsapp.net';
    
    if (m.mentionedJid?.[0] === groupOwner) throw '🍭 *No puedes mutar el creador del grupo*'; // لا يمكن كتم صاحب المجموعة
    
    // حالة المستخدم في قاعدة البيانات
    let userData = global.db.data.users[userToMute];
    
    if (userData.mute === true) throw '🍭 *Este usuario ya ha sido mutado*'; // المستخدم بالفعل مكتوم
    
    // إعداد الرسالة الخاصة بالرد
    const contactMessage = {
      key: { participants: "0@s.whatsapp.net", fromMe: false, id: "Halo" },
      message: {
        locationMessage: {
          name: "𝗨𝘀𝘂𝗮𝗿𝗶𝗼 𝗺𝘂𝘁𝗮𝗱𝗼",
          jpegThumbnail: await (await fetch('https://telegra.ph/file/f8324d9798fa2ed2317bc.png')).buffer(),
          vcard: `BEGIN:VCARD
VERSION:3.0
N:;Unlimited;;;
FN:Unlimited
ORG:Unlimited
TITLE:
item1.TEL;waid=19709001746:+1 (970) 900-1746
item1.X-ABLabel:Unlimited
X-WA-BIZ-DESCRIPTION:ofc
X-WA-BIZ-NAME:Unlimited
END:VCARD`
        }
      },
      participant: "0@s.whatsapp.net"
    };
    
    // تفعيل الكتم في قاعدة البيانات
    userData.mute = true;
    
    // إرسال رد
    conn.reply(m.chat, '*Tus mensajes serán eliminados*', contactMessage, null, { mentions: [userToMute] });
  } 
  else if (command === 'unmute') {
    if (!isAdmin) throw '🍬 *Solo un administrador puede ejecutar este comando*'; // فقط المسؤول يمكنه تنفيذ الأمر
    
    let userToUnmute = m.mentionedJid?.[0] || m.quoted?.sender || text;
    let userData = global.db.data.users[userToUnmute];
    
    if (userToUnmute === m.sender) throw '🍬 *Solo otro administrador puede desmutarte*'; // لا يمكن إلغاء الكتم لنفسه
    
    if (userData.mute === false) throw '🍭 *Este usuario no ha sido mutado*'; // المستخدم غير مكتوم أصلاً
    
    // إعداد الرسالة الخاصة بالرد عند فك الكتم
    const contactMessage = {
      key: { participants: "0@s.whatsapp.net", fromMe: false, id: "Halo" },
      message: {
        locationMessage: {
          name: "𝗨𝘀𝘂𝗮𝗿𝗶𝗼 𝗱𝗲𝗺𝘂𝘁𝗮𝗱𝗼",
          jpegThumbnail: await (await fetch('https://telegra.ph/file/aea704d0b242b8c41bf15.png')).buffer(),
          vcard: `BEGIN:VCARD
VERSION:3.0
N:;Unlimited;;;
FN:Unlimited
ORG:Unlimited
TITLE:
item1.TEL;waid=19709001746:+1 (970) 900-1746
item1.X-ABLabel:Unlimited
X-WA-BIZ-DESCRIPTION:ofc
X-WA-BIZ-NAME:Unlimited
END:VCARD`
        }
      },
      participant: "0@s.whatsapp.net"
    };
    
    // إلغاء الكتم في قاعدة البيانات
    userData.mute = false;
    
    // إرسال رد
    conn.reply(m.chat, '*Tus mensajes no serán eliminados*', contactMessage, null, { mentions: [userToUnmute] });
  }
};

handler.command = ['كتم', 'unmute'];
handler.admin = true;       // يحتاج أذونات مشرف (admin)
handler.botAdmin = true;    // يحتاج البوت أن يكون مشرف في المجموعة
handler.exp = 0;

export default handler;