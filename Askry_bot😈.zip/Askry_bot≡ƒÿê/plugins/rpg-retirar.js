import db from '../lib/database.js'

let المعالج = async (m, { args }) => {
  let المستخدم = global.db.data.users[m.sender]
  if (!args[0]) return m.reply(`${emoji} أدخل كمية *${عملة}* التي تريد سحبها.`)
  
  if (args[0] == 'all') {
    let الكمية = parseInt(المستخدم.bank)
    المستخدم.bank -= الكمية * 1
    المستخدم.coin += الكمية * 1
    await m.reply(`${emoji} سحبت *${الكمية} ${عملة}* من البنك، يمكنك الآن استخدامها لكن يمكن سرقتها منك.`)
    return !0
  }
  
  if (!Number(args[0])) return m.reply(`${emoji2} يجب أن تسحب كمية صالحة.\n > مثال 1 » *#retirar 25000*\n> مثال 2 » *#retirar all*`)
  
  let الكمية = parseInt(args[0])
  if (!المستخدم.bank) return m.reply(`${emoji2} ليس لديك ما يكفي من *${عملة}* في البنك.`)
  if (المستخدم.bank < الكمية) return m.reply(`${emoji2} لديك فقط *${المستخدم.bank} ${عملة}* في البنك.`)
  
  المستخدم.bank -= الكمية * 1
  المستخدم.coin += الكمية * 1
  await m.reply(`${emoji} سحبت *${الكمية} ${عملة}* من البنك، يمكنك الآن استخدامها لكن يمكن سرقتها منك.`)
}

المعالج.help = ['انسحاب']
المعالج.tags = ['rpg']
المعالج.command = ['انسحاب', 'retirar', 'with']
المعالج.group = true
المعالج.register = true

export default المعالج

