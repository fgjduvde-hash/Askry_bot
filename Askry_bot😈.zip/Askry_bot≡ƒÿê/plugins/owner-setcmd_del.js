const handler = async (m, {conn, usedPrefix, text, command}) => {
  let hash = text;
  if (m.quoted && m.quoted.fileSha256) hash = m.quoted.fileSha256.toString('hex');
  if (!hash) throw `${emoji} يمكن فقط حذف الأوامر أو النصوص المرتبطة بالملصقات أو الصور، للحصول على الكود المرتبط استخدم الأمر: ${usedPrefix}listcmd`;
  
  const sticker = global.db.data.sticker;
  if (sticker[hash] && sticker[hash].locked) throw `${emoji} فقط *المطوّر* يمكنه حذف هذا الأمر.`;

  delete sticker[hash];
  m.reply(`${emoji} تم حذف النص/الأمر المرتبط بالملصق أو الصورة من قاعدة البيانات بنجاح.`);
};

handler.command = ['ديل'];
handler.rowner = true;

export default handler;