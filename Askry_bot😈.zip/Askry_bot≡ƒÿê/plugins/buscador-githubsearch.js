/* بحث جيت هاب بواسطة WillZek 
- أكواد تيتان المجانية  
- https://whatsapp.com/channel/0029ValMlRS6buMFL9d0iQ0S
*/

// 𝗚𝗶𝘁𝗵𝘂𝗯 𝗦𝗲𝗮𝗿𝗰𝗵

import fetch from 'node-fetch';

let handler = async(m, { conn, text, usedPrefix, command }) => {

if (!text) return conn.reply(m.chat, `${emoji} من فضلك أدخل اسم مستودع جيت هاب.`, m);

try {
let api = `https://dark-core-api.vercel.app/api/search/github?key=api&text=${text}`;

let response = await fetch(api);
let json = await response.json();
let result = json.results[0];

let txt = `🍬 *الاسم:* ${result.name}\n👑 *المالك:* ${result.creator}\n🌟 *النجوم:* ${result.stars}\n🔖 *التفرعات:* ${result.forks}\n📜 *الوصف:* ${result.description}\n📆 *تاريخ الإنشاء:* ${result.createdAt}\n🔗 *الرابط:* ${result.cloneUrl}`;

let img = 'https://raw.githubusercontent.com/The-King-Destroy/Adiciones/main/Contenido/1745610598914.jpeg';

conn.sendMessage(m.chat, { image: { url: img }, caption: txt }, { quoted: fkontak });

} catch (error) {
console.error(error)
m.reply(`خطأ: ${error.message}`);
m.react('✖️');
 }
};

handler.command = ['githubsearch', 'gbsearch', 'بحثجيتهاب'];

export default handler;