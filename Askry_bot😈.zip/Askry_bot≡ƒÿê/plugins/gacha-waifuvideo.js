import { promises as fs } from 'fs'

const charactersFilePath = './src/database/characters.json'

async function loadCharacters() {
    try {
        const data = await fs.readFile(charactersFilePath, 'utf-8')
        return JSON.parse(data)
    } catch (error) {
        throw new Error('✘ فشل في تحميل ملف الشخصيات.')
    }
}

let handler = async (m, { conn, text, usedPrefix, command }) => {
    if (!text) {
        await conn.reply(m.chat, `📌 *الاستخدام:*\nاكتب اسم شخصية لعرض فيديو عشوائي لها.\n\nمثال:\n${usedPrefix + command} هيناتا`, m)
        return
    }

    const characterName = text.toLowerCase().trim()

    try {
        const characters = await loadCharacters()
        const character = characters.find(c => c.name.toLowerCase() === characterName)

        if (!character) {
            await conn.reply(m.chat, `✘ لم يتم العثور على الشخصية *${text}*.\nتحقق من صحة الاسم.`, m)
            return
        }

        if (!character.vid || character.vid.length === 0) {
            await conn.reply(m.chat, `✘ لا يوجد فيديوهات مسجلة للشخصية *${character.name}*.`, m)
            return
        }

        const randomVideo = character.vid[Math.floor(Math.random() * character.vid.length)]

        const caption = `🎀 *الاسم:* ${character.name}
⚥ *الجنس:* ${character.gender}
📚 *المصدر:* ${character.source}`

        const asGif = Math.random() < 0.5

        await conn.sendMessage(m.chat, {
            video: { url: randomVideo },
            caption,
            gifPlayback: asGif
        }, { quoted: m })

    } catch (err) {
        await conn.reply(m.chat, `✘ حدث خطأ أثناء عرض الفيديو:\n${err.message}`, m)
    }
}

handler.help = ['فيديو <اسم>']
handler.tags = ['انمي']
handler.command = ['فيديو', 'فيديو_وايفو', 'فيديوشخصية']
handler.group = true

export default handler