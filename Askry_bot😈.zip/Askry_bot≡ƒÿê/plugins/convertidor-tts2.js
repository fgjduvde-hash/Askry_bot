import axios from 'axios';
import fetch from 'node-fetch';

const handler = async (m, { conn, usedPrefix, command, text, args }) => {
  const [effect, ...textArray] = text.split(" ");
  const textToSpeak = textArray.join("");

  if (!effect) {
    let voiceList = await getVoiceList();
    let responseText = `${emoji} لم تقم بإدخال تأثير صوتي، الرجاء إدخال تأثير صوتي.\n\n*${emoji2} اختر أحد التأثيرات الصوتية التالية:*\n`;

    for (let i = 0, count = 0; count < 100 && i < voiceList.resultado.length; i++) {
      const entry = voiceList.resultado[i];
      if (entry.ID.length <= 20) {
        responseText += `*◉ ${usedPrefix + command} ${entry.ID} النص-الخاص-بك*\n`;
        count++;
      }
    }

    return conn.sendMessage(m.chat, { text: responseText.trim() }, { quoted: m });
  }

  let validEffect = false;
  let voiceList = await getVoiceList();
  for (const entry of voiceList.resultado) {
    if (entry.ID === effect) {
      validEffect = true;
      break;
    }
  }

  if (!validEffect) return conn.sendMessage(m.chat, { text: `${emoji2} التأثير الصوتي غير موجود في القائمة، استخدم ${usedPrefix + command} لرؤية قائمة التأثيرات.` }, { quoted: m });

  if (!textToSpeak) return conn.sendMessage(m.chat, {text: `${emoji} الرجاء إدخال النص الذي تريد تحويله إلى صوت.\n\n> *${emoji2} مثال: ${usedPrefix + command} ${effect} مرحبًا، هذا مثال لاستخدام الأمر.*`}, {quoted: m});

  let result = await makeTTSRequest(textToSpeak, effect);
  conn.sendMessage(m.chat, {audio: {url: result.resultado}, fileName: 'error.mp3', mimetype: 'audio/mpeg', ptt: true}, {quoted: m});
};

handler.command = ['tts2', 'صوت']
export default handler;

const secretKey = 'fe2ee40099494579af0ecf871b5af266';
const userId = 'SrgwcKcLzSY63IdsAxd1PzscFjL2';

async function getVoiceList() {
  const url = 'https://play.ht/api/v2/voices';
  const options = {
    method: 'GET',
    headers: {
      accept: 'application/json',
      AUTHORIZATION: `Bearer ${secretKey}`,
      'X-USER-ID': userId
    }
  };
  try {
    const response = await fetch(url, options);
    const responseData = await response.json(); 
    const uniqueData = responseData.reduce((acc, current) => {
      if (!acc.some(item => item.id === current.id)) {
        acc.push(current);
      }
      return acc;
    }, []);
    const simplifiedList = uniqueData.map(entry => ({
      ID: entry.id,
      name: entry.name,
      language: entry.language  
    }));
    return { resultado: simplifiedList ? simplifiedList : `${msm} خطأ، لم يتم الحصول على رد من API.` };
  } catch (error) {
    console.error('Error:', error);
    return { resultado: `${msm} خطأ، لم يتم الحصول على رد من API.` };
    throw error;
  }
}

async function makeTTSRequest(text, effect) {
  const requestData = {text: text, voice: effect};
  const headers = {
    'Authorization': `Bearer ${secretKey}`,
    'X-User-Id': userId,
    'accept': 'text/event-stream',
    'content-type': 'application/json'
  };
  try {
    const response = await axios.post('https://play.ht/api/v2/tts', requestData, { headers });
    const events = response.data.split('\r\n\r\n');
    const eventData = events.find(event => event.includes('"stage":"complete"'));
    const urlMatch = eventData.match(/"url":"([^"]+)"/);
    const url = urlMatch ? urlMatch[1] : null;
    return { resultado: url ? url : `${emoji2} لم يتم العثور على URL في الرد.` };
  } catch (error) {
    console.error('Error:', error);
    return { resultado: `${msm} خطأ، لم يتم الحصول على رد من API.` };
  }
}