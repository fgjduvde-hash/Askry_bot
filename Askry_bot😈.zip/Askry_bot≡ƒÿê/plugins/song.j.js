import axios from 'axios';
import {
    spawn
} from 'child_process';

let handler = async (m, {
    conn,
    text
}) => {
    if (!text) return m.reply('⌯ اكتب رابط أغنية Apple Music\nمثال: .applemusic https://music.apple.com/us/album/call-your-mom/1689703584?i=1689704028');

    try {
        const apiUrl = `https://emam-x-api.vercel.app/home/sections/Download/api/AppleMusic/download?url=${encodeURIComponent(text)}`;
        const {
            data: {
                data: songData
            }
        } = await axios.get(apiUrl);

        const caption = `
⌯ *العنوان:* ${songData.title}
⌯ *الفنان:* ${songData.artist_info.name}
⌯ *رابط الفنان:* ${songData.artist_info.url}
⌯ *الألبوم:* ${songData.album}
⌯ *رابط الألبوم:* ${songData.album_url}
⌯ *المدة:* ${songData.duration.text}
⌯ *تاريخ الإصدار:* ${songData.release_date}
⌯ *النوع:* ${songData.genre.join(', ')}
⌯ *رقم الاغنيه:* ${songData.track_number}
⌯ *رقم القرص :* ${songData.disc_number}
⌯ *الوصف:* ${songData.description}
⌯ *رابط الأغنية:* ${songData.url}
        `.trim();

        await conn.sendMessage(m.chat, {
            image: {
                url: songData.album_image
            },
            caption: caption
        }, {
            quoted: m
        });

        const audioResponse = await axios.get(songData.song_url, {
            responseType: 'arraybuffer'
        });
        const m4aBuffer = Buffer.from(audioResponse.data);

        const mp3Buffer = await new Promise((resolve, reject) => {
            const ffmpeg = spawn('ffmpeg', [
                '-i', 'pipe:0',
                '-f', 'mp3',
                '-vn',
                '-ab', '320k',
                '-ar', '48000',
                'pipe:1'
            ]);

            const chunks = [];
            ffmpeg.stdout.on('data', (chunk) => chunks.push(chunk));
            ffmpeg.on('close', (code) => code === 0 ? resolve(Buffer.concat(chunks)) : reject(new Error('FFmpeg conversion failed')));
            ffmpeg.stdin.write(m4aBuffer);
            ffmpeg.stdin.end();
        });

        await conn.sendMessage(m.chat, {
            audio: mp3Buffer,
            mimetype: 'audio/mpeg'
        }, {
            quoted: m
        });

    } catch (error) {
        m.reply('⌯ حدث خطأ أثناء جلب الأغنية');
    }
};

handler.help = ['applemusic'];
handler.tags = ['downloader'];
handler.command = ['applemusic', 'اغنيه'];

export default handler;