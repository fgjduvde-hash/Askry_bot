var handler = async (m, { conn }) => {
  let عملات = Math.floor(Math.random() * (500 - 100 + 1)) + 100;
  let خبرة = Math.floor(Math.random() * (500 - 100 + 1)) + 100;
  let ماسات = Math.floor(Math.random() * (500 - 100 + 1)) + 100;

  global.db.data.users[m.sender].diamond += ماسات;
  global.db.data.users[m.sender].coin += عملات;

  let وقت_المطالبة = global.db.data.users[m.sender].lastclaim + 86400000;
  if (new Date() - global.db.data.users[m.sender].lastclaim < 7200000) {
    return conn.reply(m.chat, `${emoji4} *عد إلى هنا بعد ${msToTime(وقت_المطالبة - new Date())}*`, m);
  }

  global.db.data.users[m.sender].exp += خبرة;
  conn.reply(m.chat, `${emoji} *المكافأة اليومية*

الموارد:
✨ خبرة : *+${خبرة}*
💎 ماسات : *+${ماسات}*
💸 ${moneda} : *+${عملات}*`, m);

  global.db.data.users[m.sender].lastclaim = Date.now();
}

handler.help = ['يومي', 'مطالبة'];
handler.tags = ['rpg'];
handler.command = ['daily', 'diario'];
handler.group = true;
handler.register = true;

export default handler;

function msToTime(duration) {
  var milliseconds = parseInt((duration % 1000) / 100),
    seconds = Math.floor((duration / 1000) % 60),
    minutes = Math.floor((duration / (1000 * 60)) % 60),
    hours = Math.floor((duration / (1000 * 60 * 60)) % 24);

  hours = (hours < 10) ? '0' + hours : hours;
  minutes = (minutes < 10) ? '0' + minutes : minutes;
  seconds = (seconds < 10) ? '0' + seconds : seconds;

  return hours + ' ساعات ' + minutes + ' دقائق';
}

