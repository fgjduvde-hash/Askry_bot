const handler = async (m, { conn, args, groupMetadata, participants, usedPrefix, command, isBotAdmin, isSuperAdmin }) => {
  if (!args[0]) return conn.reply(m.chat, `${emoji} الرجاء إدخال مفتاح دولة للمتابعة.`, m);
  if (isNaN(args[0])) return conn.reply(m.chat, `${emoji} الرجاء إدخال مفتاح دولة صحيح.\nمثال: ${usedPrefix + command} 212`, m);

  const prefix = args[0].replace(/[+]/g, '');
  const المطابقين = participants.map(u => u.id).filter(v => v !== conn.user.jid && v.startsWith(prefix || prefix));
  const bot = global.db.data.settings[conn.user.jid] || {};

  if (المطابقين == '') return m.reply(`${emoji2} لا يوجد أي رقم في هذا المجموعة يبدأ بالمفتاح +${prefix}`);

  const الأرقام = المطابقين.map(v => '⭔ @' + v.replace(/@.+/, ''));
  const انتظار = (ms) => new Promise(res => setTimeout(res, ms));

  switch (command) {
    case 'listanum':
    case 'listnum':
      conn.reply(m.chat, `${emoji} قائمة الأرقام التي تبدأ بالمفتاح +${prefix} في هذه المجموعة:\n\n` + الأرقام.join`\n`, m, { mentions: المطابقين });
      break;

    case 'kicknum':
      if (!bot.restrict) return conn.reply(m.chat, `${emoji} هذا الأمر معطّل من قبل مالك البوت.`, m);
      if (!isBotAdmin) return m.reply(`${emoji2} يجب أن يكون البوت مشرفًا لاستخدام هذا الأمر.`, m);

      await conn.reply(m.chat, `♻️ جاري بدء الطرد...`, m);

      const مالك_القروب = m.chat.split`-`[0] + '@s.whatsapp.net';
      const المستخدمين = participants.map(u => u.id).filter(v => v !== conn.user.jid && v.startsWith(prefix || prefix));

      for (const user of المستخدمين) {
        const خطأ = `@${user.split('@')[0]} تم طرده مسبقًا أو غادر المجموعة...`;

        if (user !== مالك_القروب + '@s.whatsapp.net' && user !== global.conn.user.jid && user !== global.owner + '@s.whatsapp.net' && user.startsWith(prefix || prefix) && user !== isSuperAdmin && isBotAdmin && bot.restrict) {
          await انتظار(2000);
          const نتيجة = await conn.groupParticipantsUpdate(m.chat, [user], 'remove');
          if (نتيجة[0].status === '404') m.reply(خطأ, m.chat, { mentions: conn.parseMention(خطأ) });
          await انتظار(10000);
        } else return m.reply(m.chat, `${msm} حدث خطأ.`, m);
      }
      break;
  }
};

handler.command = ['عنصريه', 'listnum', 'listanum'];
handler.group = true;
handler.botAdmin = true;
handler.admin = true;
handler.fail = null;

export default handler;