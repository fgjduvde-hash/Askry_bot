let handler = async (m, { conn, text, usedPrefix, command }) => {
  if (!text) return conn.reply(m.chat, `${emoji} من فضلك أدخل الخطأ الذي تريد الإبلاغ عنه.`, m)
  if (text.length < 10) return conn.reply(m.chat, `${emoji} يرجى توضيح الخطأ بشكل جيد، الحد الأدنى 10 حروف.`, m)
  if (text.length > 1000) return conn.reply(m.chat, `${emoji2} *الحد الأقصى 1000 حرف لإرسال البلاغ.`, m)

  const teks = `*✖️ \`تقرير\` ✖️*

☁️ الرقم:
• Wa.me/${m.sender.split`@`[0]}

👤 المستخدم: 
• ${m.pushName || 'مجهول'}

💬 الرسالة:
• ${text}`

  await conn.reply(`${suittag}@s.whatsapp.net`, m.quoted ? teks + m.quoted.text : teks, m, { mentions: conn.parseMention(teks) })

  m.reply(`${emoji} تم إرسال التقرير إلى المطور الخاص بي، أي بلاغ كاذب قد يؤدي إلى الحظر.`)
}

handler.help = ['reportar']
handler.tags = ['info']
handler.command = ['ابلاغ', 'report', 'reportar', 'bug', 'error']

export default handler