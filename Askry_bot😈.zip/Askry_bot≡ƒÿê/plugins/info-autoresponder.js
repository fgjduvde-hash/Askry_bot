let handler = async (m, { conn, text, usedPrefix, command, isOwner, isAdmin, isROwner }) => {
  if (!(isOwner || isAdmin || isROwner)) {
    conn.reply(m.chat, `${emoji2} عذرًا، لا يمكنك تخصيص الرد التلقائي في هذا القروب/الدردشة.`, m);
  }

  const chatData = global.db.data.chats[m.chat];

  if (text) {
    if (chatData.sAutoresponder) return conn.reply(m.chat, `${emoji} يوجد بالفعل رد تلقائي مفعل، إذا كنت تريد ضبط رد جديد فاستخدم الأمر بدون نص.`, m);

    chatData.sAutoresponder = text;
    conn.reply(m.chat, `${emoji} تم الحفظ بنجاح.\n\n${emoji2} إذا كان الرد التلقائي غير مفعل، يمكنك تفعيله باستخدام:\n> » *${usedPrefix}autoresponder*`, m);
  } else {
    if (chatData.sAutoresponder) {
      chatData.sAutoresponder = '';
      conn.reply(m.chat, "🗑️ تم حذف الرد التلقائي بنجاح.", m);
    } else {
      conn.reply(m.chat, `${emoji2} لا يوجد رد تلقائي مخصص في هذه الدردشة.\n\n${emoji} يمكنك تخصيص الرد التلقائي باستخدام:\n> » *${usedPrefix + command} + النص الذي تريده أن يتفاعل معه.*`, m);
    }
  }
}

handler.tags = ['info'];
handler.help = ['editautoresponder'];
handler.command = ['editautoresponder', 'autoresponder2'];

export default handler;