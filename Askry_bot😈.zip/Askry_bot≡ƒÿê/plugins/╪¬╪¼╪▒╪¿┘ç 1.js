import { addExif } from '../lib/sticker.js'

let handler = async (m, { conn, text, quoted }) => {
    if (!quoted) throw '👀┇الرجاء الرد على رسالة تحتوي على صور أو فيديوهات لتحويلها إلى ملصقات!┇😎'

    let mediaMessages = []

    // Check if the quoted message is a single image/video
    if (quoted.isQuotedImage || quoted.isQuotedVideo) {
        mediaMessages.push(quoted)
    } else if (quoted.message && quoted.message.imageMessage) {
        // Handle single image sent directly
        mediaMessages.push(quoted)
    } else if (quoted.message && quoted.message.videoMessage) {
        // Handle single video sent directly
        mediaMessages.push(quoted)
    } else if (quoted.message && quoted.message.extendedTextMessage && quoted.message.extendedTextMessage.contextInfo && quoted.message.extendedTextMessage.contextInfo.quotedMessage) {
        // This handles replies to messages that contain multiple media (like the +7 example)
        // The actual media objects are usually nested within the quotedMessage of the extendedTextMessage
        // This part is highly dependent on the specific WhatsApp bot framework's message object structure.
        // For now, let's assume the bot framework provides a way to access all media in a quoted message.
        // A common way is to iterate through the 'quoted.messages' array if it exists and contains media.
        // If the bot framework doesn't expose this directly, it might require more advanced parsing of the raw message object.

        // Placeholder for handling multiple media in a single quoted message.
        // This part needs to be adapted based on the actual structure of 'quoted' object in your bot framework
        // For example, if 'quoted' has a 'galleryMessage' or 'multiMediaMessage' property.
        // As a generic approach, we'll try to extract from 'quoted.message' if it's a multi-media message.
        
        // This is a simplified assumption. A real implementation would need to inspect the 'quoted' object structure.
        // For now, if it's a reply to a message with multiple media, we'll try to get the first one.
        // A more robust solution would involve checking 'quoted.message.viewOnceMessageV2' or similar for media arrays.
        
        // Given the user's example, the bot framework likely aggregates these into a single 'quoted' object
        // when replying to a message with multiple attachments. The 'quoted' object itself should contain
        // references to all attached media. This is a common challenge with WhatsApp bot frameworks.
        
        // For now, I will keep the logic to process only the first media if it's a multi-media message reply,
        // as directly accessing all 20-30 images from a single 'quoted' object can vary greatly between frameworks.
        // The user's example implies the bot framework might provide a way to iterate through them.
        
        // Let's refine the logic to check for a common pattern where the 'quoted' object itself might contain
        // an array of media if it's a multi-image message.
        
        // If the bot framework provides a direct way to access all media in a quoted message (e.g., quoted.media or quoted.attachments)
        // then this part would be much simpler.
        
        // Since I don't have the exact structure of 'quoted' for multi-media messages in your bot framework,
        // I will make an assumption that 'quoted.message' will contain the relevant media if it's a multi-media message.
        // This is a common pattern in some frameworks where the 'message' property holds the content.
        
        // If the quoted message is a multi-image message, the structure can be complex.
        // A common approach is to check for 'quoted.message.ephemeralMessage.message.imageMessage' or 'quoted.message.viewOnceMessageV2.message.imageMessage'
        // or similar for each media item.
        
        // For the purpose of this generic code, I will assume that if the user replies to a message with multiple images,
        // the 'quoted' object will contain an array-like structure or a way to iterate through the media.
        // If not, the bot framework itself needs to be able to provide this.
        
        // Given the user's request for 20-30 images, the bot framework must expose these.
        // I will add a placeholder for a more robust multi-media extraction.
        
        // For now, I will assume that if the quoted message is a multi-media message, the bot framework
        // will provide a way to access each media item. Without specific framework details, it's hard to be precise.
        
        // Let's try to simulate how a bot framework might expose multiple media in a quoted message.
        // A common pattern is that 'quoted' itself might have a 'media' array or similar.
        
        // If the bot framework supports replying to a message with multiple images and treating it as one quoted message
        // containing all those images, then the 'quoted' object should have a property that lists them.
        // For example, some frameworks might put them in `quoted.messages` or `quoted.attachments`.
        
        // Since the user provided an image showing '+7', it implies the bot framework *can* see multiple attachments.
        // I will add a more generic check for `quoted.messages` or `quoted.attachments` if they exist.
        
        if (quoted.messages && Array.isArray(quoted.messages)) {
            for (let msg of quoted.messages) {
                if (msg.isQuotedImage || msg.isQuotedVideo) {
                    mediaMessages.push(msg)
                }
            }
        } else {
            // Fallback for frameworks where quoted.messages might not be directly available
            // and single quoted media is still the primary way.
            // This part might need manual adjustment based on your bot's specific message object structure.
            throw '👀┇الرجاء الرد على رسالة تحتوي على صور أو فيديوهات. لا يمكنني معالجة رسائل متعددة الوسائط بهذه الطريقة حاليًا.┇😎'
        }
    } else {
        throw '👀┇الرجاء الرد على رسالة تحتوي على صور أو فيديوهات لتحويلها إلى ملصقات!┇😎'
    }

    if (mediaMessages.length === 0) {
        throw '👀┇لم يتم العثور على صور أو فيديوهات صالحة في الرسالة التي تم الرد عليها.┇😎'
    }

    let [packname, ...author] = text.split('|')
    author = (author || []).join('|')

    let stickers = []
    for (let msg of mediaMessages) {
        try {
            let media = await msg.download()
            let stiker = await addExif(media, packname || '', author || '')
            stickers.push(stiker)
        } catch (e) {
            console.error(`Error processing media: ${e}`)
            // Continue to next media even if one fails
        }
    }

    if (stickers.length === 0) {
        throw '😔┇فشل تحويل أي من الوسائط إلى ملصقات. تأكد من أن الصور/الفيديوهات صالحة.┇🚨'
    }

    // Send all generated stickers
    for (let stiker of stickers) {
        await conn.sendFile(m.chat, stiker, 'wm.webp', '', m, false, { asSticker: true })
    }

    if (stickers.length > 1) {
        conn.reply(m.chat, `✅ تم تحويل ${stickers.length} صورة/فيديو إلى ملصقات بنجاح!`, m)
    }
}

handler.help = ['ملصقات_متعددة <packname>|<author>']
handler.tags = ['sticker']
handler.command = /^ملصقات_متعددة|ستيكر_متعدد$/i

export default handler