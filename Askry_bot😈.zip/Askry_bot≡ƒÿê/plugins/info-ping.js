// plugins/main/ping.js
// ╔════════════════════════════════════════════════════════════════╗
// ║  💀 ASKRY-BOT - PING & SPEED - HACKER EDITION 💀              ║
// ║  Author: Al Askry | Telegram: @askry47 | © 2026               ║
// ╚════════════════════════════════════════════════════════════════╝

import speed from 'performance-now'
import { exec } from 'child_process'

let handler = async (m, { conn, usedPrefix, command }) => {
  
  // 💀 ثيم الهاكر الفاخر
  const skull = '💀'
  const flash = '⚡'
  const system = '🖥️'
  const time = '⏱️'
  const dev = '👑'
  const channel = '📡'
  
  // زخرفة الحدود
  let z1 = '╭━━━━━━━━━━━━━━━⊰💀⊱━━━━━━━━━━━━━━━╮'
  let z2 = '┃'
  let z3 = '╰━━━━━━━━━━━━━━━⊰💀⊱━━━━━━━━━━━━━━━╯'
  let z4 = '═'.repeat(35)
  let z5 = '─'.repeat(33)

  // حساب السرعة
  let timestamp = speed()
  let latensi = speed() - timestamp
  let pingValue = latensi.toFixed(4)

  // جلب معلومات النظام (neofetch)
  exec(`neofetch --stdout`, (error, stdout, stderr) => {
    let child = stdout.toString("utf-8")
    let ssd = child ? child.replace(/Memory:/, "رام:") : "غير متاح"

    let text = `
${z1}
${z2} ${' '.repeat(28)} ${z2}
${z2}   💀 𝐀𝐒𝐊𝐑𝐘-𝐁𝐎𝐓 💀   ${z2}
${z2}   ${'𝐒𝐏𝐄𝐄𝐃 𝐓𝐄𝐒𝐓'}   ${z2}
${z2} ${' '.repeat(28)} ${z2}
${z3}

${z2} ${flash} ${' '.repeat(4)} *سـرعة الـبـوت* ${' '.repeat(4)} ${flash} ${z2}
${z2} ${z4} ${z2}
${z2} ⚡ *الـبـيـنـغ:* ${' '.repeat(16)} ${pingValue} ms ${z2}
${z2} 🟢 *الـحـالـة:* ${' '.repeat(15)} مستقر ✅ ${z2}
${z2} ${z5} ${z2}

${z2} ${system} ${' '.repeat(3)} *مـعـلـومـات الـسـيـرفـر* ${' '.repeat(3)} ${system} ${z2}
${z2} ${z4} ${z2}
${z2} 🖥️ *نـظـام الـتـشـغـيـل:* ${' '.repeat(6)} Linux/Ubuntu ${z2}
${z2} 💾 *الـذاكـرة (RAM):* ${' '.repeat(9)} ${ssd.split('\n')[6] || 'Unknown'} ${z2}
${z2} ${z5} ${z2}

${z2} ${dev} ${' '.repeat(4)} *مـعـلـومـات الـمـطـور* ${' '.repeat(4)} ${dev} ${z2}
${z2} ${z4} ${z2}
${z2} 👑 المطور: Al Askry | عسكري 👑 ${z2}
${z2} 📡 تليجرام: @askry47 ${z2}
${z2} ${z5} ${z2}

${z2} ${channel} ${' '.repeat(5)} *قـنـاة آلَبـوت* ${' '.repeat(5)} ${channel} ${z2}
${z2} ${z4} ${z2}
${z2} 🔗 https://whatsapp.com/channel/0029Vb6z6NO545v2nTgoBa3I ${z2}
${z2} ${z5} ${z2}

${z2} ✅ *البوت يعمل بسرعة فائقة* ✅ ${z2}
${z2} ${' '.repeat(28)} ${z2}
${z3}

${z2} 💀 © 2026 Al Askry - All Rights Reserved 💀 ${z2}
${z1}
`.trim()

    conn.reply(m.chat, text, m, { contextInfo: {
      forwardingScore: 999,
      isForwarded: true,
      forwardedNewsletterMessageInfo: {
        newsletterJid: '120363403628890197@newsletter',
        newsletterName: 'ASKRY-BOT Official',
        serverMessageId: -1
      }
    }})
  })
}

// 💀 إعدادات الأمر
handler.help = ['ping', 'تست', 'فحص', 'speed', 'بينق']
handler.tags = ['info', 'askry', 'main']
handler.command = ['بينق', 'p', 'ping', 'تست', 'فحص', 'speed', 'سرعة', 'alive']
handler.register = false
handler.limit = false

// 💀 ASKRY-BOT © 2026 Al Askry - All Rights Reserved
export default handler