import Jimp from 'jimp';

let handler = async (m, { conn }) => {
  if (!m.quoted) return conn.reply(m.chat, `${emoji} من فضلك، قم بالرد على صورة لتعيينها كصورة للملف الشخصي.`, m);

  try {
    const media = await m.quoted.download();
    if (!media) return conn.reply(m.chat, `${emoji2} لم يتمكن من الحصول على الصورة.`, m);

    const image = await Jimp.read(media);
    const buffer = await image.getBufferAsync(Jimp.MIME_JPEG);

    await conn.updateProfilePicture(conn.user.jid, buffer);
    return conn.reply(m.chat, `${emoji} تم تغيير صورة الملف الشخصي بنجاح.`, m);
  } catch (e) {
    console.error(e);
    return conn.reply(m.chat, `${msm} حدث خطأ أثناء محاولة تغيير صورة الملف الشخصي.`, m);
  }
};

handler.help = ['حط'];
handler.tags = ['owner'];
handler.command = ['حط', 'setimage'];
handler.rowner = true;

export default handler;