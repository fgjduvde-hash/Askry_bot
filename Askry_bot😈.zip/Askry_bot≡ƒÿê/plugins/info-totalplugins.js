let handler = async (m, { conn }) => {
  let totalf = Object.values(global.plugins).filter(
    (v) => v.help && v.tags
  ).length;
  conn.reply(m.chat, `${emoji} إجمالي الوظائف : ${totalf}`, m);
}

handler.help = ['totalfunciones'];
handler.tags = ['main'];
handler.command = ['اجمالي الوظائف', 'comandos', 'funciones'];
handler.register = true;

export default handler;