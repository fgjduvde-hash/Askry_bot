import { promises as fs } from 'fs';

const مسار_الشخصيات = './src/database/characters.json';
const مسار_الحريم = './src/database/harem.json';

async function تحميل_الشخصيات() {
    try {
        const data = await fs.readFile(مسار_الشخصيات, 'utf-8');
        return JSON.parse(data);
    } catch (error) {
        throw new Error('✘ فشل في تحميل ملف الشخصيات.');
    }
}

async function تحميل_الحريم() {
    try {
        const data = await fs.readFile(مسار_الحريم, 'utf-8');
        return JSON.parse(data);
    } catch (error) {
        return [];
    }
}

let handler = async (m, { conn, args }) => {
    if (args.length === 0) {
        await conn.reply(m.chat, '📌 يجب كتابة اسم الشخصية لعرض معلوماتها.\nمثال » *#معلومة Aika Sano*', m);
        return;
    }

    const اسم_الشخصية = args.join(' ').toLowerCase().trim();

    try {
        const الشخصيات = await تحميل_الشخصيات();
        const الشخصية = الشخصيات.find(c => c.name.toLowerCase() === اسم_الشخصية);

        if (!الشخصية) {
            await conn.reply(m.chat, `✘ لم يتم العثور على الشخصية *${اسم_الشخصية}*.`, m);
            return;
        }

        const الحريم = await تحميل_الحريم();
        const دخول_المستخدم = الحريم.find(entry => entry.characterId === الشخصية.id);
        const الحالة = دخول_المستخدم 
            ? `مملوكة من قبل @${دخول_المستخدم.userId.split('@')[0]}` 
            : 'غير مملوكة';

        const الرسالة = `🎀 *الاسم:* ${الشخصية.name}
⚥ *الجنس:* ${الشخصية.gender}
💰 *القيمة:* ${الشخصية.value}
💞 *الحالة:* ${الحالة}
📚 *المصدر:* ${الشخصية.source}`;

        await conn.reply(m.chat, الرسالة, m, { mentions: [دخول_المستخدم ? دخول_المستخدم.userId : null] });
    } catch (error) {
        await conn.reply(m.chat, `✘ حدث خطأ أثناء تحميل معلومات الشخصية:\n${error.message}`, m);
    }
};

handler.help = ['معلومة <اسم الشخصية>'];
handler.tags = ['انمي'];
handler.command = ['معلومة', 'معلومات_وايفو', 'معلوماتشخصية'];
handler.group = true;
handler.register = true;

export default handler;