let handler = async (m, { conn }) => {
  const imageURL = 'https://files.catbox.moe/ajhr5i.jpg'

  let text = `
*🧮┇╾⪼ قسم حل المسائل الرياضية*

> ⩺ ⌟.حل [معادلة] — حل معادلة رياضية  
> ⩺ ⌟.math • .matematik — حل رياضي مباشر  
> ⩺ ⌟.calculator — آلة حاسبة ذكية  
> ⩺ ⌟.integrate — التكامل الرياضي  
> ⩺ ⌟.derive — الاشتقاق  
> ⩺ ⌟.factor — تحليل عوامل  
> ⩺ ⌟.simplify — تبسيط تعبير رياضي  
> ⩺ ⌟.convertunit — تحويل وحدة  
> ⩺ ⌟.matrix — حساب المصفوفات  
> ⩺ ⌟.graph — رسم دوال  

*🎀┇لا تنسَ كتابة (.) قبل كل أمر لاستخدامه!*
*ملاحظة: لازلنا نعمل على هاذا القسم*

`.trim()

  await conn.sendMessage(m.chat, {
    image: { url: imageURL },
    caption: text,
    mentions: [m.sender]
  }, { quoted: m })
}

handler.help = ['س8']
handler.tags = ['menu']
handler.command = /^س8$/i

export default handler