let cooldowns = {}

let handler = async (m, { conn, text, command, usedPrefix }) => {
  let users = global.db.data.users[m.sender]

  let tiempoEspera = 10

  if (cooldowns[m.sender] && Date.now() - cooldowns[m.sender] < tiempoEspera * 1000) {
    let tiempoRestante = segundosAHMS(Math.ceil((cooldowns[m.sender] + tiempoEspera * 1000 - Date.now()) / 1000))
    conn.reply(m.chat, `${emoji3} لقد قمت بالمراهنة مؤخرًا، يرجى الانتظار *⏱ ${tiempoRestante}* قبل المراهنة مرة أخرى.`, m)
    return
  }

  cooldowns[m.sender] = Date.now()

  if (!text) return conn.reply(m.chat, `${emoji} يجب أن تدخل كمية *💸 ${moneda}* ولونًا للمراهنة، مثل: *${usedPrefix + command} 20 black*`, m)

  let args = text.trim().split(" ")
  if (args.length !== 2) return conn.reply(m.chat, `${emoji2} تنسيق غير صحيح. يجب كتابة كمية *💸 ${moneda}* ولون، مثل: *${usedPrefix + command} 20 black*`, m)

  let coin = parseInt(args[0])
  let color = args[1].toLowerCase()

  if (isNaN(coin) || coin <= 0) return conn.reply(m.chat, `${emoji} الرجاء إدخال كمية صالحة للمراهنة.`, m)

  if (coin > 10000) return conn.reply(m.chat, `${emoji} الحد الأقصى للمراهنة هو 50 *${moneda}*.`, m)

  if (!(color === 'black' || color === 'red')) return conn.reply(m.chat, `${emoji2} يجب أن تراهن على لون صالح: *black* أو *red*.`, m)

  if (coin > users.coin) return conn.reply(m.chat, `${emoji2} ليس لديك ما يكفي من *${moneda}* لإجراء هذه المراهنة.`, m)

  await conn.reply(m.chat, `${emoji} راهنت بـ ${coin} *💸 ${moneda}* على اللون ${color}. انتظر *⏱ 10 ثوانٍ* لمعرفة النتيجة...`, m)

  setTimeout(() => {
    let result = Math.random()
    let win = false

    if (result < 0.5) {
      win = color === 'black'
    } else {
      win = color === 'red'
    }

    if (win) {
      users.coin += coin
      conn.reply(m.chat, `${emoji} فزت! حصلت على ${coin} *💸 ${moneda}*. المجموع: ${users.coin} *${moneda}*.`, m)
    } else {
      users.coin -= coin
      conn.reply(m.chat, `${emoji2} خسرت. تم خصم ${coin} *💸 ${moneda}*. المجموع: ${users.coin} *${moneda}*.`, m)
    }

  }, 10000)
}

handler.tags = ['اقتصاد']
handler.help = ['روليت *<الكمية> <اللون>*']
handler.command = ['روليت', 'roulette', 'rt']
handler.register = true
handler.group = true 

export default handler

function segundosAHMS(segundos) {
  let segundosRestantes = segundos % 60
  return `${segundosRestantes} ثانية`
}