/* 
- تعيين الإيموجي بواسطة Angel-OFC
- قم بتعديل منشن الكل باستخدام إيموجيك المفضل
- https://whatsapp.com/channel/0029VaJxgcB0bIdvuOwKTM2Y
*/
let handler = async (m, { conn, text, isRowner }) => {

  if (!text) {
    return m.reply(`${emoji} يجب عليك تقديم إيموجي صالح بعد الأمر. مثال: .setemoji ${emoji2}`);
  }

  const emoji = text.trim();

  if (!isEmoji(emoji)) {
    return m.reply(`${emoji} النص المُدخل ليس إيموجيًا صالحًا. تأكد من أنه إيموجي حقيقي.`);
  }

  try {
    global.db.data.chats[m.chat].customEmoji = emoji;

    m.reply(`${emoji2} تم تحديث إيموجي المجموعة بنجاح إلى: ${emoji}`);
  } catch (error) {
    console.error(error);
    m.reply(`${msm} حدث خطأ أثناء محاولة تغيير الإيموجي.`);
  }
};

const isEmoji = (text) => {
  const emojiRegex =
    /(?:\p{Emoji_Presentation}|\p{Extended_Pictographic}|\p{Emoji})/gu;
  return emojiRegex.test(text) && text.length <= 2;
};

handler.help = ['setemoji *<إيموجي>*'];
handler.tags = ['group'];
handler.command = ['setemoji', 'setemo'];
handler.admin = true;
handler.group = true;

export default handler;