let handler = async (m, { conn, text, isRowner }) => {
  if (!text) return m.reply(`${emoji} من فضلك، أدخل اسمًا للعملة الخاصة بالبوت.\n> مثال: #setmoneda عملات`);

  global.moneda = text.trim();
  
  m.reply(`${emoji} تم تغيير اسم عملة البوت إلى: ${global.moneda}`);
};

handler.help = ['عملة'];
handler.tags = ['tools'];
handler.command = ['عملة'];
handler.rowner = true;

export default handler;