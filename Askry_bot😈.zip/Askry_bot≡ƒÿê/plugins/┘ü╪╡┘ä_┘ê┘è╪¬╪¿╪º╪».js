import fetch from 'node-fetch';

function isChapterUrl(url) {
  return /\d{7,}-.+/.test(url);
}

let handler = async (m, { conn, text, command }) => {
  if (!text) return conn.reply(m.chat, `❌ الرجاء إرسال رابط فصل بعد الأمر.`, m);

  if (command === 'فصل') {
    if (!isChapterUrl(text))
      return conn.reply(m.chat, '❌ هذا رابط رواية وليس رابط فصل. استخدم أمر ".فصل" مع رابط الفصل.', m);

    try {
      const res = await fetch(`https://emam-x-api.vercel.app/home/sections/Search/api/Wattpad/chapter?url=${encodeURIComponent(text)}`);
      const json = await res.json();

      console.log('استجابة API للفصل:', JSON.stringify(json, null, 2));

      const title = json.title || '📖 فصل بدون عنوان';
      const content = json.text || json.story?.text || json.content || json.chapterText;

      if (!content) return conn.reply(m.chat, '❌ لا يوجد محتوى لهذا الفصل.', m);

      const trimmed = `${title}\n\n${content}`.slice(0, 4000);
      return conn.reply(m.chat, trimmed, m);
    } catch (e) {
      console.error(e);
      return conn.reply(m.chat, '❌ حدث خطأ أثناء جلب الفصل.', m);
    }
  }
};

handler.command = ['فصل'];
handler.help = ['فصل <رابط_فصل>'];
handler.tags = ['كتب'];

export default handler;