import fetch from 'node-fetch';

var handler = async (m, { conn, args, usedPrefix, command }) => {
    if (!args[0]) {
        return conn.reply(m.chat, `${emoji} من فضلك أدخل رابط فيديو تيك توك.`, m);
    }

    try {
        await conn.reply(m.chat, `${emoji} انتظر لحظة، جاري تحميل الفيديو...`, m);

        const tiktokData = await tiktokdl(args[0]);

        if (!tiktokData || !tiktokData.data || !tiktokData.data.play) {
            return conn.reply(m.chat, "خطأ: تعذر الحصول على الفيديو.", m);
        }

        const videoURL = tiktokData.data.play;

        if (videoURL) {
            await conn.sendFile(m.chat, videoURL, "tiktok.mp4", `${emoji} هذا هو الفيديو الخاص بك ฅ^•ﻌ•^ฅ`, m);
        } else {
            return conn.reply(m.chat, "تعذر التحميل.", m);
        }
    } catch (error1) {
        return conn.reply(m.chat, `خطأ: ${error1.message}`, m);
    }
};

handler.help = ['tiktok'].map((v) => v + ' *<رابط>*');
handler.tags = ['تحميلات'];
handler.command = ['tiktok', 'tt', 'تيكتوك'];
handler.group = true;
handler.register = true;
handler.coin = 2;
handler.limit = true;

export default handler;

async function tiktokdl(url) {
    let tikwm = `https://www.tikwm.com/api/?url=${url}?hd=1`;
    let response = await (await fetch(tikwm)).json();
    return response;
}