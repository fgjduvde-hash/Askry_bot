import { createHash } from 'crypto' 
import fetch from 'node-fetch'

const handler = async (m, { conn, usedPrefix, command, args, isOwner, isAdmin, isROwner }) => {
  let chat = global.db.data.chats[m.chat]
  let user = global.db.data.users[m.sender]
  let bot = global.db.data.settings[conn.user.jid] || {}
  let type = command.toLowerCase()
  let isAll = false, isUser = false
  let isEnable = chat[type] || false

  if (args[0] === 'on' || args[0] === 'تفعيل') {
    isEnable = true;
  } else if (args[0] === 'off' || args[0] === 'تعطيل') {
    isEnable = false
  } else {
    const estado = isEnable ? '✓ مفعل' : '✗ معطل'
    return conn.reply(m.chat, `「✦」يمكن للمشرف تفعيل أو تعطيل *${command}* باستخدام:\n\n> ✐ *${usedPrefix}${command} on* للتفعيل.\n> ✐ *${usedPrefix}${command} off* للتعطيل.\n\n✧ الحالة الحالية » *${estado}*`, m)
  }

  switch (type) {
    case 'welcome':
    case 'ترحيب':
      if (!m.isGroup) {
        if (!isOwner) {
          global.dfail('group', m, conn)
          throw false
        }
      } else if (!isAdmin) {
        global.dfail('admin', m, conn)
        throw false
      }
      chat.welcome = isEnable
      break  
      
    case 'antiprivado':
    case 'منع_خاص':
      isAll = true
      if (!isOwner) {
        global.dfail('rowner', m, conn)
        throw false
      }
      bot.antiPrivate = isEnable
      break

    case 'restrict':
    case 'تقييد':
      isAll = true
      if (!isOwner) {
        global.dfail('rowner', m, conn)
        throw false
      }
      bot.restrict = isEnable
      break

    case 'antibot':
    case 'منع_بوتات':
      if (m.isGroup) {
        if (!(isAdmin || isOwner)) {
          global.dfail('admin', m, conn)
          throw false
        }
      }
      chat.antiBot = isEnable
      break

    case 'autoaceptar':
    case 'قبول_تلقائي':
      if (!m.isGroup) {
        if (!isOwner) {
          global.dfail('group', m, conn)
          throw false
        }
      } else if (!isAdmin) {
        global.dfail('admin', m, conn)
        throw false
      }
      chat.autoAceptar = isEnable
      break

    case 'autorechazar':
    case 'رفض_تلقائي':
      if (!m.isGroup) {
        if (!isOwner) {
          global.dfail('group', m, conn)
          throw false
        }
      } else if (!isAdmin) {
        global.dfail('admin', m, conn)
        throw false
      }
      chat.autoRechazar = isEnable
      break

    case 'autoresponder':
    case 'رد_تلقائي':
      if (m.isGroup) {
        if (!(isAdmin || isOwner)) {
          global.dfail('admin', m, conn)
          throw false
        }
      }
      chat.autoresponder = isEnable
      break

    case 'antisubbots':
    case 'منع_بوتات_فرعية':
      if (m.isGroup) {
        if (!(isAdmin || isOwner)) {
          global.dfail('admin', m, conn)
          throw false
        }
      }
      chat.antiBot2 = isEnable
      break

    case 'modoadmin':
    case 'وضع_المشرفين':
      if (m.isGroup) {
        if (!(isAdmin || isOwner)) {
          global.dfail('admin', m, conn);
          throw false;
        }
      }
      chat.modoadmin = isEnable;
      break;

    case 'reaction':
    case 'تفاعل':
      if (!m.isGroup) {
        if (!isOwner) {
          global.dfail('group', m, conn)
          throw false
        }
      } else if (!isAdmin) {
        global.dfail('admin', m, conn)
        throw false
      }
      chat.reaction = isEnable
      break
      
    case 'nsfw':
    case 'وضع_البالغين':
      if (m.isGroup) {
        if (!(isAdmin || isOwner)) {
          global.dfail('admin', m, conn)
          throw false
        }
      }
      chat.nsfw = isEnable
      break

    case 'jadibotmd':
    case 'وضع_جادي_بوت':
      isAll = true
      if (!isOwner) {
        global.dfail('rowner', m, conn)
        throw false
      }
      bot.jadibotmd = isEnable
      break

    case 'detect':
    case 'كشف':
      if (!m.isGroup) {
        if (!isOwner) {
          global.dfail('group', m, conn)
          throw false
        }
      } else if (!isAdmin) {
        global.dfail('admin', m, conn)
        throw false
      }
      chat.detect = isEnable
      break

    case 'antilink':
    case 'منع_الروابط':
      if (m.isGroup) {
        if (!(isAdmin || isOwner)) {
          global.dfail('admin', m, conn)
          throw false
        }
      }
      chat.antiLink = isEnable
      break

    case 'antifake':
    case 'منع_مزيف':
      if (m.isGroup) {
        if (!(isAdmin || isOwner)) {
          global.dfail('admin', m, conn)
          throw false
        }
      }
      chat.antifake = isEnable
      break
  }
  
  chat[type] = isEnable;
  
  conn.reply(m.chat, `《✦》تم *${isEnable ? 'تفعيل' : 'تعطيل'}* الوظيفة *${type}* ${isAll ? 'لهذا البوت' : isUser ? '' : 'لهذه المجموعة'}`, m);
};

handler.help = ['welcome', 'ترحيب', 'antiprivado', 'منع_خاص', 'restrict', 'تقييد', 'autolevelup', 'ترقية_تلقائية', 'antibot', 'منع_بوتات', 'autoaceptar', 'قبول_تلقائي', 'autorechazar', 'رفض_تلقائي', 'autoresponder', 'رد_تلقائي', 'antisubbots', 'منع_بوتات_فرعية', 'modoadmin', 'وضع_المشرفين', 'reaction', 'تفاعل', 'nsfw', 'وضع_البالغين', 'antispam', 'منع_سبام', 'jadibotmd', 'وضع_جادي_بوت', 'subbots', 'بوتات_فرعية', 'detect', 'كشف', 'antilink', 'منع_الروابط', 'antifake', 'منع_مزيف']
handler.tags = ['nable'];
handler.command = ['welcome', 'ترحيب', 'antiprivado', 'منع_خاص', 'restrict', 'تقييد', 'autolevelup', 'ترقية_تلقائية', 'antibot', 'منع_بوتات', 'autoaceptar', 'قبول_تلقائي', 'autorechazar', 'رفض_تلقائي', 'autoresponder', 'رد_تلقائي', 'antisubbots', 'منع_بوتات_فرعية', 'modoadmin', 'وضع_المشرفين', 'reaction', 'تفاعل', 'nsfw', 'وضع_البالغين', 'antispam', 'منع_سبام', 'jadibotmd', 'وضع_جادي_بوت', 'subbots', 'بوتات_فرعية', 'detect', 'كشف', 'antilink', 'منع_الروابط', 'antifake', 'منع_مزيف']

export default handler